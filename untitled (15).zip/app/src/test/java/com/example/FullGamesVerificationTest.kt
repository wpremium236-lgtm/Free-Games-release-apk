package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.core.model.GameCatalog
import com.example.games.ludo.LudoBoardCoordinates
import com.example.games.ludo.LudoEngine
import com.example.games.ludo.LudoPlayer
import com.example.games.ludo.LudoToken
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import kotlin.math.abs
import kotlin.math.hypot

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class FullGamesVerificationTest {

  @Test
  fun testGameCatalogHasAll20GamesAndValidData() {
    val games = GameCatalog.games
    assertTrue("App must contain at least 20 games", games.size >= 20)

    val expectedGameIds = setOf(
      "ludo", "snake", "tictactoe", "carracing", "tapflying",
      "game2048", "sudoku", "minesweeper", "memorymatch", "chess",
      "checkers", "solitaire", "bubbleshooter", "archery", "brickbreaker",
      "spaceshooter", "numberguessing", "wordpuzzle", "connectfour", "knifehit",
      "fruitslicer", "blockpuzzle", "colormatch", "whackamole"
    )

    val actualIds = games.map { it.id }.toSet()
    expectedGameIds.forEach { expectedId ->
      assertTrue("GameCatalog must contain game id: $expectedId", actualIds.contains(expectedId))
    }

    games.forEach { game ->
      assertTrue("Game ${game.id} must have non-empty English name", game.nameEn.isNotBlank())
      assertTrue("Game ${game.id} must have non-empty Bengali name", game.nameBn.isNotBlank())
      assertTrue("Game ${game.id} must have an icon emoji", game.iconEmoji.isNotBlank())
      assertTrue("Game ${game.id} must have description", game.descriptionEn.isNotBlank())
      assertTrue("Game ${game.id} must have how-to-play instructions", game.howToPlayEn.isNotBlank())
      assertTrue("Game ${game.id} must have controls instructions", game.controlsEn.isNotBlank())
    }
  }

  @Test
  fun testLudo15x15ClassicBoardBasesAndGeometry() {
    // 1. Grid Size
    assertEquals(15, LudoBoardCoordinates.GRID_SIZE)

    // 2. 52 Track Cells Loop
    val track = LudoBoardCoordinates.TRACK_COORDINATES
    assertEquals(52, track.size)
    assertEquals(52, track.toSet().size) // All unique coordinates

    // 3. 4 Symmetrical Bases: 4 sockets per base
    val players = listOf(LudoPlayer.RED, LudoPlayer.GREEN, LudoPlayer.YELLOW, LudoPlayer.BLUE)
    players.forEach { p ->
      for (tokenId in 0 until 4) {
        val socket = LudoBoardCoordinates.getBaseSocket(p, tokenId)
        when (p) {
          LudoPlayer.RED -> {
            assertTrue("Red socket must be in top-left 6x6", socket.first < 6f && socket.second < 6f)
          }
          LudoPlayer.GREEN -> {
            assertTrue("Green socket must be in top-right 6x6", socket.first >= 9f && socket.second < 6f)
          }
          LudoPlayer.YELLOW -> {
            assertTrue("Yellow socket must be in bottom-right 6x6", socket.first >= 9f && socket.second >= 9f)
          }
          LudoPlayer.BLUE -> {
            assertTrue("Blue socket must be in bottom-left 6x6", socket.first < 6f && socket.second >= 9f)
          }
          else -> {}
        }
      }
    }

    // 4. Center Finish Spots
    players.forEach { p ->
      val finishSpot = LudoBoardCoordinates.getHomeFinishCoordinate(p)
      assertTrue("Finish spot must be in center 3x3 (6..9)", finishSpot.first in 6f..9f && finishSpot.second in 6f..9f)
    }
  }

  @Test
  fun testLudoPlayerModesAndSeating() {
    // 2 Players: RED + GREEN
    val p2 = LudoEngine.getActivePlayers(2)
    assertEquals(2, p2.size)
    assertEquals(listOf(LudoPlayer.RED, LudoPlayer.GREEN), p2)

    // 3 Players: RED + GREEN + YELLOW
    val p3 = LudoEngine.getActivePlayers(3)
    assertEquals(3, p3.size)
    assertEquals(listOf(LudoPlayer.RED, LudoPlayer.GREEN, LudoPlayer.YELLOW), p3)

    // 4 Players: RED + GREEN + YELLOW + BLUE
    val p4 = LudoEngine.getActivePlayers(4)
    assertEquals(4, p4.size)
    assertEquals(listOf(LudoPlayer.RED, LudoPlayer.GREEN, LudoPlayer.YELLOW, LudoPlayer.BLUE), p4)

    // 5 Players: RED + GREEN + YELLOW + BLUE + PURPLE
    val p5 = LudoEngine.getActivePlayers(5)
    assertEquals(5, p5.size)
    assertEquals(listOf(LudoPlayer.RED, LudoPlayer.GREEN, LudoPlayer.YELLOW, LudoPlayer.BLUE, LudoPlayer.PURPLE), p5)

    // 6 Players: RED + GREEN + YELLOW + BLUE + PURPLE + ORANGE
    val p6 = LudoEngine.getActivePlayers(6)
    assertEquals(6, p6.size)
    assertEquals(listOf(LudoPlayer.RED, LudoPlayer.GREEN, LudoPlayer.YELLOW, LudoPlayer.BLUE, LudoPlayer.PURPLE, LudoPlayer.ORANGE), p6)
  }

  @Test
  fun testLudoTurnProgressionAndColorIsolation() {
    val active = LudoEngine.getActivePlayers(4)
    val redToken = LudoToken(id = 0, player = LudoPlayer.RED, position = 0)
    val greenToken = LudoToken(id = 0, player = LudoPlayer.GREEN, position = 13)
    val yellowToken = LudoToken(id = 0, player = LudoPlayer.YELLOW, position = 26)
    val blueToken = LudoToken(id = 0, player = LudoPlayer.BLUE, position = 39)

    // On Red turn (roll 3):
    assertTrue(LudoEngine.isTokenSelectable(redToken, LudoPlayer.RED, 3))
    assertFalse("Green cannot move on Red turn", LudoEngine.isTokenSelectable(greenToken, LudoPlayer.RED, 3))
    assertFalse("Yellow cannot move on Red turn", LudoEngine.isTokenSelectable(yellowToken, LudoPlayer.RED, 3))
    assertFalse("Blue cannot move on Red turn", LudoEngine.isTokenSelectable(blueToken, LudoPlayer.RED, 3))

    // Next turn is Green:
    val nextIdx = LudoEngine.getNextPlayerIndex(0, active)
    val greenPlayer = active[nextIdx]
    assertEquals(LudoPlayer.GREEN, greenPlayer)
    assertTrue(LudoEngine.isTokenSelectable(greenToken, greenPlayer, 3))
    assertFalse("Red cannot move on Green turn", LudoEngine.isTokenSelectable(redToken, greenPlayer, 3))
  }

  @Test
  fun testLudoCaptureSendsOpponentToBase() {
    val redToken = LudoToken(id = 0, player = LudoPlayer.RED, position = 5)
    val greenToken = LudoToken(id = 0, player = LudoPlayer.GREEN, position = 9)

    // Red rolls 4: lands on square 9 (non-safe track cell)
    val nextPos = LudoEngine.calculateNextPosition(redToken, 4)
    assertEquals(9, nextPos)

    val captured = LudoEngine.checkCaptures(redToken, nextPos, listOf(redToken, greenToken))
    assertEquals(1, captured.size)
    assertEquals(greenToken, captured[0])

    // Capturing grants bonus roll
    assertTrue(LudoEngine.shouldGetBonusRoll(roll = 4, capturedOpponent = true, reachedHome = false))
  }

  @Test
  fun testLudoProtectedOnSafeStarSquares() {
    val redToken = LudoToken(id = 0, player = LudoPlayer.RED, position = 4)
    val greenToken = LudoToken(id = 0, player = LudoPlayer.GREEN, position = 8) // Safe Star ★

    // Red rolls 4: lands on square 8
    val nextPos = LudoEngine.calculateNextPosition(redToken, 4)
    assertEquals(8, nextPos)

    // Cannot capture on safe star
    val captured = LudoEngine.checkCaptures(redToken, nextPos, listOf(redToken, greenToken))
    assertTrue("Tokens on safe star cell 8 cannot be captured", captured.isEmpty())
  }

  @Test
  fun testLudoExactHomeEntryAndWinning() {
    // Red token in home corridor at pos 55 (step 4). Step 5 is 56. Central home is 57.
    val token = LudoToken(id = 0, player = LudoPlayer.RED, position = 55)

    // Roll 1: advances to 56
    assertTrue(LudoEngine.canMoveToken(token, 1))
    assertEquals(56, LudoEngine.calculateNextPosition(token, 1))

    // Roll 2: exact finish in central home 57
    assertTrue(LudoEngine.canMoveToken(token, 2))
    assertEquals(57, LudoEngine.calculateNextPosition(token, 2))

    // Roll 3: overshoots -> cannot move
    assertFalse(LudoEngine.canMoveToken(token, 3))
    assertEquals(55, LudoEngine.calculateNextPosition(token, 3))

    // Winning condition: all 4 tokens finished (57)
    val redTokens = listOf(
      LudoToken(id = 0, player = LudoPlayer.RED, position = 57),
      LudoToken(id = 1, player = LudoPlayer.RED, position = 57),
      LudoToken(id = 2, player = LudoPlayer.RED, position = 57),
      LudoToken(id = 3, player = LudoPlayer.RED, position = 57)
    )
    assertTrue(LudoEngine.hasPlayerWon(redTokens))
  }

  @Test
  fun testFirebaseConfigurationResourcesPresent() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val packageName = context.packageName
    assertEquals("com.aistudio.freegames.hubqwe", packageName)

    val defaultWebClientIdRes = context.resources.getIdentifier("default_web_client_id", "string", packageName)
    assertTrue("default_web_client_id resource must be present", defaultWebClientIdRes != 0)
    val webClientId = context.getString(defaultWebClientIdRes)
    assertTrue("webClientId must be non-empty", webClientId.isNotBlank())

    val googleAppIdRes = context.resources.getIdentifier("google_app_id", "string", packageName)
    assertTrue("google_app_id resource must be present", googleAppIdRes != 0)
  }
}
