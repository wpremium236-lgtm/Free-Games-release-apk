package com.example

import com.example.games.ludo.LudoBoardCoordinates
import com.example.games.ludo.LudoEngine
import com.example.games.ludo.LudoPlayer
import com.example.games.ludo.LudoToken
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.hypot

class LudoRulesUnitTest {

  @Test
  fun testTrackGeometryCountAndUniqueness() {
    val track = LudoBoardCoordinates.TRACK_COORDINATES
    // Exactly 52 track cells in classic 15x15 Ludo
    assertEquals(52, track.size)

    // All 52 coordinates must be distinct
    val uniqueCoords = track.toSet()
    assertEquals("All 52 track coordinates must be unique without any overlap", 52, uniqueCoords.size)
  }

  @Test
  fun testTrackGeometryStrictContiguityAndNoJumps() {
    val track = LudoBoardCoordinates.TRACK_COORDINATES
    assertEquals(52, track.size)

    for (i in 0 until 52) {
      val c1 = track[i]
      val c2 = track[(i + 1) % 52]

      val dx = abs(c2.first - c1.first)
      val dy = abs(c2.second - c1.second)
      val dist = hypot(dx, dy)

      // Every consecutive cell transition must be adjacent on grid (cardinal 1.0, or corner diagonal <= 1.42)
      assertTrue(
        "Step from cell $i ($c1) to next cell ${(i + 1) % 52} ($c2) has jump! dx=$dx, dy=$dy, dist=$dist",
        dx <= 1.01f && dy <= 1.01f && dist <= 1.42f
      )
    }

    // Explicit check for closed loop return (51 -> 0)
    val c51 = track[51]
    val c0 = track[0]
    val dist51To0 = hypot(c0.first - c51.first, c0.second - c51.second)
    assertTrue("Cell 51 to 0 must be adjacent to close loop seamlessly, dist was $dist51To0", dist51To0 <= 1.42f)
  }

  @Test
  fun testPlayerRoutesStartAndHomeEntrance() {
    val players = listOf(LudoPlayer.RED, LudoPlayer.GREEN, LudoPlayer.YELLOW, LudoPlayer.BLUE)
    assertEquals(4, players.size)

    players.forEach { player ->
      // Starting cell must be valid index in 0..51
      assertTrue(player.startPos in 0 until LudoEngine.TRACK_LENGTH)
      assertTrue(player.endTrackPos in 0 until LudoEngine.TRACK_LENGTH)

      // Expected end track pos is 50 steps from start pos
      val expectedEnd = (player.startPos + 50) % LudoEngine.TRACK_LENGTH
      assertEquals(
        "Player ${player.displayName} endTrackPos must be 50 steps from startPos",
        expectedEnd,
        player.endTrackPos
      )
    }
  }

  @Test
  fun testTurnOrderCycleAndHundredTurnSimulation() {
    val activePlayers = LudoEngine.getActivePlayers(4)
    assertEquals(4, activePlayers.size)

    val expectedCycle = listOf(
      LudoPlayer.RED,
      LudoPlayer.GREEN,
      LudoPlayer.YELLOW,
      LudoPlayer.BLUE
    )

    var currentIdx = 0
    for (turn in 0 until 120) {
      val expectedPlayer = expectedCycle[turn % 4]
      assertEquals(expectedPlayer, activePlayers[currentIdx])
      currentIdx = LudoEngine.getNextPlayerIndex(currentIdx, activePlayers)
    }
  }

  @Test
  fun testTokenSelectionOnlyActivePlayerTokensSelectable() {
    val allPlayers = listOf(LudoPlayer.RED, LudoPlayer.GREEN, LudoPlayer.YELLOW, LudoPlayer.BLUE)
    allPlayers.forEach { activePlayer ->
      allPlayers.forEach { candidatePlayer ->
        val token = LudoToken(id = 0, player = candidatePlayer, position = -1)
        val isSelectable = LudoEngine.isTokenSelectable(token, activePlayer, roll = 6)
        if (candidatePlayer == activePlayer) {
          assertTrue("Active player's token must be selectable on roll 6", isSelectable)
        } else {
          assertFalse("Opponent's token must be locked and not selectable", isSelectable)
        }
      }
    }
  }

  @Test
  fun testSpecificTokenSelectivityExampleDiceThree() {
    val redPlayer = LudoPlayer.RED
    // Token 1 on track at pos 10 -> moving 3 lands on 13 (valid)
    val token1 = LudoToken(id = 0, player = redPlayer, position = 10)
    // Token 2 in base (-1) -> roll 3 cannot release (invalid)
    val token2 = LudoToken(id = 1, player = redPlayer, position = -1)
    // Token 3 on track at pos 20 -> moving 3 lands on 23 (valid)
    val token3 = LudoToken(id = 2, player = redPlayer, position = 20)
    // Token 4 already finished (57) -> cannot move (invalid)
    val token4 = LudoToken(id = 3, player = redPlayer, position = 57)

    assertTrue(LudoEngine.isTokenSelectable(token1, redPlayer, 3))
    assertFalse(LudoEngine.isTokenSelectable(token2, redPlayer, 3))
    assertTrue(LudoEngine.isTokenSelectable(token3, redPlayer, 3))
    assertFalse(LudoEngine.isTokenSelectable(token4, redPlayer, 3))

    // For any opponent player (e.g. Green), red tokens must NEVER be selectable
    assertFalse(LudoEngine.isTokenSelectable(token1, LudoPlayer.GREEN, 3))
    assertFalse(LudoEngine.isTokenSelectable(token3, LudoPlayer.GREEN, 3))
  }

  @Test
  fun testDiceValidityRange() {
    val token = LudoToken(id = 0, player = LudoPlayer.RED, position = 10)
    // Invalid dice rolls
    assertFalse(LudoEngine.canMoveToken(token, 0))
    assertFalse(LudoEngine.canMoveToken(token, 7))
    assertFalse(LudoEngine.canMoveToken(token, -1))
    assertFalse(LudoEngine.canMoveToken(token, 10))

    // Valid dice rolls
    for (roll in 1..6) {
      assertTrue("Roll $roll must be legal for token on track", LudoEngine.canMoveToken(token, roll))
    }
  }

  @Test
  fun testSafeSpotsSingleSourceOfTruth() {
    // 8 Safe Cells exactly in standard 15x15 Ludo
    assertEquals(8, LudoEngine.SAFE_CELLS.size)
    assertEquals(LudoEngine.SAFE_CELLS, LudoEngine.safePositions)

    // 4 Player start cells
    assertTrue(LudoEngine.isSafeSpot(0))   // Red Start
    assertTrue(LudoEngine.isSafeSpot(13))  // Green Start
    assertTrue(LudoEngine.isSafeSpot(26))  // Yellow Start
    assertTrue(LudoEngine.isSafeSpot(39))  // Blue Start

    // 4 Star cells
    assertTrue(LudoEngine.isSafeSpot(8))
    assertTrue(LudoEngine.isSafeSpot(21))
    assertTrue(LudoEngine.isSafeSpot(34))
    assertTrue(LudoEngine.isSafeSpot(47))

    // Non-safe cells
    assertFalse(LudoEngine.isSafeSpot(1))
    assertFalse(LudoEngine.isSafeSpot(7))
    assertFalse(LudoEngine.isSafeSpot(14))
    assertFalse(LudoEngine.isSafeSpot(51))
  }

  @Test
  fun testCaptureRuleAndProtectionOnSafeSpot() {
    val redToken = LudoToken(id = 0, player = LudoPlayer.RED, position = 15)
    val yellowToken = LudoToken(id = 0, player = LudoPlayer.YELLOW, position = 15)

    // Can capture opponent on non-safe square 15
    assertTrue(LudoEngine.canCapture(15, LudoPlayer.RED, yellowToken))

    // Cannot capture own token
    val ownRedToken = LudoToken(id = 1, player = LudoPlayer.RED, position = 15)
    assertFalse(LudoEngine.canCapture(15, LudoPlayer.RED, ownRedToken))

    // Opponent on safe spot (e.g. 21) cannot be captured
    val greenTokenOnSafe = LudoToken(id = 0, player = LudoPlayer.GREEN, position = 21)
    assertFalse(LudoEngine.canCapture(21, LudoPlayer.RED, greenTokenOnSafe))
  }

  @Test
  fun testBaseReleaseOnlyOnSix() {
    val baseToken = LudoToken(id = 0, player = LudoPlayer.RED, position = -1)
    for (roll in 1..5) {
      assertFalse("Base token cannot move on roll $roll", LudoEngine.canMoveToken(baseToken, roll))
      assertEquals(-1, LudoEngine.calculateNextPosition(baseToken, roll))
    }
    assertTrue("Base token can move on roll 6", LudoEngine.canMoveToken(baseToken, 6))
    assertEquals(0, LudoEngine.calculateNextPosition(baseToken, 6))
  }

  @Test
  fun testThreeSixesRule() {
    assertFalse(LudoEngine.isThreeSixesForfeit(1))
    assertFalse(LudoEngine.isThreeSixesForfeit(2))
    assertTrue("3 sixes in a row must forfeit turn", LudoEngine.isThreeSixesForfeit(3))
    assertTrue(LudoEngine.isThreeSixesForfeit(4))
  }

  @Test
  fun testExactHomeFinishRule() {
    // Red token in home lane at step 4 (position 55). Step 5 is 56. Finish is 57.
    val tokenInLane = LudoToken(id = 0, player = LudoPlayer.RED, position = 55)

    // Roll 1: moves to step 5 (position 56)
    assertTrue(LudoEngine.canMoveToken(tokenInLane, 1))
    assertEquals(56, LudoEngine.calculateNextPosition(tokenInLane, 1))

    // Roll 2: reaches exact finish in central home (57)
    assertTrue(LudoEngine.canMoveToken(tokenInLane, 2))
    assertEquals(57, LudoEngine.calculateNextPosition(tokenInLane, 2))

    // Roll 3: overshoots! (4 + 3 = 7 > 6)
    assertFalse("Overshoot must be rejected", LudoEngine.canMoveToken(tokenInLane, 3))
    assertEquals(55, LudoEngine.calculateNextPosition(tokenInLane, 3))

    // Roll 6: overshoots!
    assertFalse(LudoEngine.canMoveToken(tokenInLane, 6))
  }

  @Test
  fun testPlayerCountAndTotalTokens() {
    val p2 = LudoEngine.getActivePlayers(2)
    assertEquals(2, p2.size)

    val p3 = LudoEngine.getActivePlayers(3)
    assertEquals(3, p3.size)

    val p4 = LudoEngine.getActivePlayers(4)
    assertEquals(4, p4.size)

    val p5 = LudoEngine.getActivePlayers(5)
    assertEquals(5, p5.size)

    val p6 = LudoEngine.getActivePlayers(6)
    assertEquals(6, p6.size)

    // 4 Players * 4 tokens = 16 tokens total
    val tokens4 = p4.flatMap { player ->
      (0 until 4).map { id -> LudoToken(id = id, player = player, position = -1) }
    }
    assertEquals(16, tokens4.size)

    // 6 Players * 4 tokens = 24 tokens total
    val tokens6 = p6.flatMap { player ->
      (0 until 4).map { id -> LudoToken(id = id, player = player, position = -1) }
    }
    assertEquals(24, tokens6.size)
  }

  @Test
  fun testRequirementD_FiveAndSixPlayerSeatingAndCycle() {
    val p5 = LudoEngine.getActivePlayers(5)
    assertEquals(listOf(LudoPlayer.RED, LudoPlayer.GREEN, LudoPlayer.YELLOW, LudoPlayer.BLUE, LudoPlayer.PURPLE), p5)

    val p6 = LudoEngine.getActivePlayers(6)
    val expected6 = listOf(
      LudoPlayer.RED,
      LudoPlayer.GREEN,
      LudoPlayer.YELLOW,
      LudoPlayer.BLUE,
      LudoPlayer.PURPLE,
      LudoPlayer.ORANGE
    )
    assertEquals(expected6, p6)

    var idx = 0
    for (i in 0 until 6) {
      assertEquals(expected6[i], p6[idx])
      idx = LudoEngine.getNextPlayerIndex(idx, p6)
    }
    assertEquals(0, idx)
  }

  @Test
  fun testSixPlayerBoardAndMovementRules() {
    val p6 = LudoEngine.getActivePlayers(6)
    assertEquals(6, p6.size)
    assertEquals(72, LudoEngine.getTrackLength(6))
    assertEquals(77, LudoEngine.getFinishedPos(6))

    // 6 Base release on 6 only
    val purpleToken = LudoToken(id = 0, player = LudoPlayer.PURPLE, position = -1)
    assertFalse(LudoEngine.canMoveToken(purpleToken, 5, 6))
    assertTrue(LudoEngine.canMoveToken(purpleToken, 6, 6))
    assertEquals(48, LudoEngine.calculateNextPosition(purpleToken, 6, 6)) // Purple start = 48

    val orangeToken = LudoToken(id = 0, player = LudoPlayer.ORANGE, position = -1)
    assertTrue(LudoEngine.canMoveToken(orangeToken, 6, 6))
    assertEquals(60, LudoEngine.calculateNextPosition(orangeToken, 6, 6)) // Orange start = 60

    // Capture in 6-player mode
    val redOnTrack = LudoToken(id = 0, player = LudoPlayer.RED, position = 15)
    val purpleOnTrack = LudoToken(id = 1, player = LudoPlayer.PURPLE, position = 15)
    assertTrue(LudoEngine.canCapture(15, LudoPlayer.RED, purpleOnTrack, 6))

    // Safe spots in 6-player mode
    assertTrue(LudoEngine.isSafeSpot(0, 6))   // Red start
    assertTrue(LudoEngine.isSafeSpot(12, 6))  // Green start
    assertTrue(LudoEngine.isSafeSpot(24, 6))  // Yellow start
    assertTrue(LudoEngine.isSafeSpot(36, 6))  // Blue start
    assertTrue(LudoEngine.isSafeSpot(48, 6))  // Purple start
    assertTrue(LudoEngine.isSafeSpot(60, 6))  // Orange start
    assertTrue(LudoEngine.isSafeSpot(7, 6))   // Star safe
  }

  @Test
  fun testWinnerConditionAllFourTokensInHome() {
    val tokens3Home1Lane = listOf(
      LudoToken(id = 0, player = LudoPlayer.RED, position = 57),
      LudoToken(id = 1, player = LudoPlayer.RED, position = 57),
      LudoToken(id = 2, player = LudoPlayer.RED, position = 57),
      LudoToken(id = 3, player = LudoPlayer.RED, position = 56)
    )
    assertFalse(LudoEngine.hasPlayerWon(tokens3Home1Lane))

    val tokensAll4Home = listOf(
      LudoToken(id = 0, player = LudoPlayer.RED, position = 57),
      LudoToken(id = 1, player = LudoPlayer.RED, position = 57),
      LudoToken(id = 2, player = LudoPlayer.RED, position = 57),
      LudoToken(id = 3, player = LudoPlayer.RED, position = 57)
    )
    assertTrue(LudoEngine.hasPlayerWon(tokensAll4Home))
  }

  @Test
  fun testRequirementA_TwoPlayerSeatingAndDice() {
    val p2 = LudoEngine.getActivePlayers(2)
    assertEquals(listOf(LudoPlayer.RED, LudoPlayer.GREEN), p2)

    val currentP = p2[0] // RED
    assertTrue(LudoEngine.isCurrentPlayerTurn(LudoPlayer.RED, currentP))
    assertFalse(LudoEngine.isCurrentPlayerTurn(LudoPlayer.GREEN, currentP))

    val redToken = LudoToken(id = 0, player = LudoPlayer.RED, position = 0)
    val greenToken = LudoToken(id = 0, player = LudoPlayer.GREEN, position = 13)
    assertTrue(LudoEngine.isTokenSelectable(redToken, currentP, roll = 4))
    assertFalse(LudoEngine.isTokenSelectable(greenToken, currentP, roll = 4))
  }

  @Test
  fun testRequirementB_ThreePlayerSeatingAndCycle() {
    val p3 = LudoEngine.getActivePlayers(3)
    assertEquals(listOf(LudoPlayer.RED, LudoPlayer.GREEN, LudoPlayer.YELLOW), p3)

    var idx = 0
    assertEquals(LudoPlayer.RED, p3[idx])
    idx = LudoEngine.getNextPlayerIndex(idx, p3)
    assertEquals(LudoPlayer.GREEN, p3[idx])
    idx = LudoEngine.getNextPlayerIndex(idx, p3)
    assertEquals(LudoPlayer.YELLOW, p3[idx])
    idx = LudoEngine.getNextPlayerIndex(idx, p3)
    assertEquals(LudoPlayer.RED, p3[idx])
  }

  @Test
  fun testRequirementC_FourPlayerSeatingAndCycle() {
    val p4 = LudoEngine.getActivePlayers(4)
    assertEquals(listOf(LudoPlayer.RED, LudoPlayer.GREEN, LudoPlayer.YELLOW, LudoPlayer.BLUE), p4)

    var idx = 0
    val expected = listOf(LudoPlayer.RED, LudoPlayer.GREEN, LudoPlayer.YELLOW, LudoPlayer.BLUE)
    for (i in 0 until 4) {
      assertEquals(expected[i], p4[idx])
      idx = LudoEngine.getNextPlayerIndex(idx, p4)
    }
    assertEquals(0, idx)
  }

  @Test
  fun testRequirementJ_OfflinePassAndPlayTurnProgression() {
    val p4 = LudoEngine.getActivePlayers(4)
    var currentIdx = 0

    // Red moves without bonus
    currentIdx = LudoEngine.getNextPlayerIndex(currentIdx, p4)
    assertEquals(LudoPlayer.GREEN, p4[currentIdx])

    // Green moves without bonus
    currentIdx = LudoEngine.getNextPlayerIndex(currentIdx, p4)
    assertEquals(LudoPlayer.YELLOW, p4[currentIdx])

    // Yellow rolls 6 -> gets bonus roll
    val getsBonus = LudoEngine.shouldGetBonusRoll(roll = 6, capturedOpponent = false, reachedHome = false)
    assertTrue(getsBonus)
    // Same player continues turn!
    assertEquals(LudoPlayer.YELLOW, p4[currentIdx])

    // Next turn without bonus
    currentIdx = LudoEngine.getNextPlayerIndex(currentIdx, p4)
    assertEquals(LudoPlayer.BLUE, p4[currentIdx])
  }

  @Test
  fun testSecurityMaliciousClientCannotMoveOpponentToken() {
    val activePlayers = LudoEngine.getActivePlayers(4)
    val currentTurnPlayer = activePlayers[0] // RED
    assertEquals(LudoPlayer.RED, currentTurnPlayer)

    // Attempting to move Green, Yellow, or Blue token during Red's turn
    val greenToken = LudoToken(id = 0, player = LudoPlayer.GREEN, position = 13)
    val yellowToken = LudoToken(id = 1, player = LudoPlayer.YELLOW, position = 26)
    val blueToken = LudoToken(id = 2, player = LudoPlayer.BLUE, position = 39)

    assertFalse("Green token must NOT be selectable on Red's turn", LudoEngine.isTokenSelectable(greenToken, currentTurnPlayer, 4))
    assertFalse("Yellow token must NOT be selectable on Red's turn", LudoEngine.isTokenSelectable(yellowToken, currentTurnPlayer, 4))
    assertFalse("Blue token must NOT be selectable on Red's turn", LudoEngine.isTokenSelectable(blueToken, currentTurnPlayer, 4))
  }

  @Test
  fun testSecurityOutOfTurnRollProtection() {
    val activePlayers = LudoEngine.getActivePlayers(2) // RED, GREEN
    val redPlayer = activePlayers[0]
    val greenPlayer = activePlayers[1]

    // On Red's turn:
    assertTrue(LudoEngine.isCurrentPlayerTurn(redPlayer, redPlayer))
    assertFalse("Green player attempting to roll during Red's turn must be denied", LudoEngine.isCurrentPlayerTurn(greenPlayer, redPlayer))

    // On Green's turn:
    assertTrue(LudoEngine.isCurrentPlayerTurn(greenPlayer, greenPlayer))
    assertFalse("Red player attempting to roll during Green's turn must be denied", LudoEngine.isCurrentPlayerTurn(redPlayer, greenPlayer))
  }

  @Test
  fun testSecurityTokenPositionBoundsValidation() {
    val redPlayer = LudoPlayer.RED
    // Valid positions: -1 (base) up to 57 (finished home)
    val baseToken = LudoToken(id = 0, player = redPlayer, position = -1)
    val trackToken = LudoToken(id = 1, player = redPlayer, position = 30)
    val finishedToken = LudoToken(id = 2, player = redPlayer, position = 57)

    assertTrue(baseToken.position in -1..57)
    assertTrue(trackToken.position in -1..57)
    assertTrue(finishedToken.position in -1..57)

    val negativeInvalid = -2
    val overflowInvalid = 58
    assertFalse(negativeInvalid in -1..57)
    assertFalse(overflowInvalid in -1..57)
  }

  @Test
  fun testBonusRollOnCaptureAndHomeFinish() {
    assertTrue(LudoEngine.shouldGetBonusRoll(roll = 6, capturedOpponent = false, reachedHome = false))
    assertTrue(LudoEngine.shouldGetBonusRoll(roll = 3, capturedOpponent = true, reachedHome = false))
    assertTrue(LudoEngine.shouldGetBonusRoll(roll = 2, capturedOpponent = false, reachedHome = true))
    assertFalse(LudoEngine.shouldGetBonusRoll(roll = 4, capturedOpponent = false, reachedHome = false))
  }
}
