package com.example.games.ludo

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun LudoDiceView(
  value: Int,
  isRolling: Boolean,
  diceSize: Dp = 58.dp,
  highlightColor: Color = Color(0xFF6C5CE7),
  modifier: Modifier = Modifier
) {
  val rotationAnim = remember { Animatable(0f) }

  LaunchedEffect(isRolling) {
    if (isRolling) {
      rotationAnim.animateTo(
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
          animation = tween(250, easing = LinearEasing),
          repeatMode = RepeatMode.Restart
        )
      )
    } else {
      rotationAnim.snapTo(0f)
    }
  }

  Box(
    modifier = modifier
      .size(diceSize)
      .rotate(if (isRolling) rotationAnim.value else 0f)
      .shadow(elevation = 6.dp, shape = RoundedCornerShape(12.dp))
      .clip(RoundedCornerShape(12.dp))
      .background(
        Brush.linearGradient(
          colors = listOf(Color(0xFFFFFFFF), Color(0xFFEDEDED))
        )
      )
      .border(2.5.dp, highlightColor, RoundedCornerShape(12.dp)),
    contentAlignment = Alignment.Center
  ) {
    Canvas(modifier = Modifier.size(diceSize)) {
      val w = size.width
      val h = size.height
      val pipRadius = w * 0.085f
      val pipColor = Color(0xFF2D3436)

      val left = w * 0.25f
      val center = w * 0.5f
      val right = w * 0.75f

      val top = h * 0.25f
      val middle = h * 0.5f
      val bottom = h * 0.75f

      when (value.coerceIn(1, 6)) {
        1 -> {
          drawCircle(pipColor, pipRadius, Offset(center, middle))
        }
        2 -> {
          drawCircle(pipColor, pipRadius, Offset(left, top))
          drawCircle(pipColor, pipRadius, Offset(right, bottom))
        }
        3 -> {
          drawCircle(pipColor, pipRadius, Offset(left, top))
          drawCircle(pipColor, pipRadius, Offset(center, middle))
          drawCircle(pipColor, pipRadius, Offset(right, bottom))
        }
        4 -> {
          drawCircle(pipColor, pipRadius, Offset(left, top))
          drawCircle(pipColor, pipRadius, Offset(right, top))
          drawCircle(pipColor, pipRadius, Offset(left, bottom))
          drawCircle(pipColor, pipRadius, Offset(right, bottom))
        }
        5 -> {
          drawCircle(pipColor, pipRadius, Offset(left, top))
          drawCircle(pipColor, pipRadius, Offset(right, top))
          drawCircle(pipColor, pipRadius, Offset(center, middle))
          drawCircle(pipColor, pipRadius, Offset(left, bottom))
          drawCircle(pipColor, pipRadius, Offset(right, bottom))
        }
        6 -> {
          drawCircle(pipColor, pipRadius, Offset(left, top))
          drawCircle(pipColor, pipRadius, Offset(right, top))
          drawCircle(pipColor, pipRadius, Offset(left, middle))
          drawCircle(pipColor, pipRadius, Offset(right, middle))
          drawCircle(pipColor, pipRadius, Offset(left, bottom))
          drawCircle(pipColor, pipRadius, Offset(right, bottom))
        }
      }
    }
  }
}
