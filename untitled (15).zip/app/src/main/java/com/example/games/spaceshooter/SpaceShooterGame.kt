package com.example.games.spaceshooter

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import com.example.core.audio.SoundManager
import com.example.core.model.GameResultType
import com.example.games.common.GameOverDialog
import com.example.games.common.GamePauseDialog
import com.example.games.common.GameTopBar
import kotlinx.coroutines.delay
import java.util.UUID
import kotlin.math.hypot
import kotlin.random.Random

data class Bullet(
  var x: Float,
  var y: Float,
  val isPlayer: Boolean,
  val vx: Float = 0f,
  val vy: Float = -0.025f
)

data class EnemyShip(
  var x: Float,
  var y: Float,
  val type: Int, // 0: Scout, 1: Cruiser
  var health: Int,
  val maxHealth: Int,
  val speedY: Float = 0.005f,
  var speedX: Float = 0f
)

data class Particle(
  var x: Float,
  var y: Float,
  var vx: Float,
  var vy: Float,
  var life: Float,
  val color: Color
)

@Composable
fun SpaceShooterGame(
  onBack: () -> Unit,
  onGameFinished: (gameId: String, score: Int, resultType: GameResultType, duration: Long, sessionId: String) -> Unit
) {
  val context = LocalContext.current
  val soundManager = remember { SoundManager.getInstance(context) }
  var sessionId by remember { mutableStateOf(UUID.randomUUID().toString()) }
  var startTimeMs by remember { mutableStateOf(System.currentTimeMillis()) }
  var playerX by remember { mutableFloatStateOf(0.5f) }
  var playerY by remember { mutableFloatStateOf(0.85f) }
  var lives by remember { mutableIntStateOf(3) }
  var score by remember { mutableIntStateOf(0) }
  var wave by remember { mutableIntStateOf(1) }
  var tripleLaserTimer by remember { mutableIntStateOf(0) }

  val bullets = remember { mutableStateListOf<Bullet>() }
  val enemies = remember { mutableStateListOf<EnemyShip>() }
  val particles = remember { mutableStateListOf<Particle>() }

  var isPaused by remember { mutableStateOf(false) }
  var isMuted by remember { mutableStateOf(!soundManager.isSoundEnabled) }
  var isGameOver by remember { mutableStateOf(false) }
  var frameCount by remember { mutableIntStateOf(0) }

  fun restartGame() {
    playerX = 0.5f
    playerY = 0.85f
    lives = 3
    score = 0
    wave = 1
    tripleLaserTimer = 0
    bullets.clear()
    enemies.clear()
    particles.clear()
    isGameOver = false
    startTimeMs = System.currentTimeMillis()
    sessionId = UUID.randomUUID().toString()
  }

  fun spawnExplosion(x: Float, y: Float, count: Int = 12, color: Color = Color(0xFFFFB142)) {
    for (i in 0 until count) {
      val angle = Random.nextFloat() * 6.283f
      val speed = Random.nextFloat() * 0.015f + 0.005f
      particles.add(
        Particle(
          x = x,
          y = y,
          vx = kotlin.math.cos(angle) * speed,
          vy = kotlin.math.sin(angle) * speed,
          life = 1f,
          color = color
        )
      )
    }
  }

  // Game loop
  LaunchedEffect(isPaused, isGameOver) {
    while (!isGameOver) {
      if (!isPaused) {
        frameCount++

        // 1. Auto-fire player lasers
        if (frameCount % 6 == 0) {
          if (tripleLaserTimer > 0) {
            bullets.add(Bullet(playerX, playerY - 0.05f, isPlayer = true, vx = 0f))
            bullets.add(Bullet(playerX - 0.03f, playerY - 0.05f, isPlayer = true, vx = -0.006f))
            bullets.add(Bullet(playerX + 0.03f, playerY - 0.05f, isPlayer = true, vx = 0.006f))
            tripleLaserTimer--
          } else {
            bullets.add(Bullet(playerX, playerY - 0.05f, isPlayer = true))
          }
        }

        // 2. Spawn enemies
        if (frameCount % 45 == 0 && enemies.size < 8) {
          val type = if (wave >= 3 && Random.nextFloat() < 0.3f) 1 else 0
          val hp = if (type == 1) 3 else 1
          val speedY = if (type == 1) 0.004f else 0.007f + (wave * 0.001f)
          enemies.add(
            EnemyShip(
              x = Random.nextFloat() * 0.8f + 0.1f,
              y = -0.05f,
              type = type,
              health = hp,
              maxHealth = hp,
              speedY = speedY,
              speedX = (Random.nextFloat() - 0.5f) * 0.004f
            )
          )
        }

        // 3. Move bullets
        val bulletIterator = bullets.iterator()
        while (bulletIterator.hasNext()) {
          val b = bulletIterator.next()
          b.x += b.vx
          b.y += b.vy
          if (b.y < -0.05f || b.y > 1.05f || b.x < -0.05f || b.x > 1.05f) {
            bulletIterator.remove()
          }
        }

        // 4. Move enemies & Enemy firing
        val enemyIterator = enemies.iterator()
        while (enemyIterator.hasNext()) {
          val e = enemyIterator.next()
          e.y += e.speedY
          e.x += e.speedX
          if (e.x < 0.05f || e.x > 0.95f) e.speedX = -e.speedX

          if (e.type == 1 && frameCount % 60 == 0 && Random.nextFloat() < 0.6f) {
            bullets.add(Bullet(e.x, e.y + 0.04f, isPlayer = false, vy = 0.015f))
          }

          if (e.y > 1.05f) {
            enemyIterator.remove()
          }
        }

        // 5. Bullet-Enemy Collisions
        for (b in bullets.filter { it.isPlayer }) {
          for (e in enemies) {
            val dist = hypot(b.x - e.x, b.y - e.y)
            val hitRadius = if (e.type == 1) 0.06f else 0.045f
            if (dist < hitRadius) {
              e.health--
              b.y = -99f
              spawnExplosion(b.x, b.y, 4, Color(0xFFFF5252))
              if (e.health <= 0) {
                spawnExplosion(e.x, e.y, 14, if (e.type == 1) Color(0xFF00CEC9) else Color(0xFFFF7675))
                soundManager.playCollisionSound()
                score += if (e.type == 1) 50 else 20
                if (score > wave * 300) {
                  wave++
                  tripleLaserTimer += 40
                }
              }
              break
            }
          }
        }
        enemies.removeAll { it.health <= 0 }
        bullets.removeAll { it.y < -0.1f }

        // 6. Enemy Bullet / Collision with Player
        for (b in bullets.filter { !it.isPlayer }) {
          if (hypot(b.x - playerX, b.y - playerY) < 0.05f) {
            b.y = 99f
            lives--
            soundManager.playLoseSound()
            spawnExplosion(playerX, playerY, 15, Color(0xFFFF3838))
            if (lives <= 0) {
              isGameOver = true
              val dur = ((System.currentTimeMillis() - startTimeMs) / 1000L).coerceAtLeast(1L)
              onGameFinished("spaceshooter", score, GameResultType.GAME_OVER, dur, sessionId)
            }
          }
        }

        for (e in enemies) {
          if (hypot(e.x - playerX, e.y - playerY) < 0.06f) {
            e.health = 0
            lives--
            soundManager.playLoseSound()
            spawnExplosion(playerX, playerY, 18, Color(0xFFFF4757))
            if (lives <= 0) {
              isGameOver = true
              val dur = ((System.currentTimeMillis() - startTimeMs) / 1000L).coerceAtLeast(1L)
              onGameFinished("spaceshooter", score, GameResultType.GAME_OVER, dur, sessionId)
            }
          }
        }

        // 7. Update particles
        val particleIterator = particles.iterator()
        while (particleIterator.hasNext()) {
          val p = particleIterator.next()
          p.x += p.vx
          p.y += p.vy
          p.life -= 0.04f
          if (p.life <= 0f) particleIterator.remove()
        }
      }
      delay(20)
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF050510))
  ) {
    GameTopBar(
      title = "Space Shooter (Wave $wave)",
      score = score,
      lives = lives,
      isPaused = isPaused,
      isMuted = isMuted,
      onBack = onBack,
      onPauseToggle = { isPaused = !isPaused },
      onRestart = { restartGame() },
      onMuteToggle = {
        soundManager.isSoundEnabled = !soundManager.isSoundEnabled
        isMuted = !soundManager.isSoundEnabled
      }
    )

    BoxWithConstraints(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .pointerInput(Unit) {
          detectDragGestures { change, dragAmount ->
            change.consume()
            playerX = (playerX + dragAmount.x / size.width).coerceIn(0.08f, 0.92f)
            playerY = (playerY + dragAmount.y / size.height).coerceIn(0.2f, 0.92f)
          }
        }
        .pointerInput(Unit) {
          detectTapGestures { offset ->
            playerX = (offset.x / size.width).coerceIn(0.08f, 0.92f)
            playerY = (offset.y / size.height).coerceIn(0.2f, 0.92f)
          }
        }
    ) {
      Canvas(modifier = Modifier.fillMaxSize().testTag("space_canvas")) {
        val widthPx = size.width
        val heightPx = size.height

        // Draw starfield
        for (i in 0 until 40) {
          val sx = ((i * 37) % 100) / 100f * widthPx
          val sy = ((i * 73 + frameCount * 2) % 1000) / 1000f * heightPx
          drawCircle(
            color = Color.White.copy(alpha = 0.4f + (i % 5) * 0.1f),
            radius = if (i % 7 == 0) 2.5f else 1.5f,
            center = Offset(sx, sy)
          )
        }

        // Draw bullets
        for (b in bullets) {
          val color = if (b.isPlayer) Color(0xFF00FFCC) else Color(0xFFFF3366)
          drawCircle(
            color = color,
            radius = if (b.isPlayer) 5f else 6f,
            center = Offset(b.x * widthPx, b.y * heightPx)
          )
        }

        // Draw enemies
        for (e in enemies) {
          val ex = e.x * widthPx
          val ey = e.y * heightPx
          val enemyColor = if (e.type == 1) Color(0xFF00CEC9) else Color(0xFFFF5252)
          val enemyPath = Path().apply {
            moveTo(ex, ey + 20f)
            lineTo(ex - 18f, ey - 14f)
            lineTo(ex, ey - 6f)
            lineTo(ex + 18f, ey - 14f)
            close()
          }
          drawPath(enemyPath, enemyColor)

          if (e.type == 1 && e.health < e.maxHealth) {
            val barW = 36f
            val hpRatio = e.health.toFloat() / e.maxHealth
            drawRect(Color.Gray, Offset(ex - barW / 2, ey - 24f), Size(barW, 4f))
            drawRect(Color.Green, Offset(ex - barW / 2, ey - 24f), Size(barW * hpRatio, 4f))
          }
        }

        // Draw player spaceship
        val px = playerX * widthPx
        val py = playerY * heightPx

        // Thruster flame
        val flamePath = Path().apply {
          moveTo(px - 6f, py + 16f)
          lineTo(px, py + 26f + (frameCount % 4) * 3f)
          lineTo(px + 6f, py + 16f)
          close()
        }
        drawPath(flamePath, Color(0xFFFFB142))

        val shipPath = Path().apply {
          moveTo(px, py - 22f)
          lineTo(px - 20f, py + 16f)
          lineTo(px - 8f, py + 10f)
          lineTo(px, py + 14f)
          lineTo(px + 8f, py + 10f)
          lineTo(px + 20f, py + 16f)
          close()
        }
        drawPath(shipPath, Color(0xFF4A90E2))
        drawCircle(Color(0xFF50E3C2), radius = 6f, center = Offset(px, py - 4f))

        // Draw particles
        for (p in particles) {
          drawCircle(
            color = p.color.copy(alpha = p.life.coerceIn(0f, 1f)),
            radius = 3.5f * p.life,
            center = Offset(p.x * widthPx, p.y * heightPx)
          )
        }
      }
    }

    if (isPaused) {
      GamePauseDialog(
        onResume = { isPaused = false },
        onRestart = {
          restartGame()
          isPaused = false
        },
        onExit = onBack
      )
    }

    if (isGameOver) {
      GameOverDialog(
        gameTitle = "Space Shooter",
        resultType = GameResultType.GAME_OVER,
        score = score,
        highScore = score,
        onPlayAgain = { restartGame() },
        onExit = onBack
      )
    }
  }
}
