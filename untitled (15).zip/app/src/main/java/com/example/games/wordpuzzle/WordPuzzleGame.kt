package com.example.games.wordpuzzle

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.core.model.GameResultType
import com.example.games.common.GameOverDialog
import com.example.games.common.GamePauseDialog
import com.example.games.common.GameTopBar
import java.util.UUID

data class WordPuzzleLevel(
  val levelNum: Int,
  val letters: List<Char>,
  val targetWords: List<String>
)

val puzzleLevels = listOf(
  WordPuzzleLevel(1, listOf('G', 'A', 'M', 'E'), listOf("GAME", "MAGE", "MEGA")),
  WordPuzzleLevel(2, listOf('P', 'L', 'A', 'Y'), listOf("PLAY", "LAY", "PAY", "PLY")),
  WordPuzzleLevel(3, listOf('S', 'T', 'A', 'R'), listOf("STAR", "ARTS", "RATS", "TARS")),
  WordPuzzleLevel(4, listOf('B', 'I', 'R', 'D'), listOf("BIRD", "RIB", "BID", "DRIP")),
  WordPuzzleLevel(5, listOf('S', 'M', 'A', 'R', 'T'), listOf("SMART", "STAR", "RAMS", "ARMS", "TRAM"))
)

@Composable
fun WordPuzzleGame(
  onBack: () -> Unit,
  onGameFinished: (gameId: String, score: Int, resultType: GameResultType, duration: Long, sessionId: String) -> Unit
) {
  val context = LocalContext.current
  val soundManager = remember { SoundManager.getInstance(context) }
  var currentLevelIdx by remember { mutableIntStateOf(0) }
  var sessionId by remember { mutableStateOf(UUID.randomUUID().toString()) }
  var startTimeMs by remember { mutableStateOf(System.currentTimeMillis()) }

  val currentLevel = puzzleLevels[currentLevelIdx % puzzleLevels.size]
  val scrambledLetters = remember(currentLevelIdx) { mutableStateListOf<Char>().apply { addAll(currentLevel.letters.shuffled()) } }
  val discoveredWords = remember(currentLevelIdx) { mutableStateListOf<String>() }
  var currentInput by remember { mutableStateOf("") }
  var hintsUsed by remember { mutableIntStateOf(0) }
  var score by remember { mutableIntStateOf(0) }
  var feedbackMsg by remember { mutableStateOf("Form words from the letters below!") }
  var feedbackColor by remember { mutableStateOf(Color(0xFFA4B0BE)) }
  var isPaused by remember { mutableStateOf(false) }
  var isMuted by remember { mutableStateOf(!soundManager.isSoundEnabled) }
  var isGameOver by remember { mutableStateOf(false) }
  var isLevelCleared by remember { mutableStateOf(false) }

  fun restartGame() {
    currentLevelIdx = 0
    score = 0
    hintsUsed = 0
    discoveredWords.clear()
    currentInput = ""
    isGameOver = false
    isLevelCleared = false
    feedbackMsg = "Form words from the letters below!"
    feedbackColor = Color(0xFFA4B0BE)
    startTimeMs = System.currentTimeMillis()
    sessionId = UUID.randomUUID().toString()
  }

  fun nextLevel() {
    if (currentLevelIdx < puzzleLevels.size - 1) {
      currentLevelIdx++
      currentInput = ""
      discoveredWords.clear()
      isLevelCleared = false
      feedbackMsg = "Level ${currentLevelIdx + 1}! Find all words!"
      feedbackColor = Color(0xFF00CEC9)
    } else {
      isGameOver = true
      val dur = ((System.currentTimeMillis() - startTimeMs) / 1000L).coerceAtLeast(1L)
      onGameFinished("wordpuzzle", score, GameResultType.WIN, dur, sessionId)
    }
  }

  fun checkWord() {
    val word = currentInput.uppercase().trim()
    if (word.isEmpty()) return
    soundManager.playButtonClick()

    if (word in discoveredWords) {
      feedbackMsg = "Already found '$word'!"
      feedbackColor = Color(0xFFFFA502)
      currentInput = ""
      return
    }

    if (word in currentLevel.targetWords) {
      discoveredWords.add(word)
      score += word.length * 25
      soundManager.playWinSound()
      feedbackMsg = "🎉 Correct! Found '$word' (+${word.length * 25} pts)!"
      feedbackColor = Color(0xFF2ED573)

      if (discoveredWords.size == currentLevel.targetWords.size) {
        score += 100
        isLevelCleared = true
        soundManager.playWinSound()
      }
    } else {
      feedbackMsg = "Not in the puzzle words list"
      feedbackColor = Color(0xFFFF4757)
      soundManager.playLoseSound()
    }
    currentInput = ""
  }

  fun useHint() {
    val undiscovered = currentLevel.targetWords.filter { it !in discoveredWords }
    if (undiscovered.isNotEmpty()) {
      soundManager.playCardSound()
      val target = undiscovered.first()
      feedbackMsg = "💡 Hint: A word starts with '${target.take(2)}...'"
      feedbackColor = Color(0xFFFFB142)
      hintsUsed++
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F0C20))
  ) {
    GameTopBar(
      title = "Word Puzzle (Lvl ${currentLevel.levelNum})",
      score = score,
      isPaused = isPaused,
      isMuted = isMuted,
      onBack = onBack,
      onPauseToggle = { isPaused = !isPaused },
      onRestart = { restartGame() },
      onMuteToggle = {
        soundManager.isSoundEnabled = !soundManager.isSoundEnabled
        isMuted = !soundManager.isSoundEnabled
      }
    )

    // Target Words Slots Display
    Card(
      colors = CardDefaults.cardColors(containerColor = Color(0xFF18152E)),
      shape = RoundedCornerShape(16.dp),
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Words: ${discoveredWords.size} / ${currentLevel.targetWords.size}", color = Color(0xFFA4B0BE), fontSize = 13.sp)
          Text("Score: $score", fontWeight = FontWeight.Bold, color = Color(0xFFFFB142), fontSize = 13.sp)
        }
        Spacer(modifier = Modifier.height(12.dp))

        // Slots for each word
        Column(
          verticalArrangement = Arrangement.spacedBy(8.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          currentLevel.targetWords.forEach { target ->
            val isFound = target in discoveredWords
            Row(
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              target.forEach { ch ->
                Box(
                  modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isFound) Color(0xFF2ED573) else Color(0xFF241F42))
                    .border(1.dp, if (isFound) Color(0xFF00B894) else Color(0xFF6C5CE7), RoundedCornerShape(8.dp)),
                  contentAlignment = Alignment.Center
                ) {
                  Text(
                    text = if (isFound) ch.toString() else "_",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                  )
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text(feedbackMsg, color = feedbackColor, fontSize = 13.sp, fontWeight = FontWeight.Medium)
      }
    }

    Spacer(modifier = Modifier.weight(1f))

    // Current Word Under Construction
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 24.dp)
        .height(52.dp)
        .border(2.dp, Color(0xFF6C5CE7), RoundedCornerShape(12.dp))
        .background(Color(0xFF1E1B38), RoundedCornerShape(12.dp)),
      contentAlignment = Alignment.Center
    ) {
      Text(
        text = if (currentInput.isEmpty()) "Tap letters to spell" else currentInput,
        fontSize = 22.sp,
        fontWeight = FontWeight.Bold,
        color = if (currentInput.isEmpty()) Color(0xFF718093) else Color.White
      )
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Action Controls (Hint, Shuffle, Clear)
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 24.dp),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Button(
        onClick = { useHint() },
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E2A52)),
        shape = CircleShape,
        modifier = Modifier.testTag("word_hint_btn")
      ) {
        Icon(Icons.Default.Lightbulb, contentDescription = "Hint", tint = Color(0xFFFFB142), modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("Hint", fontSize = 12.sp, color = Color.White)
      }

      Button(
        onClick = { scrambledLetters.shuffle() },
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E2A52)),
        shape = CircleShape,
        modifier = Modifier.testTag("word_shuffle_btn")
      ) {
        Icon(Icons.Default.Shuffle, contentDescription = "Shuffle", tint = Color(0xFF00CEC9), modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("Shuffle", fontSize = 12.sp, color = Color.White)
      }

      Button(
        onClick = { currentInput = "" },
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E2A52)),
        shape = CircleShape,
        modifier = Modifier.testTag("word_clear_btn")
      ) {
        Text("Clear", fontSize = 12.sp, color = Color.White)
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Letter Wheels / Buttons
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp),
      horizontalArrangement = Arrangement.SpaceEvenly
    ) {
      scrambledLetters.forEachIndexed { idx, ch ->
        Box(
          modifier = Modifier
            .size(54.dp)
            .clip(CircleShape)
            .background(Color(0xFF6C5CE7))
            .border(2.dp, Color(0xFFA29BFE), CircleShape)
            .clickable {
              if (currentInput.length < 8) {
                currentInput += ch
                soundManager.playButtonClick()
              }
            }
            .testTag("letter_tile_$idx"),
          contentAlignment = Alignment.Center
        ) {
          Text(ch.toString(), fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Submit Button
    Button(
      onClick = { checkWord() },
      colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00B894)),
      shape = RoundedCornerShape(12.dp),
      modifier = Modifier
        .fillMaxWidth()
        .height(50.dp)
        .padding(horizontal = 24.dp)
        .testTag("word_submit_btn")
    ) {
      Text("SUBMIT WORD", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
    }

    Spacer(modifier = Modifier.height(20.dp))

    // Level Cleared Overlay Dialog
    if (isLevelCleared) {
      androidx.compose.ui.window.Dialog(onDismissRequest = {}) {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1B38)),
          modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
          Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text("🎉 LEVEL CLEARED! 🎉", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFB142))
            Spacer(modifier = Modifier.height(8.dp))
            Text("All words discovered! +100 Bonus", color = Color.White, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(16.dp))
            Button(
              onClick = { nextLevel() },
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00B894)),
              modifier = Modifier.fillMaxWidth().testTag("next_level_btn")
            ) {
              Text(if (currentLevelIdx < puzzleLevels.size - 1) "Next Level ➔" else "Finish Game 🏆")
            }
          }
        }
      }
    }

    if (isPaused) {
      GamePauseDialog(
        onResume = { isPaused = false },
        onRestart = {
          restartGame()
          isPaused = false
        },
        onExit = onBack
      )
    }

    if (isGameOver) {
      GameOverDialog(
        gameTitle = "Word Puzzle",
        resultType = GameResultType.WIN,
        score = score,
        highScore = score,
        onPlayAgain = { restartGame() },
        onExit = onBack
      )
    }
  }
}
