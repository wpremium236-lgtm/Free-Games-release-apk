package com.example.games.colormatch

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.games.common.GameOverDialog
import com.example.games.common.GamePauseDialog
import com.example.games.common.GameTopBar
import kotlinx.coroutines.delay
import kotlin.random.Random

data class ColorOption(val name: String, val color: Color)

val ColorList = listOf(
  ColorOption("RED", Color(0xFFFF5252)),
  ColorOption("BLUE", Color(0xFF00A8FF)),
  ColorOption("GREEN", Color(0xFF2ED573)),
  ColorOption("YELLOW", Color(0xFFFBC531)),
  ColorOption("PURPLE", Color(0xFF9C88FF))
)

@Composable
fun ColorMatchGame(
  onBack: () -> Unit,
  onGameFinished: (score: Int) -> Unit
) {
  val context = LocalContext.current
  val soundManager = remember { SoundManager.getInstance(context) }
  var score by remember { mutableIntStateOf(0) }
  var streak by remember { mutableIntStateOf(0) }
  var highScore by remember { mutableIntStateOf(0) }
  var isPaused by remember { mutableStateOf(false) }
  var isMuted by remember { mutableStateOf(!soundManager.isSoundEnabled) }
  var isGameOver by remember { mutableStateOf(false) }

  var displayedWord by remember { mutableStateOf("RED") }
  var inkColor by remember { mutableStateOf(Color(0xFFFF5252)) }
  var isMatching by remember { mutableStateOf(true) }
  var timerProgress by remember { mutableFloatStateOf(1f) }

  fun nextQuestion() {
    val wordOpt = ColorList.random()
    val match = Random.nextBoolean()
    isMatching = match
    displayedWord = wordOpt.name
    inkColor = if (match) {
      wordOpt.color
    } else {
      ColorList.filter { it.name != wordOpt.name }.random().color
    }
    timerProgress = 1f
  }

  fun resetGame() {
    score = 0
    streak = 0
    isGameOver = false
    nextQuestion()
  }

  remember {
    nextQuestion()
    true
  }

  fun handleAnswer(userSaysMatch: Boolean) {
    if (isGameOver) return
    if (userSaysMatch == isMatching) {
      streak++
      score += 10 + streak * 2
      soundManager.playScoreBeep()
      nextQuestion()
    } else {
      isGameOver = true
      soundManager.playCollisionSound()
      soundManager.playLoseSound()
      onGameFinished(score)
    }
  }

  // Timer countdown loop
  LaunchedEffect(timerProgress, isPaused, isGameOver) {
    if (isPaused || isGameOver) return@LaunchedEffect
    val stepTime = (25 - (streak * 0.5f).toInt()).coerceAtLeast(12).toLong()
    while (timerProgress > 0f && !isPaused && !isGameOver) {
      delay(stepTime)
      timerProgress -= 0.015f
      if (timerProgress <= 0f) {
        isGameOver = true
        soundManager.playLoseSound()
        onGameFinished(score)
        break
      }
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F0C20))
  ) {
    GameTopBar(
      title = "Color Match",
      score = score,
      highScore = highScore,
      isPaused = isPaused,
      isMuted = isMuted,
      onBack = onBack,
      onPauseToggle = { isPaused = !isPaused },
      onRestart = { resetGame() },
      onMuteToggle = {
        isMuted = !isMuted
        soundManager.isSoundEnabled = !isMuted
      }
    )

    // Streak & Timer Bar
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 24.dp, vertical = 12.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text("STREAK: $streak 🔥", color = Color(0xFFFFB142), fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Text("Does text match ink color?", color = Color(0xFFA4B0BE), fontSize = 12.sp)
      }
      Spacer(modifier = Modifier.height(8.dp))
      LinearProgressIndicator(
        progress = { timerProgress.coerceIn(0f, 1f) },
        modifier = Modifier
          .fillMaxWidth()
          .height(8.dp)
          .clip(RoundedCornerShape(4.dp)),
        color = if (timerProgress > 0.3f) Color(0xFF00CEC9) else Color(0xFFFF5252),
        trackColor = Color(0xFF241F42)
      )
    }

    // Main Question Display Card
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .padding(24.dp),
      contentAlignment = Alignment.Center
    ) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(240.dp)
          .clip(RoundedCornerShape(20.dp))
          .background(Color(0xFF18152E))
          .border(2.dp, Color(0xFF3B336A), RoundedCornerShape(20.dp)),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = displayedWord,
          fontSize = 54.sp,
          fontWeight = FontWeight.Black,
          color = inkColor
        )
      }
    }

    // Match / No Match Decision Buttons
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 24.dp, vertical = 24.dp),
      horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      Button(
        onClick = { handleAnswer(false) },
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5252)),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
          .weight(1f)
          .height(58.dp)
          .testTag("color_match_no")
      ) {
        Text("❌ NO MATCH", fontSize = 16.sp, fontWeight = FontWeight.Bold)
      }

      Button(
        onClick = { handleAnswer(true) },
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2ED573)),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
          .weight(1f)
          .height(58.dp)
          .testTag("color_match_yes")
      ) {
        Text("✓ MATCH", fontSize = 16.sp, fontWeight = FontWeight.Bold)
      }
    }
  }

  if (isPaused) {
    GamePauseDialog(
      onResume = { isPaused = false },
      onRestart = { resetGame() },
      onExit = onBack
    )
  }

  if (isGameOver) {
    GameOverDialog(
      isWin = false,
      score = score,
      highScore = highScore,
      onPlayAgain = { resetGame() },
      onExit = onBack
    )
  }
}
