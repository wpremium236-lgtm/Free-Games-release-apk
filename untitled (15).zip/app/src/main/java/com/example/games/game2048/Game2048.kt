package com.example.games.game2048

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.core.model.GameResultType
import com.example.games.common.GameOverDialog
import com.example.games.common.GamePauseDialog
import com.example.games.common.GameTopBar
import java.util.UUID
import kotlin.math.abs
import kotlin.random.Random

@Composable
fun Game2048(
  onBack: () -> Unit,
  onGameFinished: (gameId: String, score: Int, resultType: GameResultType, duration: Long, sessionId: String) -> Unit
) {
  val context = LocalContext.current
  val soundManager = remember { SoundManager.getInstance(context) }
  var sessionId by remember { mutableStateOf(UUID.randomUUID().toString()) }
  var startTimeMs by remember { mutableStateOf(System.currentTimeMillis()) }
  var hasSubmittedSession by remember { mutableStateOf(false) }

  var board by remember {
    mutableStateOf(Array(4) { IntArray(4) })
  }
  var previousBoard by remember { mutableStateOf<Array<IntArray>?>(null) }
  var previousScore by remember { mutableIntStateOf(0) }
  var score by remember { mutableIntStateOf(0) }
  var highScore by remember { mutableIntStateOf(0) }
  var isPaused by remember { mutableStateOf(false) }
  var isMuted by remember { mutableStateOf(!soundManager.isSoundEnabled) }
  var isGameOver by remember { mutableStateOf(false) }
  var hasWon by remember { mutableStateOf(false) }

  fun triggerGameFinished(resultType: GameResultType, finalScore: Int) {
    if (!hasSubmittedSession) {
      hasSubmittedSession = true
      val duration = ((System.currentTimeMillis() - startTimeMs) / 1000L).coerceAtLeast(1L)
      onGameFinished("game2048", finalScore, resultType, duration, sessionId)
    }
  }

  fun spawnTile(targetBoard: Array<IntArray>) {
    val emptySlots = mutableListOf<Pair<Int, Int>>()
    for (r in 0..3) {
      for (c in 0..3) {
        if (targetBoard[r][c] == 0) emptySlots.add(Pair(r, c))
      }
    }
    if (emptySlots.isNotEmpty()) {
      val (r, c) = emptySlots.random()
      targetBoard[r][c] = if (Random.nextFloat() < 0.9f) 2 else 4
    }
  }

  fun initBoard() {
    val newB = Array(4) { IntArray(4) }
    spawnTile(newB)
    spawnTile(newB)
    board = newB
    previousBoard = null
    score = 0
    isGameOver = false
    hasWon = false
    sessionId = UUID.randomUUID().toString()
    startTimeMs = System.currentTimeMillis()
    hasSubmittedSession = false
  }

  remember {
    initBoard()
    true
  }

  fun canMove(b: Array<IntArray>): Boolean {
    for (r in 0..3) {
      for (c in 0..3) {
        if (b[r][c] == 0) return true
        if (r < 3 && b[r][c] == b[r + 1][c]) return true
        if (c < 3 && b[r][c] == b[r][c + 1]) return true
      }
    }
    return false
  }

  fun slideRow(row: IntArray): Pair<IntArray, Int> {
    val nonZero = row.filter { it != 0 }.toMutableList()
    var pointsEarned = 0
    val result = mutableListOf<Int>()
    var i = 0
    while (i < nonZero.size) {
      if (i + 1 < nonZero.size && nonZero[i] == nonZero[i + 1]) {
        val merged = nonZero[i] * 2
        result.add(merged)
        pointsEarned += merged
        if (merged == 2048 && !hasWon) hasWon = true
        i += 2
      } else {
        result.add(nonZero[i])
        i++
      }
    }
    while (result.size < 4) result.add(0)
    return Pair(result.toIntArray(), pointsEarned)
  }

  fun move(dir: String) {
    if (isGameOver) return
    val backup = Array(4) { r -> board[r].clone() }
    val newBoard = Array(4) { r -> board[r].clone() }
    var points = 0
    var moved = false

    when (dir) {
      "LEFT" -> {
        for (r in 0..3) {
          val (slid, pts) = slideRow(newBoard[r])
          points += pts
          if (!newBoard[r].contentEquals(slid)) moved = true
          newBoard[r] = slid
        }
      }
      "RIGHT" -> {
        for (r in 0..3) {
          val reversed = newBoard[r].reversedArray()
          val (slid, pts) = slideRow(reversed)
          val unreversed = slid.reversedArray()
          points += pts
          if (!newBoard[r].contentEquals(unreversed)) moved = true
          newBoard[r] = unreversed
        }
      }
      "UP" -> {
        for (c in 0..3) {
          val colArr = IntArray(4) { r -> newBoard[r][c] }
          val (slid, pts) = slideRow(colArr)
          points += pts
          for (r in 0..3) {
            if (newBoard[r][c] != slid[r]) moved = true
            newBoard[r][c] = slid[r]
          }
        }
      }
      "DOWN" -> {
        for (c in 0..3) {
          val colArr = IntArray(4) { r -> newBoard[3 - r][c] }
          val (slid, pts) = slideRow(colArr)
          points += pts
          for (r in 0..3) {
            if (newBoard[3 - r][c] != slid[r]) moved = true
            newBoard[3 - r][c] = slid[r]
          }
        }
      }
    }

    if (moved) {
      previousBoard = backup
      previousScore = score
      score += points
      soundManager.playButtonClick()
      if (points > 0) soundManager.playScoreBeep()

      val reached2048 = newBoard.any { row -> row.any { it >= 2048 } }
      if (reached2048 && !hasWon) {
        hasWon = true
        soundManager.playWinSound()
      }

      spawnTile(newBoard)
      board = newBoard

      if (!canMove(newBoard)) {
        isGameOver = true
        if (!hasWon) soundManager.playLoseSound()
        val resultType = if (hasWon) GameResultType.WIN else GameResultType.GAME_OVER
        triggerGameFinished(resultType, score)
      }
    }
  }

  fun undo() {
    previousBoard?.let {
      board = it
      score = previousScore
      previousBoard = null
      soundManager.playButtonClick()
    }
  }

  fun getTileColor(value: Int): Pair<Color, Color> {
    return when (value) {
      0 -> Pair(Color(0xFF241F42), Color.Transparent)
      2 -> Pair(Color(0xFFEEE4DA), Color(0xFF776E65))
      4 -> Pair(Color(0xFFEDE0C8), Color(0xFF776E65))
      8 -> Pair(Color(0xFFF2B179), Color.White)
      16 -> Pair(Color(0xFFF59563), Color.White)
      32 -> Pair(Color(0xFFF67C5F), Color.White)
      64 -> Pair(Color(0xFFF65E3B), Color.White)
      128 -> Pair(Color(0xFFEDCF72), Color.White)
      256 -> Pair(Color(0xFFEDCC61), Color.White)
      512 -> Pair(Color(0xFFEDC850), Color.White)
      1024 -> Pair(Color(0xFFEDC53F), Color.White)
      2048 -> Pair(Color(0xFFEDC22E), Color.White)
      else -> Pair(Color(0xFF3C3A32), Color.White)
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F0C20))
  ) {
    GameTopBar(
      title = "2048",
      score = score,
      highScore = highScore,
      isPaused = isPaused,
      isMuted = isMuted,
      onBack = onBack,
      onPauseToggle = { isPaused = !isPaused },
      onRestart = { initBoard() },
      onMuteToggle = {
        isMuted = !isMuted
        soundManager.isSoundEnabled = !isMuted
      }
    )

    // Undo & Top Info
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text("Join identical numbers to get 2048!", fontSize = 12.sp, color = Color(0xFFA4B0BE))
      Button(
        onClick = { undo() },
        enabled = previousBoard != null,
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF241F42)),
        modifier = Modifier.testTag("2048_undo_btn")
      ) {
        Icon(Icons.Default.Undo, contentDescription = "Undo", tint = if (previousBoard != null) Color.White else Color.Gray, modifier = Modifier.size(16.dp))
        Text(" Undo", color = if (previousBoard != null) Color.White else Color.Gray, fontSize = 12.sp)
      }
    }

    // 4x4 Grid Board with Swipe Gestures
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .padding(16.dp),
      contentAlignment = Alignment.Center
    ) {
      BoxWithConstraints(
        modifier = Modifier
          .aspectRatio(1f)
          .clip(RoundedCornerShape(16.dp))
          .background(Color(0xFF18152E))
          .padding(8.dp)
          .pointerInput(Unit) {
            detectDragGestures { change, dragAmount ->
              change.consume()
              val (dx, dy) = dragAmount
              if (abs(dx) > abs(dy)) {
                if (dx > 30) move("RIGHT")
                else if (dx < -30) move("LEFT")
              } else {
                if (dy > 30) move("DOWN")
                else if (dy < -30) move("UP")
              }
            }
          }
      ) {
        Column(modifier = Modifier.fillMaxSize()) {
          for (r in 0..3) {
            Row(modifier = Modifier.weight(1f)) {
              for (c in 0..3) {
                val value = board[r][c]
                val (bgColor, textColor) = getTileColor(value)
                Box(
                  modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .padding(4.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(bgColor)
                    .border(1.dp, Color(0xFF3B336A), RoundedCornerShape(10.dp)),
                  contentAlignment = Alignment.Center
                ) {
                  if (value > 0) {
                    Text(
                      text = "$value",
                      fontSize = when {
                        value >= 1024 -> 18.sp
                        value >= 128 -> 22.sp
                        else -> 26.sp
                      },
                      fontWeight = FontWeight.Bold,
                      color = textColor
                    )
                  }
                }
              }
            }
          }
        }
      }
    }

    // On-screen Directional Controls
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 16.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      IconButton(
        onClick = { move("UP") },
        colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFF241F42)),
        modifier = Modifier.size(48.dp).testTag("2048_up")
      ) {
        Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Up", tint = Color.White)
      }
      Row(horizontalArrangement = Arrangement.spacedBy(36.dp)) {
        IconButton(
          onClick = { move("LEFT") },
          colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFF241F42)),
          modifier = Modifier.size(48.dp).testTag("2048_left")
        ) {
          Icon(Icons.Default.KeyboardArrowLeft, contentDescription = "Left", tint = Color.White)
        }
        IconButton(
          onClick = { move("RIGHT") },
          colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFF241F42)),
          modifier = Modifier.size(48.dp).testTag("2048_right")
        ) {
          Icon(Icons.Default.KeyboardArrowRight, contentDescription = "Right", tint = Color.White)
        }
      }
      IconButton(
        onClick = { move("DOWN") },
        colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFF241F42)),
        modifier = Modifier.size(48.dp).testTag("2048_down")
      ) {
        Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Down", tint = Color.White)
      }
    }
  }

  if (isPaused) {
    GamePauseDialog(
      onResume = { isPaused = false },
      onRestart = { initBoard() },
      onExit = onBack
    )
  }

  if (isGameOver) {
    GameOverDialog(
      gameTitle = "2048",
      resultType = if (hasWon) GameResultType.WIN else GameResultType.GAME_OVER,
      score = score,
      highScore = highScore,
      onPlayAgain = { initBoard() },
      onExit = onBack
    )
  }
}
