package com.example.games.brickbreaker

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.games.common.GameOverDialog
import com.example.games.common.GamePauseDialog
import com.example.games.common.GameTopBar
import kotlinx.coroutines.delay
import kotlin.math.abs

data class Brick(
  val r: Int, val c: Int,
  var health: Int,
  val color: Color
)

@Composable
fun BrickBreakerGame(
  onBack: () -> Unit,
  onGameFinished: (score: Int) -> Unit
) {
  val context = LocalContext.current
  val soundManager = remember { SoundManager.getInstance(context) }
  var paddleX by remember { mutableFloatStateOf(0.5f) }
  val paddleWidth = 0.22f
  var ballX by remember { mutableFloatStateOf(0.5f) }
  var ballY by remember { mutableFloatStateOf(0.85f) }
  var ballVx by remember { mutableFloatStateOf(0.012f) }
  var ballVy by remember { mutableFloatStateOf(-0.016f) }
  var lives by remember { mutableIntStateOf(3) }
  var score by remember { mutableIntStateOf(0) }
  var highScore by remember { mutableIntStateOf(0) }
  var isPaused by remember { mutableStateOf(false) }
  var isMuted by remember { mutableStateOf(!soundManager.isSoundEnabled) }
  var isGameOver by remember { mutableStateOf(false) }
  var hasWon by remember { mutableStateOf(false) }
  var ballLaunched by remember { mutableStateOf(false) }

  val brickRows = 5
  val brickCols = 7
  val bricks = remember {
    mutableStateListOf<Brick>().apply {
      val colors = listOf(Color(0xFFFF5252), Color(0xFFFFB142), Color(0xFF2ED573), Color(0xFF00CEC9), Color(0xFF9C88FF))
      for (r in 0 until brickRows) {
        for (c in 0 until brickCols) {
          add(Brick(r, c, health = if (r == 0) 2 else 1, color = colors[r]))
        }
      }
    }
  }

  fun resetBall() {
    ballX = paddleX
    ballY = 0.85f
    ballVx = if (paddleX > 0.5f) -0.012f else 0.012f
    ballVy = -0.016f
    ballLaunched = false
  }

  fun resetGame() {
    bricks.clear()
    val colors = listOf(Color(0xFFFF5252), Color(0xFFFFB142), Color(0xFF2ED573), Color(0xFF00CEC9), Color(0xFF9C88FF))
    for (r in 0 until brickRows) {
      for (c in 0 until brickCols) {
        bricks.add(Brick(r, c, health = if (r == 0) 2 else 1, color = colors[r]))
      }
    }
    lives = 3
    score = 0
    paddleX = 0.5f
    resetBall()
    isGameOver = false
    hasWon = false
  }

  // Physics game loop
  LaunchedEffect(ballLaunched, isPaused, isGameOver) {
    if (!ballLaunched || isPaused || isGameOver) return@LaunchedEffect
    val brickW = 1f / brickCols
    val brickH = 0.04f

    while (ballLaunched && !isPaused && !isGameOver) {
      delay(16)
      ballX += ballVx
      ballY += ballVy

      // Wall bounce
      if (ballX <= 0.02f) {
        ballX = 0.02f
        ballVx = abs(ballVx)
        soundManager.playButtonClick()
      } else if (ballX >= 0.98f) {
        ballX = 0.98f
        ballVx = -abs(ballVx)
        soundManager.playButtonClick()
      }

      // Ceiling bounce
      if (ballY <= 0.02f) {
        ballY = 0.02f
        ballVy = abs(ballVy)
        soundManager.playButtonClick()
      }

      // Paddle collision (paddle at y = 0.88f)
      if (ballY in 0.86f..0.89f && ballVy > 0) {
        val hitOffset = (ballX - paddleX) / (paddleWidth / 2)
        if (abs(hitOffset) <= 1.1f) {
          ballVy = -abs(ballVy)
          ballVx = hitOffset * 0.018f
          soundManager.playMoveSound()
        }
      }

      // Brick collisions (bricks top = 0.10f)
      val bTopOffset = 0.10f
      val activeBricks = bricks.filter { it.health > 0 }
      for (b in activeBricks) {
        val bxMin = b.c * brickW
        val bxMax = bxMin + brickW
        val byMin = bTopOffset + b.r * brickH
        val byMax = byMin + brickH
        if (ballX in bxMin..bxMax && ballY in byMin..byMax) {
          b.health--
          ballVy = -ballVy
          score += 20
          soundManager.playCollisionSound()
          soundManager.playScoreBeep()

          // Check win
          if (bricks.none { it.health > 0 }) {
            hasWon = true
            isGameOver = true
            soundManager.playWinSound()
            onGameFinished(score + 1000)
            break
          }
          break
        }
      }

      // Ball fell to bottom
      if (ballY > 0.98f) {
        lives--
        soundManager.playLoseSound()
        if (lives <= 0) {
          isGameOver = true
          onGameFinished(score)
        } else {
          resetBall()
        }
      }
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F0C20))
  ) {
    GameTopBar(
      title = "Brick Breaker",
      score = score,
      highScore = highScore,
      lives = lives,
      isPaused = isPaused,
      isMuted = isMuted,
      onBack = onBack,
      onPauseToggle = { isPaused = !isPaused },
      onRestart = { resetGame() },
      onMuteToggle = {
        isMuted = !isMuted
        soundManager.isSoundEnabled = !isMuted
      }
    )

    // Canvas Playfield
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .padding(12.dp),
      contentAlignment = Alignment.Center
    ) {
      BoxWithConstraints(
        modifier = Modifier
          .fillMaxSize()
          .clip(RoundedCornerShape(16.dp))
          .background(Color(0xFF141128))
          .pointerInput(Unit) {
            detectDragGestures(
              onDrag = { change, dragAmount ->
                change.consume()
                paddleX = (paddleX + dragAmount.x / size.width).coerceIn(paddleWidth / 2, 1f - paddleWidth / 2)
                if (!ballLaunched) {
                  ballX = paddleX
                }
              },
              onDragEnd = {
                if (!ballLaunched) ballLaunched = true
              }
            )
          }
          .testTag("brick_breaker_canvas")
      ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
          val w = size.width
          val h = size.height

          // Draw Bricks
          val brickW = w / brickCols
          val brickH = h * 0.04f
          val bTopOffset = h * 0.10f
          bricks.forEach { b ->
            if (b.health > 0) {
              drawRoundRect(
                color = b.color,
                topLeft = Offset(b.c * brickW + 2f, bTopOffset + b.r * brickH + 2f),
                size = Size(brickW - 4f, brickH - 4f),
                cornerRadius = CornerRadius(4f)
              )
            }
          }

          // Draw Paddle
          val pw = paddleWidth * w
          val ph = 16f
          val px = (paddleX * w) - pw / 2
          val py = h * 0.88f
          drawRoundRect(
            color = Color(0xFF00CEC9),
            topLeft = Offset(px, py),
            size = Size(pw, ph),
            cornerRadius = CornerRadius(8f)
          )

          // Draw Ball
          val ballRadius = 8f
          drawCircle(
            color = Color(0xFFFFB142),
            radius = ballRadius,
            center = Offset(ballX * w, ballY * h)
          )
        }
      }
    }

    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp, vertical = 8.dp),
      horizontalArrangement = Arrangement.Center
    ) {
      Text(
        if (!ballLaunched) "Drag paddle to launch ball" else "Keep the ball in play!",
        fontSize = 12.sp,
        color = Color(0xFFA4B0BE)
      )
    }
  }

  if (isPaused) {
    GamePauseDialog(
      onResume = { isPaused = false },
      onRestart = { resetGame() },
      onExit = onBack
    )
  }

  if (isGameOver) {
    GameOverDialog(
      isWin = hasWon,
      score = score,
      highScore = highScore,
      onPlayAgain = { resetGame() },
      onExit = onBack
    )
  }
}
