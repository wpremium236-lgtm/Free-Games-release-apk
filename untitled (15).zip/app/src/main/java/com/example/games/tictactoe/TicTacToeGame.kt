package com.example.games.tictactoe

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.core.model.GameDifficulty
import com.example.core.model.GameResultType
import com.example.games.common.GameOverDialog
import com.example.games.common.GamePauseDialog
import com.example.games.common.GameTopBar
import kotlinx.coroutines.delay
import java.util.UUID
import kotlin.random.Random

enum class Mark { EMPTY, X, O }

@Composable
fun TicTacToeGame(
  onBack: () -> Unit,
  onGameFinished: (gameId: String, score: Int, resultType: GameResultType, duration: Long, sessionId: String) -> Unit
) {
  val context = LocalContext.current
  val soundManager = remember { SoundManager.getInstance(context) }
  var sessionId by remember { mutableStateOf(UUID.randomUUID().toString()) }
  var startTimeMs by remember { mutableStateOf(System.currentTimeMillis()) }
  var hasSubmittedSession by remember { mutableStateOf(false) }
  var finalResultType by remember { mutableStateOf(GameResultType.GAME_OVER) }
  var finalScore by remember { mutableIntStateOf(0) }

  val board = remember { mutableStateListOf(*Array(9) { Mark.EMPTY }) }
  var currentTurn by remember { mutableStateOf(Mark.X) }
  var isAiMode by remember { mutableStateOf(true) }
  var difficulty by remember { mutableStateOf(GameDifficulty.HARD) }
  var xScore by remember { mutableIntStateOf(0) }
  var oScore by remember { mutableIntStateOf(0) }
  var drawScore by remember { mutableIntStateOf(0) }
  var winner by remember { mutableStateOf<Mark?>(null) }
  var winningIndices by remember { mutableStateOf<List<Int>>(emptyList()) }
  var isDraw by remember { mutableStateOf(false) }
  var isPaused by remember { mutableStateOf(false) }
  var isMuted by remember { mutableStateOf(!soundManager.isSoundEnabled) }
  var showGameOverDialog by remember { mutableStateOf(false) }

  fun triggerGameFinished(resultType: GameResultType, score: Int) {
    if (!hasSubmittedSession) {
      hasSubmittedSession = true
      finalResultType = resultType
      finalScore = score
      val duration = ((System.currentTimeMillis() - startTimeMs) / 1000L).coerceAtLeast(1L)
      onGameFinished("tictactoe", score, resultType, duration, sessionId)
    }
  }

  val winPatterns = listOf(
    listOf(0, 1, 2), listOf(3, 4, 5), listOf(6, 7, 8),
    listOf(0, 3, 6), listOf(1, 4, 7), listOf(2, 5, 8),
    listOf(0, 4, 8), listOf(2, 4, 6)
  )

  fun checkWinner(): Pair<Mark?, List<Int>> {
    for (p in winPatterns) {
      val a = board[p[0]]
      val b = board[p[1]]
      val c = board[p[2]]
      if (a != Mark.EMPTY && a == b && b == c) {
        return Pair(a, p)
      }
    }
    return Pair(null, emptyList())
  }

  fun resetBoard() {
    for (i in 0..8) board[i] = Mark.EMPTY
    winner = null
    winningIndices = emptyList()
    isDraw = false
    currentTurn = Mark.X
    showGameOverDialog = false
    sessionId = UUID.randomUUID().toString()
    startTimeMs = System.currentTimeMillis()
    hasSubmittedSession = false
  }

  fun minimax(b: MutableList<Mark>, isMaximizing: Boolean): Int {
    for (p in winPatterns) {
      if (b[p[0]] != Mark.EMPTY && b[p[0]] == b[p[1]] && b[p[1]] == b[p[2]]) {
        return if (b[p[0]] == Mark.O) 10 else -10
      }
    }
    if (b.none { it == Mark.EMPTY }) return 0

    return if (isMaximizing) {
      var best = -1000
      for (i in 0..8) {
        if (b[i] == Mark.EMPTY) {
          b[i] = Mark.O
          best = maxOf(best, minimax(b, false))
          b[i] = Mark.EMPTY
        }
      }
      best
    } else {
      var best = 1000
      for (i in 0..8) {
        if (b[i] == Mark.EMPTY) {
          b[i] = Mark.X
          best = minOf(best, minimax(b, true))
          b[i] = Mark.EMPTY
        }
      }
      best
    }
  }

  fun findBestMove(): Int {
    val emptyIndices = board.indices.filter { board[it] == Mark.EMPTY }
    if (emptyIndices.isEmpty()) return -1

    when (difficulty) {
      GameDifficulty.EASY -> return emptyIndices.random()
      GameDifficulty.MEDIUM -> {
        if (Random.nextBoolean()) return emptyIndices.random()
      }
      GameDifficulty.HARD -> {}
    }

    var bestVal = -1000
    var bestMove = emptyIndices.first()
    val bCopy = board.toMutableList()
    for (i in emptyIndices) {
      bCopy[i] = Mark.O
      val moveVal = minimax(bCopy, false)
      bCopy[i] = Mark.EMPTY
      if (moveVal > bestVal) {
        bestMove = i
        bestVal = moveVal
      }
    }
    return bestMove
  }

  fun onCellClicked(index: Int) {
    if (board[index] != Mark.EMPTY || winner != null || isDraw) return
    if (isAiMode && currentTurn == Mark.O) return

    board[index] = currentTurn
    soundManager.playButtonClick()
    val (w, p) = checkWinner()
    if (w != null) {
      winner = w
      winningIndices = p
      soundManager.playWinSound()
      if (w == Mark.X) xScore++ else oScore++
      val resType = if (w == Mark.X) GameResultType.WIN else GameResultType.LOSS
      val s = if (w == Mark.X) 100 else 0
      triggerGameFinished(resType, s)
      showGameOverDialog = true
    } else if (board.none { it == Mark.EMPTY }) {
      isDraw = true
      drawScore++
      soundManager.playScoreBeep()
      triggerGameFinished(GameResultType.DRAW, 50)
      showGameOverDialog = true
    } else {
      currentTurn = if (currentTurn == Mark.X) Mark.O else Mark.X
    }
  }

  // AI turn
  LaunchedEffect(currentTurn, isAiMode, winner, isDraw) {
    if (isAiMode && currentTurn == Mark.O && winner == null && !isDraw) {
      delay(400)
      val move = findBestMove()
      if (move in 0..8) {
        board[move] = Mark.O
        soundManager.playButtonClick()
        val (w, p) = checkWinner()
        if (w != null) {
          winner = w
          winningIndices = p
          soundManager.playLoseSound()
          oScore++
          val resType = if (w == Mark.X) GameResultType.WIN else GameResultType.LOSS
          val s = if (w == Mark.X) 100 else 0
          triggerGameFinished(resType, s)
          showGameOverDialog = true
        } else if (board.none { it == Mark.EMPTY }) {
          isDraw = true
          drawScore++
          soundManager.playScoreBeep()
          triggerGameFinished(GameResultType.DRAW, 50)
          showGameOverDialog = true
        } else {
          currentTurn = Mark.X
        }
      }
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F0C20))
  ) {
    GameTopBar(
      title = "Tic Tac Toe",
      score = xScore,
      highScore = xScore,
      isPaused = isPaused,
      isMuted = isMuted,
      onBack = onBack,
      onPauseToggle = { isPaused = !isPaused },
      onRestart = { resetBoard() },
      onMuteToggle = {
        isMuted = !isMuted
        soundManager.isSoundEnabled = !isMuted
      }
    )

    // Game Mode & Difficulty bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 8.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row {
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isAiMode) Color(0xFF6C5CE7) else Color(0xFF1E1B38))
            .clickable {
              isAiMode = true
              resetBoard()
            }
            .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
          Text("vs AI", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.width(6.dp))
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (!isAiMode) Color(0xFF6C5CE7) else Color(0xFF1E1B38))
            .clickable {
              isAiMode = false
              resetBoard()
            }
            .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
          Text("2 Players", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
      }

      if (isAiMode) {
        Row {
          listOf(GameDifficulty.EASY, GameDifficulty.MEDIUM, GameDifficulty.HARD).forEach { diff ->
            Text(
              text = diff.labelEn,
              fontSize = 11.sp,
              color = if (difficulty == diff) Color(0xFF00CEC9) else Color(0xFFA4B0BE),
              fontWeight = if (difficulty == diff) FontWeight.Bold else FontWeight.Normal,
              modifier = Modifier
                .padding(horizontal = 4.dp)
                .clickable { difficulty = diff }
            )
          }
        }
      }
    }

    // Score Board
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 8.dp),
      horizontalArrangement = Arrangement.SpaceEvenly
    ) {
      Card(
        colors = CardDefaults.cardColors(containerColor = if (currentTurn == Mark.X) Color(0xFF00A8FF).copy(alpha = 0.2f) else Color(0xFF18152E)),
        shape = RoundedCornerShape(10.dp)
      ) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
          Text("Player X", color = Color(0xFF00A8FF), fontWeight = FontWeight.Bold, fontSize = 12.sp)
          Text("$xScore", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
      }
      Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF18152E)),
        shape = RoundedCornerShape(10.dp)
      ) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
          Text("Draws", color = Color(0xFFA4B0BE), fontWeight = FontWeight.Bold, fontSize = 12.sp)
          Text("$drawScore", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
      }
      Card(
        colors = CardDefaults.cardColors(containerColor = if (currentTurn == Mark.O) Color(0xFFFF5252).copy(alpha = 0.2f) else Color(0xFF18152E)),
        shape = RoundedCornerShape(10.dp)
      ) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
          Text(if (isAiMode) "AI (O)" else "Player O", color = Color(0xFFFF5252), fontWeight = FontWeight.Bold, fontSize = 12.sp)
          Text("$oScore", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
      }
    }

    // 3x3 Grid
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .padding(24.dp),
      contentAlignment = Alignment.Center
    ) {
      BoxWithConstraints(
        modifier = Modifier
          .aspectRatio(1f)
          .clip(RoundedCornerShape(16.dp))
          .background(Color(0xFF18152E))
          .padding(8.dp)
      ) {
        Column(modifier = Modifier.fillMaxSize()) {
          for (row in 0..2) {
            Row(modifier = Modifier.weight(1f)) {
              for (col in 0..2) {
                val index = row * 3 + col
                val isWinCell = winningIndices.contains(index)
                Box(
                  modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .padding(4.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                      if (isWinCell) Color(0xFF2ED573).copy(alpha = 0.35f)
                      else Color(0xFF241F42)
                    )
                    .border(
                      1.dp,
                      if (isWinCell) Color(0xFF2ED573) else Color(0xFF3B336A),
                      RoundedCornerShape(12.dp)
                    )
                    .clickable(enabled = board[index] == Mark.EMPTY && winner == null && !isDraw) {
                      onCellClicked(index)
                    }
                    .testTag("ttt_cell_$index"),
                  contentAlignment = Alignment.Center
                ) {
                  Text(
                    text = when (board[index]) {
                      Mark.X -> "X"
                      Mark.O -> "O"
                      Mark.EMPTY -> ""
                    },
                    fontSize = 38.sp,
                    fontWeight = FontWeight.Bold,
                    color = when (board[index]) {
                      Mark.X -> Color(0xFF00A8FF)
                      Mark.O -> Color(0xFFFF5252)
                      Mark.EMPTY -> Color.Transparent
                    }
                  )
                }
              }
            }
          }
        }
      }
    }

    // Status / Next round button
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      contentAlignment = Alignment.Center
    ) {
      Button(
        onClick = { resetBoard() },
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6C5CE7)),
        modifier = Modifier.fillMaxWidth(0.6f).testTag("ttt_reset_btn")
      ) {
        Text("New Match", fontWeight = FontWeight.Bold)
      }
    }
  }

  if (isPaused) {
    GamePauseDialog(
      onResume = { isPaused = false },
      onRestart = { resetBoard() },
      onExit = onBack
    )
  }

  if (showGameOverDialog) {
    GameOverDialog(
      gameTitle = "Tic Tac Toe",
      resultType = finalResultType,
      score = finalScore,
      highScore = xScore * 100,
      onPlayAgain = { resetBoard() },
      onExit = onBack
    )
  }
}
