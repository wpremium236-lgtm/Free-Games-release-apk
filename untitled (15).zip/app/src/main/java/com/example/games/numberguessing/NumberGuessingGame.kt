package com.example.games.numberguessing

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.core.model.GameDifficulty
import com.example.core.model.GameResultType
import com.example.games.common.GameOverDialog
import com.example.games.common.GamePauseDialog
import com.example.games.common.GameTopBar
import java.util.UUID
import kotlin.math.abs
import kotlin.random.Random

data class GuessEntry(
  val number: Int,
  val result: String, // "HIGH", "LOW", "CORRECT"
  val diff: Int
)

@Composable
fun NumberGuessingGame(
  onBack: () -> Unit,
  onGameFinished: (gameId: String, score: Int, resultType: GameResultType, duration: Long, sessionId: String) -> Unit
) {
  val context = LocalContext.current
  val soundManager = remember { SoundManager.getInstance(context) }
  var difficulty by remember { mutableStateOf(GameDifficulty.MEDIUM) }
  var sessionId by remember { mutableStateOf(UUID.randomUUID().toString()) }
  var startTimeMs by remember { mutableStateOf(System.currentTimeMillis()) }

  val maxRange = when (difficulty) {
    GameDifficulty.EASY -> 50
    GameDifficulty.MEDIUM -> 100
    GameDifficulty.HARD -> 500
  }

  val totalAttempts = when (difficulty) {
    GameDifficulty.EASY -> 10
    GameDifficulty.MEDIUM -> 7
    GameDifficulty.HARD -> 10
  }

  var secretNumber by remember(difficulty) { mutableIntStateOf(Random.nextInt(1, maxRange + 1)) }
  var currentInput by remember { mutableStateOf("") }
  var attemptsLeft by remember(difficulty) { mutableIntStateOf(totalAttempts) }
  var lowerBound by remember(difficulty) { mutableIntStateOf(1) }
  var upperBound by remember(difficulty) { mutableIntStateOf(maxRange) }
  var hintMessage by remember { mutableStateOf("Guess a number between 1 and $maxRange") }
  var tempIndicator by remember { mutableStateOf("Neutral") }
  var tempColor by remember { mutableStateOf(Color(0xFF74B9FF)) }
  val history = remember { mutableStateListOf<GuessEntry>() }
  var isGameOver by remember { mutableStateOf(false) }
  var isWin by remember { mutableStateOf(false) }
  var isPaused by remember { mutableStateOf(false) }
  var isMuted by remember { mutableStateOf(!soundManager.isSoundEnabled) }
  var score by remember { mutableIntStateOf(0) }

  fun restartGame() {
    secretNumber = Random.nextInt(1, maxRange + 1)
    currentInput = ""
    attemptsLeft = totalAttempts
    lowerBound = 1
    upperBound = maxRange
    hintMessage = "Guess a number between 1 and $maxRange"
    tempIndicator = "Neutral"
    tempColor = Color(0xFF74B9FF)
    history.clear()
    isGameOver = false
    isWin = false
    score = 0
    startTimeMs = System.currentTimeMillis()
    sessionId = UUID.randomUUID().toString()
  }

  fun submitGuess() {
    val guess = currentInput.toIntOrNull() ?: return
    if (guess < 1 || guess > maxRange) {
      hintMessage = "Number must be between 1 and $maxRange!"
      return
    }

    soundManager.playButtonClick()
    attemptsLeft--
    val diff = abs(guess - secretNumber)

    if (guess == secretNumber) {
      isWin = true
      isGameOver = true
      val remainingMultiplier = (attemptsLeft + 1) * 20
      val diffBonus = when (difficulty) {
        GameDifficulty.EASY -> 50
        GameDifficulty.MEDIUM -> 100
        GameDifficulty.HARD -> 250
      }
      score = diffBonus + remainingMultiplier
      hintMessage = "🎉 BINGO! You guessed the secret number $secretNumber!"
      soundManager.playWinSound()
      history.add(0, GuessEntry(guess, "CORRECT", 0))
      val dur = ((System.currentTimeMillis() - startTimeMs) / 1000L).coerceAtLeast(1L)
      onGameFinished("numberguessing", score, GameResultType.WIN, dur, sessionId)
      return
    }

    if (guess > secretNumber) {
      hintMessage = "▼ Too HIGH! The number is smaller than $guess."
      upperBound = minOf(upperBound, guess - 1)
      history.add(0, GuessEntry(guess, "HIGH", diff))
    } else {
      hintMessage = "▲ Too LOW! The number is bigger than $guess."
      lowerBound = maxOf(lowerBound, guess + 1)
      history.add(0, GuessEntry(guess, "LOW", diff))
    }

    val percentDiff = diff.toFloat() / maxRange
    when {
      percentDiff <= 0.05f -> {
        tempIndicator = "🔥 Boiling Hot! (Extremely Close!)"
        tempColor = Color(0xFFFF4757)
      }
      percentDiff <= 0.15f -> {
        tempIndicator = "☀️ Warm (Getting closer)"
        tempColor = Color(0xFFFFA502)
      }
      percentDiff <= 0.35f -> {
        tempIndicator = "❄️ Chilly (Quite far)"
        tempColor = Color(0xFF70A1FF)
      }
      else -> {
        tempIndicator = "🧊 Freezing Cold (Far away)"
        tempColor = Color(0xFF2ED573)
      }
    }

    currentInput = ""
    if (attemptsLeft <= 0) {
      isGameOver = true
      isWin = false
      soundManager.playLoseSound()
      hintMessage = "Game Over! The secret number was $secretNumber"
      val dur = ((System.currentTimeMillis() - startTimeMs) / 1000L).coerceAtLeast(1L)
      onGameFinished("numberguessing", 20, GameResultType.GAME_OVER, dur, sessionId)
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F0C20))
  ) {
    GameTopBar(
      title = "Number Guessing",
      score = score,
      isPaused = isPaused,
      isMuted = isMuted,
      onBack = onBack,
      onPauseToggle = { isPaused = !isPaused },
      onRestart = { restartGame() },
      onMuteToggle = {
        soundManager.isSoundEnabled = !soundManager.isSoundEnabled
        isMuted = !soundManager.isSoundEnabled
      }
    )

    // Difficulty Selector
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceEvenly
    ) {
      GameDifficulty.values().forEach { d ->
        val isSelected = difficulty == d
        Button(
          onClick = {
            if (difficulty != d) {
              difficulty = d
              restartGame()
            }
          },
          colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) Color(0xFF6C5CE7) else Color(0xFF1E1B38)
          ),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.weight(1f).padding(horizontal = 4.dp).testTag("diff_${d.name}")
        ) {
          Text(d.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
      }
    }

    // Main status card
    Card(
      colors = CardDefaults.cardColors(containerColor = Color(0xFF18152E)),
      shape = RoundedCornerShape(16.dp),
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("Target: 1 - $maxRange", color = Color(0xFFA4B0BE), fontSize = 13.sp)
          Text("Attempts: $attemptsLeft / $totalAttempts", fontWeight = FontWeight.Bold, color = if (attemptsLeft <= 2) Color(0xFFFF4757) else Color(0xFFFFB142))
        }

        Spacer(modifier = Modifier.height(8.dp))

        LinearProgressIndicator(
          progress = { attemptsLeft.toFloat() / totalAttempts },
          modifier = Modifier
            .fillMaxWidth()
            .height(6.dp)
            .clip(RoundedCornerShape(3.dp)),
          color = if (attemptsLeft <= 2) Color(0xFFFF4757) else Color(0xFF00CEC9),
          trackColor = Color(0xFF2E2A52)
        )

        Spacer(modifier = Modifier.height(14.dp))

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.Center,
          modifier = Modifier
            .background(Color(0xFF241F42), RoundedCornerShape(10.dp))
            .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
          Text("Range: ", fontSize = 13.sp, color = Color(0xFFA4B0BE))
          Text("[$lowerBound — $upperBound]", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00FFCC))
        }

        Spacer(modifier = Modifier.height(12.dp))

        Box(
          modifier = Modifier
            .size(width = 160.dp, height = 56.dp)
            .border(2.dp, Color(0xFF6C5CE7), RoundedCornerShape(12.dp))
            .background(Color(0xFF0F0C20), RoundedCornerShape(12.dp)),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = if (currentInput.isEmpty()) "?" else currentInput,
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text(hintMessage, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)

        if (history.isNotEmpty() && !isGameOver) {
          Spacer(modifier = Modifier.height(6.dp))
          Text(tempIndicator, color = tempColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
      }
    }

    if (history.isNotEmpty()) {
      LazyRow(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        items(history) { entry ->
          val chipBg = when (entry.result) {
            "CORRECT" -> Color(0xFF2ED573)
            "HIGH" -> Color(0xFFFF7675)
            else -> Color(0xFF0984E3)
          }
          val arrow = when (entry.result) {
            "HIGH" -> "▼"
            "LOW" -> "▲"
            else -> "★"
          }
          Box(
            modifier = Modifier
              .background(chipBg, RoundedCornerShape(8.dp))
              .padding(horizontal = 10.dp, vertical = 6.dp)
          ) {
            Text("${entry.number} $arrow", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
          }
        }
      }
    }

    Spacer(modifier = Modifier.weight(1f))

    // Numeric Keypad
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 8.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      val keys = listOf(
        listOf("1", "2", "3"),
        listOf("4", "5", "6"),
        listOf("7", "8", "9"),
        listOf("⌫", "0", "GUESS")
      )
      keys.forEach { rowKeys ->
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          rowKeys.forEach { key ->
            val isGuess = key == "GUESS"
            val isBack = key == "⌫"
            Button(
              onClick = {
                if (isGameOver) return@Button
                when (key) {
                  "GUESS" -> submitGuess()
                  "⌫" -> if (currentInput.isNotEmpty()) currentInput = currentInput.dropLast(1)
                  else -> if (currentInput.length < 4) currentInput += key
                }
              },
              colors = ButtonDefaults.buttonColors(
                containerColor = when {
                  isGuess -> Color(0xFF00B894)
                  isBack -> Color(0xFFE84118)
                  else -> Color(0xFF241F42)
                }
              ),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier
                .weight(1f)
                .height(48.dp)
                .testTag("key_$key")
            ) {
              Text(key, fontSize = if (isGuess) 14.sp else 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
          }
        }
      }
    }
  }

  if (isPaused) {
    GamePauseDialog(
      onResume = { isPaused = false },
      onRestart = {
        restartGame()
        isPaused = false
      },
      onExit = onBack
    )
  }

  if (isGameOver) {
    GameOverDialog(
      gameTitle = "Number Guessing",
      resultType = if (isWin) GameResultType.WIN else GameResultType.GAME_OVER,
      score = score,
      highScore = score,
      onPlayAgain = { restartGame() },
      onExit = onBack
    )
  }
}
