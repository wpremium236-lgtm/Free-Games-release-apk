package com.example.games.ludo

import androidx.compose.ui.graphics.Color

/**
 * 6 Ludo Players supported in standard and extended Ludo:
 * RED -> GREEN -> YELLOW -> BLUE -> PURPLE -> ORANGE
 *
 * Each player has:
 * - 4 tokens (24 tokens total in a 6-player match)
 * - Own distinct color
 * - Own starting cell on the track
 * - Own last track cell before entering private home lane
 * - Own 5-cell private home corridor
 * - Own final finish spot in the central home triangle
 */
enum class LudoPlayer(
  val id: Int,
  val displayName: String,
  val color: Color,
  val startPos: Int, // 4-player classic start
  val endTrackPos: Int // 4-player classic end
) {
  RED(0, "Red", Color(0xFFE84118), 0, 50),
  GREEN(1, "Green", Color(0xFF2ED573), 13, 11),
  YELLOW(2, "Yellow", Color(0xFFFFA502), 26, 24),
  BLUE(3, "Blue", Color(0xFF1E90FF), 39, 37),
  PURPLE(4, "Purple", Color(0xFF9B59B6), 48, 46),
  ORANGE(5, "Orange", Color(0xFFFF6348), 60, 58);

  fun getStartPos(playerCount: Int): Int {
    return if (playerCount > 4) id * 12 else startPos
  }

  fun getEndTrackPos(playerCount: Int): Int {
    return if (playerCount > 4) (id * 12 + 70) % 72 else endTrackPos
  }

  companion object {
    fun fromId(id: Int): LudoPlayer = entries.firstOrNull { it.id == id } ?: RED
  }
}

data class LudoToken(
  val id: Int, // 0..3 (Token 1..4)
  val player: LudoPlayer,
  // -1: in base yard
  // 0..51 (4P) / 0..71 (6P): on main track
  // 52..56 (4P) / 72..76 (6P): in 5-step private home corridor
  // 57 (4P) / 77 (6P): finished in central home
  var position: Int = -1
) {
  fun isInBase(): Boolean = position == -1

  fun isOnTrack(playerCount: Int = 4): Boolean =
    position in 0 until LudoEngine.getTrackLength(playerCount)

  fun isInHomeLane(playerCount: Int = 4): Boolean {
    val start = LudoEngine.getHomeLaneStart(playerCount)
    val finish = LudoEngine.getFinishedPos(playerCount)
    return position in start until finish
  }

  fun isFinished(playerCount: Int = 4): Boolean {
    return if (playerCount > 4) position >= 77 else (position == 57 || position >= 77)
  }
}

/**
 * Unified Ludo Engine supporting 2, 3, 4, 5, and 6 players.
 * 2-4 Players: Classic 15x15 board with 52 track cells, 8 safe cells.
 * 5-6 Players: Extended 6-arm board with 72 track cells, 12 safe cells, 24 tokens total.
 */
object LudoEngine {
  const val TRACK_LENGTH = 52
  const val HOME_STEPS = 5
  const val FINISHED_POS = 57

  // 4-player safe cells (4 start + 4 star safe cells)
  val SAFE_CELLS_4P: Set<Int> = setOf(0, 8, 13, 21, 26, 34, 39, 47)
  val SAFE_CELLS: Set<Int> = SAFE_CELLS_4P
  val safePositions: Set<Int> = SAFE_CELLS_4P

  // 6-player safe cells (6 start + 6 star safe cells)
  val SAFE_CELLS_6P: Set<Int> = setOf(0, 7, 12, 19, 24, 31, 36, 43, 48, 55, 60, 67)

  fun getTrackLength(playerCount: Int = 4): Int = if (playerCount > 4) 72 else 52
  fun getHomeLaneStart(playerCount: Int = 4): Int = if (playerCount > 4) 72 else 52
  fun getFinishedPos(playerCount: Int = 4): Int = if (playerCount > 4) 77 else 57

  /**
   * Deterministic player seating configuration for 2, 3, 4, 5, and 6 players.
   */
  fun getActivePlayers(count: Int): List<LudoPlayer> {
    return when (count) {
      2 -> listOf(LudoPlayer.RED, LudoPlayer.GREEN)
      3 -> listOf(LudoPlayer.RED, LudoPlayer.GREEN, LudoPlayer.YELLOW)
      4 -> listOf(LudoPlayer.RED, LudoPlayer.GREEN, LudoPlayer.YELLOW, LudoPlayer.BLUE)
      5 -> listOf(LudoPlayer.RED, LudoPlayer.GREEN, LudoPlayer.YELLOW, LudoPlayer.BLUE, LudoPlayer.PURPLE)
      6 -> listOf(LudoPlayer.RED, LudoPlayer.GREEN, LudoPlayer.YELLOW, LudoPlayer.BLUE, LudoPlayer.PURPLE, LudoPlayer.ORANGE)
      else -> listOf(LudoPlayer.RED, LudoPlayer.GREEN, LudoPlayer.YELLOW, LudoPlayer.BLUE)
    }
  }

  fun isSafeSpot(pos: Int, playerCount: Int = 4): Boolean {
    return if (playerCount > 4) {
      SAFE_CELLS_6P.contains(pos)
    } else {
      SAFE_CELLS_4P.contains(pos)
    }
  }

  fun isCurrentPlayerTurn(requestedPlayer: LudoPlayer, currentPlayer: LudoPlayer): Boolean {
    return requestedPlayer == currentPlayer
  }

  /**
   * Evaluates if a given token can make a legal move with the dice roll (1..6).
   */
  fun canMoveToken(token: LudoToken, roll: Int, playerCount: Int = 4): Boolean {
    if (roll !in 1..6) return false
    if (token.isFinished(playerCount)) return false

    // Base release: requires exact 6
    if (token.isInBase()) {
      return roll == 6
    }

    val trackLen = getTrackLength(playerCount)
    val start = token.player.getStartPos(playerCount)
    val endTrackSteps = if (playerCount > 4) 70 else 50
    val totalStepsToFinish = endTrackSteps + 6 // 56 for 4p, 76 for 6p

    // Moving on main track
    if (token.isOnTrack(playerCount)) {
      val stepsFromStart = (token.position - start + trackLen) % trackLen
      val totalSteps = stepsFromStart + roll
      return totalSteps <= totalStepsToFinish
    }

    // Moving in 5-step private home corridor
    if (token.isInHomeLane(playerCount)) {
      val laneStart = getHomeLaneStart(playerCount)
      val currentLaneStep = token.position - laneStart // 0..4
      val remainingSteps = 5 - currentLaneStep // steps to finish (1..5)
      return roll <= remainingSteps
    }

    return false
  }

  /**
   * Calculates the target position for a token given a dice roll (1..6).
   */
  fun calculateNextPosition(token: LudoToken, roll: Int, playerCount: Int = 4): Int {
    if (!canMoveToken(token, roll, playerCount)) return token.position

    val start = token.player.getStartPos(playerCount)
    if (token.isInBase()) {
      return start
    }

    val trackLen = getTrackLength(playerCount)
    val endTrackSteps = if (playerCount > 4) 70 else 50
    val totalStepsToFinish = endTrackSteps + 6
    val finishedPos = getFinishedPos(playerCount)
    val laneStart = getHomeLaneStart(playerCount)

    if (token.isOnTrack(playerCount)) {
      val stepsFromStart = (token.position - start + trackLen) % trackLen
      val totalSteps = stepsFromStart + roll
      return when {
        totalSteps <= endTrackSteps -> (token.position + roll) % trackLen
        totalSteps in (endTrackSteps + 1)..(endTrackSteps + 5) -> laneStart + (totalSteps - endTrackSteps - 1)
        totalSteps == totalStepsToFinish -> finishedPos
        else -> token.position
      }
    }

    if (token.isInHomeLane(playerCount)) {
      val currentLaneStep = token.position - laneStart
      val remaining = 5 - currentLaneStep
      return when {
        roll < remaining -> token.position + roll
        roll == remaining -> finishedPos
        else -> token.position
      }
    }

    return token.position
  }

  fun canCapture(
    targetPos: Int,
    movingPlayer: LudoPlayer,
    targetToken: LudoToken,
    playerCount: Int = 4
  ): Boolean {
    if (targetToken.player == movingPlayer) return false
    val trackLen = getTrackLength(playerCount)
    if (targetPos !in 0 until trackLen) return false
    if (isSafeSpot(targetPos, playerCount)) return false
    return targetToken.position == targetPos
  }

  fun checkCaptures(
    movedToken: LudoToken,
    targetPos: Int,
    allTokens: List<LudoToken>,
    playerCount: Int = 4
  ): List<LudoToken> {
    val trackLen = getTrackLength(playerCount)
    if (targetPos !in 0 until trackLen || isSafeSpot(targetPos, playerCount)) {
      return emptyList()
    }
    return allTokens.filter { other ->
      other.player != movedToken.player && other.position == targetPos
    }
  }

  fun hasPlayerWon(playerTokens: List<LudoToken>, playerCount: Int = 4): Boolean {
    if (playerTokens.isEmpty()) return false
    return playerTokens.all { it.isFinished(playerCount) }
  }

  fun isTokenSelectable(
    token: LudoToken,
    activePlayer: LudoPlayer,
    roll: Int,
    playerCount: Int = 4
  ): Boolean {
    if (token.player != activePlayer) return false
    return canMoveToken(token, roll, playerCount)
  }

  fun isThreeSixesForfeit(consecutiveSixes: Int): Boolean {
    return consecutiveSixes >= 3
  }

  fun shouldGetBonusRoll(roll: Int, capturedOpponent: Boolean, reachedHome: Boolean): Boolean {
    return roll == 6 || capturedOpponent || reachedHome
  }

  fun getNextPlayerIndex(currentIndex: Int, activePlayers: List<LudoPlayer>): Int {
    if (activePlayers.isEmpty()) return 0
    return (currentIndex + 1) % activePlayers.size
  }
}
