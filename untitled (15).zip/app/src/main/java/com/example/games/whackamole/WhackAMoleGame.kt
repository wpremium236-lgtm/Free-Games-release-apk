package com.example.games.whackamole

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.games.common.GameOverDialog
import com.example.games.common.GamePauseDialog
import com.example.games.common.GameTopBar
import kotlinx.coroutines.delay
import kotlin.random.Random

enum class MoleType(val icon: String, val points: Int) {
  NORMAL("🐹", 10),
  GOLDEN("⭐", 50),
  BOMB("💣", -20)
}

data class MoleHole(
  val id: Int,
  var activeMole: MoleType? = null,
  var isHit: Boolean = false
)

@Composable
fun WhackAMoleGame(
  onBack: () -> Unit,
  onGameFinished: (score: Int) -> Unit
) {
  val context = LocalContext.current
  val soundManager = remember { SoundManager.getInstance(context) }
  var score by remember { mutableIntStateOf(0) }
  var highScore by remember { mutableIntStateOf(0) }
  var timeRemaining by remember { mutableIntStateOf(30) }
  var isPaused by remember { mutableStateOf(false) }
  var isMuted by remember { mutableStateOf(!soundManager.isSoundEnabled) }
  var isGameOver by remember { mutableStateOf(false) }

  val holes = remember {
    mutableStateListOf<MoleHole>().apply {
      for (i in 0..8) add(MoleHole(i))
    }
  }

  fun resetGame() {
    holes.forEach {
      it.activeMole = null
      it.isHit = false
    }
    score = 0
    timeRemaining = 30
    isGameOver = false
  }

  fun whackMole(hole: MoleHole) {
    if (isGameOver || hole.isHit || hole.activeMole == null) return
    val mole = hole.activeMole ?: return
    hole.isHit = true
    if (mole == MoleType.BOMB) {
      soundManager.playCollisionSound()
      score = maxOf(0, score + mole.points)
    } else {
      soundManager.playScoreBeep()
      score += mole.points
    }
  }

  // Timer loop
  LaunchedEffect(isPaused, isGameOver) {
    while (!isPaused && !isGameOver && timeRemaining > 0) {
      delay(1000)
      timeRemaining--
      if (timeRemaining <= 0) {
        isGameOver = true
        soundManager.playWinSound()
        onGameFinished(score)
        break
      }
    }
  }

  // Mole popup loop
  LaunchedEffect(isPaused, isGameOver) {
    while (!isPaused && !isGameOver) {
      val popupInterval = (700 - (score * 2)).coerceAtLeast(400).toLong()
      delay(popupInterval)
      val targetHole = holes.random()
      val rand = Random.nextFloat()
      val type = when {
        rand < 0.15f -> MoleType.GOLDEN
        rand < 0.35f -> MoleType.BOMB
        else -> MoleType.NORMAL
      }
      targetHole.activeMole = type
      targetHole.isHit = false

      delay(popupInterval)
      targetHole.activeMole = null
      targetHole.isHit = false
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F0C20))
  ) {
    GameTopBar(
      title = "Whack-A-Mole",
      score = score,
      highScore = highScore,
      timeRemainingSec = timeRemaining,
      isPaused = isPaused,
      isMuted = isMuted,
      onBack = onBack,
      onPauseToggle = { isPaused = !isPaused },
      onRestart = { resetGame() },
      onMuteToggle = {
        isMuted = !isMuted
        soundManager.isSoundEnabled = !isMuted
      }
    )

    // Hint banner
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text("🐹 = +10  ⭐ = +50  💣 = -20", fontSize = 12.sp, color = Color(0xFFA4B0BE))
      Text("TIME: ${timeRemaining}s", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00CEC9))
    }

    // 3x3 Mole Holes Grid
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .padding(20.dp),
      contentAlignment = Alignment.Center
    ) {
      BoxWithConstraints(
        modifier = Modifier
          .aspectRatio(1f)
          .clip(RoundedCornerShape(20.dp))
          .background(Color(0xFF141926))
          .border(2.dp, Color(0xFF3B336A), RoundedCornerShape(20.dp))
          .padding(12.dp)
      ) {
        Column(modifier = Modifier.fillMaxSize()) {
          for (r in 0..2) {
            Row(modifier = Modifier.weight(1f)) {
              for (c in 0..2) {
                val index = r * 3 + c
                val hole = holes[index]

                Box(
                  modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .padding(8.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF241F42))
                    .border(3.dp, Color(0xFF3B336A), CircleShape)
                    .clickable { whackMole(hole) }
                    .testTag("mole_hole_$index"),
                  contentAlignment = Alignment.Center
                ) {
                  Box(
                    modifier = Modifier
                      .fillMaxSize(0.85f)
                      .clip(CircleShape)
                      .background(Color(0xFF141128)),
                    contentAlignment = Alignment.Center
                  ) {
                    if (hole.activeMole != null) {
                      Text(
                        text = if (hole.isHit) "💥" else hole.activeMole!!.icon,
                        fontSize = 34.sp
                      )
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  if (isPaused) {
    GamePauseDialog(
      onResume = { isPaused = false },
      onRestart = { resetGame() },
      onExit = onBack
    )
  }

  if (isGameOver) {
    GameOverDialog(
      isWin = score >= 100,
      score = score,
      highScore = highScore,
      onPlayAgain = { resetGame() },
      onExit = onBack
    )
  }
}
