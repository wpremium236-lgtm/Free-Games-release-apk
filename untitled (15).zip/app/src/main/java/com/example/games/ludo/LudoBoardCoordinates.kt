package com.example.games.ludo

/**
 * Mathematically precise Ludo Board Grid Coordinates.
 * Supports:
 * - 4-Player Symmetrical 15x15 Grid (52 track cells, 4 corner bases)
 * - 6-Player Extended 17x17 Grid (72 track cells, 6 perimeter bases)
 */
object LudoBoardCoordinates {
  const val GRID_SIZE = 15
  const val GRID_SIZE_6P = 17

  /**
   * 52 continuous track coordinates on 15x15 grid for 2..4 players.
   */
  val TRACK_COORDINATES: List<Pair<Float, Float>> = listOf(
    // Sector 0: RED arm (0..12)
    Pair(1f, 6f),   // 0 (RED START ★)
    Pair(2f, 6f),   // 1
    Pair(3f, 6f),   // 2
    Pair(4f, 6f),   // 3
    Pair(5f, 6f),   // 4
    Pair(6f, 5f),   // 5 (Corner turn up)
    Pair(6f, 4f),   // 6
    Pair(6f, 3f),   // 7
    Pair(6f, 2f),   // 8 (Safe Star ★)
    Pair(6f, 1f),   // 9
    Pair(6f, 0f),   // 10
    Pair(7f, 0f),   // 11
    Pair(8f, 0f),   // 12 (Last track cell before Green home lane)

    // Sector 1: GREEN arm (13..25)
    Pair(8f, 1f),   // 13 (GREEN START ★)
    Pair(8f, 2f),   // 14
    Pair(8f, 3f),   // 15
    Pair(8f, 4f),   // 16
    Pair(8f, 5f),   // 17
    Pair(9f, 6f),   // 18 (Corner turn right)
    Pair(10f, 6f),  // 19
    Pair(11f, 6f),  // 20
    Pair(12f, 6f),  // 21 (Safe Star ★)
    Pair(13f, 6f),  // 22
    Pair(14f, 6f),  // 23
    Pair(14f, 7f),  // 24
    Pair(14f, 8f),  // 25 (Last track cell before Yellow home lane)

    // Sector 2: YELLOW arm (26..38)
    Pair(13f, 8f),  // 26 (YELLOW START ★)
    Pair(12f, 8f),  // 27
    Pair(11f, 8f),  // 28
    Pair(10f, 8f),  // 29
    Pair(9f, 8f),   // 30
    Pair(8f, 9f),   // 31 (Corner turn down)
    Pair(8f, 10f),  // 32
    Pair(8f, 11f),  // 33
    Pair(8f, 12f),  // 34 (Safe Star ★)
    Pair(8f, 13f),  // 35
    Pair(8f, 14f),  // 36
    Pair(7f, 14f),  // 37
    Pair(6f, 14f),  // 38 (Last track cell before Blue home lane)

    // Sector 3: BLUE arm (39..51)
    Pair(6f, 13f),  // 39 (BLUE START ★)
    Pair(6f, 12f),  // 40
    Pair(6f, 11f),  // 41
    Pair(6f, 10f),  // 42
    Pair(6f, 9f),   // 43
    Pair(5f, 8f),   // 44 (Corner turn left)
    Pair(4f, 8f),   // 45
    Pair(3f, 8f),   // 46
    Pair(2f, 8f),   // 47 (Safe Star ★)
    Pair(1f, 8f),   // 48
    Pair(0f, 8f),   // 49
    Pair(0f, 7f),   // 50
    Pair(0f, 6f)    // 51 (Last track cell before Red home lane)
  )

  /**
   * 72 continuous track coordinates on 17x17 grid for 5..6 players.
   * Exactly 12 cells per sector * 6 sectors = 72 cells.
   */
  val TRACK_COORDINATES_6P: List<Pair<Float, Float>> = run {
    val list = mutableListOf<Pair<Float, Float>>()
    // Sector 0: Red (0..11)
    list.add(Pair(1f, 7f))   // 0 (RED START ★)
    list.add(Pair(2f, 7f))   // 1
    list.add(Pair(3f, 7f))   // 2
    list.add(Pair(4f, 7f))   // 3
    list.add(Pair(5f, 7f))   // 4
    list.add(Pair(6f, 7f))   // 5
    list.add(Pair(7f, 6f))   // 6
    list.add(Pair(7f, 5f))   // 7 (Safe Star ★)
    list.add(Pair(7f, 4f))   // 8
    list.add(Pair(7f, 3f))   // 9
    list.add(Pair(7f, 2f))   // 10
    list.add(Pair(8f, 1f))   // 11

    // Sector 1: Green (12..23)
    list.add(Pair(9f, 1f))   // 12 (GREEN START ★)
    list.add(Pair(9f, 2f))   // 13
    list.add(Pair(9f, 3f))   // 14
    list.add(Pair(9f, 4f))   // 15
    list.add(Pair(9f, 5f))   // 16
    list.add(Pair(9f, 6f))   // 17
    list.add(Pair(10f, 7f))  // 18
    list.add(Pair(11f, 7f))  // 19 (Safe Star ★)
    list.add(Pair(12f, 7f))  // 20
    list.add(Pair(13f, 7f))  // 21
    list.add(Pair(14f, 7f))  // 22
    list.add(Pair(15f, 7f))  // 23

    // Sector 2: Yellow (24..35)
    list.add(Pair(15f, 8f))  // 24 (YELLOW START ★)
    list.add(Pair(14f, 8f))  // 25
    list.add(Pair(13f, 8f))  // 26
    list.add(Pair(12f, 8f))  // 27
    list.add(Pair(11f, 8f))  // 28
    list.add(Pair(10f, 8f))  // 29
    list.add(Pair(10f, 9f))  // 30
    list.add(Pair(11f, 9f))  // 31 (Safe Star ★)
    list.add(Pair(12f, 9f))  // 32
    list.add(Pair(13f, 9f))  // 33
    list.add(Pair(14f, 9f))  // 34
    list.add(Pair(15f, 9f))  // 35

    // Sector 3: Blue (36..47)
    list.add(Pair(15f, 10f)) // 36 (BLUE START ★)
    list.add(Pair(14f, 10f)) // 37
    list.add(Pair(13f, 10f)) // 38
    list.add(Pair(12f, 10f)) // 39
    list.add(Pair(11f, 10f)) // 40
    list.add(Pair(10f, 10f)) // 41
    list.add(Pair(9f, 11f))  // 42
    list.add(Pair(9f, 12f))  // 43 (Safe Star ★)
    list.add(Pair(9f, 13f))  // 44
    list.add(Pair(9f, 14f))  // 45
    list.add(Pair(9f, 15f))  // 46
    list.add(Pair(8f, 15f))  // 47

    // Sector 4: Purple (48..59)
    list.add(Pair(7f, 15f))  // 48 (PURPLE START ★)
    list.add(Pair(7f, 14f))  // 49
    list.add(Pair(7f, 13f))  // 50
    list.add(Pair(7f, 12f))  // 51
    list.add(Pair(7f, 11f))  // 52
    list.add(Pair(7f, 10f))  // 53
    list.add(Pair(6f, 9f))   // 54
    list.add(Pair(5f, 9f))   // 55 (Safe Star ★)
    list.add(Pair(4f, 9f))   // 56
    list.add(Pair(3f, 9f))   // 57
    list.add(Pair(2f, 9f))   // 58
    list.add(Pair(1f, 9f))   // 59

    // Sector 5: Orange (60..71)
    list.add(Pair(1f, 8f))   // 60 (ORANGE START ★)
    list.add(Pair(2f, 8f))   // 61
    list.add(Pair(3f, 8f))   // 62
    list.add(Pair(4f, 8f))   // 63
    list.add(Pair(5f, 8f))   // 64
    list.add(Pair(6f, 8f))   // 65
    list.add(Pair(6f, 7f))   // 66
    list.add(Pair(5f, 7f))   // 67 (Safe Star ★)
    list.add(Pair(4f, 7f))   // 68
    list.add(Pair(3f, 7f))   // 69
    list.add(Pair(2f, 7f))   // 70
    list.add(Pair(0f, 7f))   // 71
    list
  }

  /**
   * 4 Sockets in each 6x6 player yard on 15x15 board.
   */
  fun getBaseSocket(player: LudoPlayer, tokenId: Int): Pair<Float, Float> {
    return when (player) {
      LudoPlayer.RED -> when (tokenId % 4) {
        0 -> Pair(1.5f, 1.5f)
        1 -> Pair(3.5f, 1.5f)
        2 -> Pair(1.5f, 3.5f)
        else -> Pair(3.5f, 3.5f)
      }
      LudoPlayer.GREEN -> when (tokenId % 4) {
        0 -> Pair(10.5f, 1.5f)
        1 -> Pair(12.5f, 1.5f)
        2 -> Pair(10.5f, 3.5f)
        else -> Pair(12.5f, 3.5f)
      }
      LudoPlayer.YELLOW -> when (tokenId % 4) {
        0 -> Pair(10.5f, 10.5f)
        1 -> Pair(12.5f, 10.5f)
        2 -> Pair(10.5f, 12.5f)
        else -> Pair(12.5f, 12.5f)
      }
      LudoPlayer.BLUE -> when (tokenId % 4) {
        0 -> Pair(1.5f, 10.5f)
        1 -> Pair(3.5f, 10.5f)
        2 -> Pair(1.5f, 12.5f)
        else -> Pair(3.5f, 12.5f)
      }
      LudoPlayer.PURPLE -> when (tokenId % 4) {
        0 -> Pair(1.5f, 10.5f)
        1 -> Pair(3.5f, 10.5f)
        2 -> Pair(1.5f, 12.5f)
        else -> Pair(3.5f, 12.5f)
      }
      LudoPlayer.ORANGE -> when (tokenId % 4) {
        0 -> Pair(10.5f, 10.5f)
        1 -> Pair(12.5f, 10.5f)
        2 -> Pair(10.5f, 12.5f)
        else -> Pair(12.5f, 12.5f)
      }
    }
  }

  /**
   * 4 Sockets in each base yard on 17x17 6-player board.
   */
  fun getBaseSocket6P(player: LudoPlayer, tokenId: Int): Pair<Float, Float> {
    val idx = tokenId % 4
    val ox = if (idx % 2 == 0) 1.2f else 2.8f
    val oy = if (idx < 2) 1.2f else 2.8f

    return when (player) {
      LudoPlayer.RED -> Pair(0.5f + ox, 0.5f + oy)         // Top-Left (0..4, 0..4)
      LudoPlayer.GREEN -> Pair(12.5f + ox, 0.5f + oy)      // Top-Right (12..16, 0..4)
      LudoPlayer.YELLOW -> Pair(12.5f + ox, 6.0f + oy)     // Middle-Right (12..16, 6..10)
      LudoPlayer.BLUE -> Pair(12.5f + ox, 12.0f + oy)      // Bottom-Right (12..16, 12..16)
      LudoPlayer.PURPLE -> Pair(0.5f + ox, 12.0f + oy)     // Bottom-Left (0..4, 12..16)
      LudoPlayer.ORANGE -> Pair(0.5f + ox, 6.0f + oy)      // Middle-Left (0..4, 6..10)
    }
  }

  /**
   * 5 Steps in private home corridor for 4P (positions 52..56).
   */
  fun getHomeLaneCoordinate(player: LudoPlayer, step: Int): Pair<Float, Float> {
    val s = step.coerceIn(0, 4)
    return when (player) {
      LudoPlayer.RED -> Pair(1f + s, 7f)
      LudoPlayer.GREEN -> Pair(7f, 1f + s)
      LudoPlayer.YELLOW -> Pair(13f - s, 7f)
      LudoPlayer.BLUE -> Pair(7f, 13f - s)
      LudoPlayer.PURPLE -> Pair(7f, 13f - s)
      LudoPlayer.ORANGE -> Pair(1f + s, 7f)
    }
  }

  /**
   * 5 Steps in private home corridor for 6P (positions 72..76 on 17x17 grid).
   */
  fun getHomeLaneCoordinate6P(player: LudoPlayer, step: Int): Pair<Float, Float> {
    val s = step.coerceIn(0, 4)
    return when (player) {
      LudoPlayer.RED -> Pair(2f + s, 8f)        // From West
      LudoPlayer.GREEN -> Pair(8f, 2f + s)       // From North
      LudoPlayer.YELLOW -> Pair(14f - s, 8f)     // From East
      LudoPlayer.BLUE -> Pair(13f - s, 13f - s)  // From South-East
      LudoPlayer.PURPLE -> Pair(8f, 14f - s)     // From South
      LudoPlayer.ORANGE -> Pair(2f + s, 13f - s) // From South-West
    }
  }

  /**
   * Center triangle finish position for 4P (position 57 on 15x15 grid).
   */
  fun getHomeFinishCoordinate(player: LudoPlayer): Pair<Float, Float> {
    return when (player) {
      LudoPlayer.RED -> Pair(6.5f, 7f)
      LudoPlayer.GREEN -> Pair(7f, 6.5f)
      LudoPlayer.YELLOW -> Pair(7.5f, 7f)
      LudoPlayer.BLUE -> Pair(7f, 7.5f)
      LudoPlayer.PURPLE -> Pair(7f, 7.5f)
      LudoPlayer.ORANGE -> Pair(6.5f, 7f)
    }
  }

  /**
   * Center triangle finish position for 6P (position 77 on 17x17 grid).
   */
  fun getHomeFinishCoordinate6P(player: LudoPlayer): Pair<Float, Float> {
    return when (player) {
      LudoPlayer.RED -> Pair(7.5f, 8f)
      LudoPlayer.GREEN -> Pair(8f, 7.5f)
      LudoPlayer.YELLOW -> Pair(8.5f, 8f)
      LudoPlayer.BLUE -> Pair(8.5f, 8.5f)
      LudoPlayer.PURPLE -> Pair(8f, 8.5f)
      LudoPlayer.ORANGE -> Pair(7.5f, 8.5f)
    }
  }

  /**
   * Maps a token's position (-1, 0..51/71, 52..56/72..76, 57/77) to grid coordinates.
   */
  fun getTokenCoordinate(token: LudoToken, playerCount: Int = 4): Pair<Float, Float> {
    if (playerCount > 4) {
      return when {
        token.isInBase() -> getBaseSocket6P(token.player, token.id)
        token.isOnTrack(playerCount) -> TRACK_COORDINATES_6P[token.position % TRACK_COORDINATES_6P.size]
        token.isInHomeLane(playerCount) -> getHomeLaneCoordinate6P(token.player, token.position - 72)
        else -> getHomeFinishCoordinate6P(token.player)
      }
    } else {
      return when {
        token.isInBase() -> getBaseSocket(token.player, token.id)
        token.isOnTrack(playerCount) -> TRACK_COORDINATES[token.position % TRACK_COORDINATES.size]
        token.isInHomeLane(playerCount) -> getHomeLaneCoordinate(token.player, token.position - 52)
        else -> getHomeFinishCoordinate(token.player)
      }
    }
  }
}
