package com.example.games.ludo

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Authentic, beautiful Ludo Board Canvas supporting:
 * - 4-Player Symmetrical 15x15 Classic Board (Red, Green, Yellow, Blue)
 * - 6-Player Extended 17x17 Symmetrical Board (Red, Green, Yellow, Blue, Purple, Orange)
 *
 * Each player has:
 * - Own base yard with 4 circular sockets
 * - Own distinct color
 * - Own start cell with star ★
 * - Own private home lane
 * - Own central finish sector
 */
@Composable
fun LudoBoardView(
  tokens: List<LudoToken>,
  activePlayers: List<LudoPlayer>,
  currentPlayer: LudoPlayer,
  movableTokens: List<LudoToken>,
  onTokenClicked: (LudoToken) -> Unit,
  modifier: Modifier = Modifier
) {
  val is6P = activePlayers.size > 4
  val infiniteTransition = rememberInfiniteTransition(label = "ludoPulse")
  val pulseScale by infiniteTransition.animateFloat(
    initialValue = 1f,
    targetValue = 1.25f,
    animationSpec = infiniteRepeatable(
      animation = tween(450, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "tokenPulse"
  )

  BoxWithConstraints(
    modifier = modifier
      .aspectRatio(1f)
      .shadow(12.dp, RoundedCornerShape(16.dp))
      .clip(RoundedCornerShape(16.dp))
      .background(Color(0xFF130F26))
      .border(3.dp, Color(0xFF3F356B), RoundedCornerShape(16.dp)),
    contentAlignment = Alignment.TopStart
  ) {
    val boardPx = maxWidth
    val activeSet = activePlayers.toSet()

    // 1. Draw Canvas Board
    Canvas(modifier = Modifier.fillMaxSize()) {
      val w = size.width
      val gridDiv = if (is6P) 17f else 15f
      val step = w / gridDiv

      // Background
      drawRect(color = Color(0xFFF7F9FC), size = size)
      val borderPaint = Color(0xFFBDC3C7)
      val borderWidth = 1.2f

      fun drawStar(col: Float, row: Float, color: Color) {
        val cx = (col + 0.5f) * step
        val cy = (row + 0.5f) * step
        val r = step * 0.28f
        val path = Path()
        for (k in 0 until 10) {
          val rad = if (k % 2 == 0) r else r * 0.45f
          val angle = Math.toRadians((k * 36 - 90).toDouble())
          val x = cx + (rad * Math.cos(angle)).toFloat()
          val y = cy + (rad * Math.sin(angle)).toFloat()
          if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        drawPath(path, color = color)
      }

      if (!is6P) {
        // --- 4-Player 15x15 Classic Board ---
        fun drawYard4P(player: LudoPlayer, colStart: Float, rowStart: Float) {
          val inGame = activeSet.contains(player)
          val yardColor = if (inGame) player.color else player.color.copy(alpha = 0.35f)
          val yardLeft = colStart * step
          val yardTop = rowStart * step
          val yardDim = 6f * step

          drawRoundRect(
            color = yardColor,
            topLeft = Offset(yardLeft, yardTop),
            size = Size(yardDim, yardDim),
            cornerRadius = CornerRadius(12f, 12f)
          )

          val innerMargin = 0.9f * step
          val innerDim = yardDim - (innerMargin * 2)
          drawRoundRect(
            color = Color.White,
            topLeft = Offset(yardLeft + innerMargin, yardTop + innerMargin),
            size = Size(innerDim, innerDim),
            cornerRadius = CornerRadius(8f, 8f)
          )

          for (i in 0 until 4) {
            val socketCoord = LudoBoardCoordinates.getBaseSocket(player, i)
            val cx = (socketCoord.first + 0.5f) * step
            val cy = (socketCoord.second + 0.5f) * step
            val radius = step * 0.42f
            drawCircle(color = yardColor, radius = radius, center = Offset(cx, cy))
            drawCircle(color = Color.White.copy(alpha = 0.45f), radius = radius * 0.55f, center = Offset(cx, cy))
          }
        }

        drawYard4P(LudoPlayer.RED, 0f, 0f)
        drawYard4P(LudoPlayer.GREEN, 9f, 0f)
        drawYard4P(LudoPlayer.YELLOW, 9f, 9f)
        drawYard4P(LudoPlayer.BLUE, 0f, 9f)

        for (col in 0 until 15) {
          for (row in 0 until 15) {
            val inYard = (col < 6 && row < 6) || (col > 8 && row < 6) ||
                         (col > 8 && row > 8) || (col < 6 && row > 8)
            val inCenter = col in 6..8 && row in 6..8

            if (!inYard && !inCenter) {
              val cellLeft = col * step
              val cellTop = row * step
              val cellSize = Size(step, step)

              val fillColor = when {
                row == 7 && col in 1..5 -> LudoPlayer.RED.color
                col == 7 && row in 1..5 -> LudoPlayer.GREEN.color
                row == 7 && col in 9..13 -> LudoPlayer.YELLOW.color
                col == 7 && row in 9..13 -> LudoPlayer.BLUE.color
                col == 1 && row == 6 -> LudoPlayer.RED.color
                col == 8 && row == 1 -> LudoPlayer.GREEN.color
                col == 13 && row == 8 -> LudoPlayer.YELLOW.color
                col == 6 && row == 13 -> LudoPlayer.BLUE.color
                else -> Color.White
              }

              drawRect(color = fillColor, topLeft = Offset(cellLeft, cellTop), size = cellSize)
              drawRect(color = borderPaint, topLeft = Offset(cellLeft, cellTop), size = cellSize, style = Stroke(width = borderWidth))

              val isStart = (col == 1 && row == 6) || (col == 8 && row == 1) || (col == 13 && row == 8) || (col == 6 && row == 13)
              val isSafeStar = (col == 6 && row == 2) || (col == 12 && row == 6) || (col == 8 && row == 12) || (col == 2 && row == 8)
              if (isStart || isSafeStar) {
                drawStar(col.toFloat(), row.toFloat(), if (isStart) Color.White else Color(0xFFF1C40F))
              }
            }
          }
        }

        // Center 4 Triangles
        val cLeft = 6f * step
        val cTop = 6f * step
        val cRight = 9f * step
        val cBottom = 9f * step
        val cx = 7.5f * step
        val cy = 7.5f * step

        drawPath(Path().apply { moveTo(cLeft, cTop); lineTo(cx, cy); lineTo(cLeft, cBottom); close() }, color = LudoPlayer.RED.color)
        drawPath(Path().apply { moveTo(cLeft, cTop); lineTo(cRight, cTop); lineTo(cx, cy); close() }, color = LudoPlayer.GREEN.color)
        drawPath(Path().apply { moveTo(cRight, cTop); lineTo(cRight, cBottom); lineTo(cx, cy); close() }, color = LudoPlayer.YELLOW.color)
        drawPath(Path().apply { moveTo(cLeft, cBottom); lineTo(cx, cy); lineTo(cRight, cBottom); close() }, color = LudoPlayer.BLUE.color)
        drawRect(color = borderPaint, topLeft = Offset(cLeft, cTop), size = Size(3 * step, 3 * step), style = Stroke(width = 1.5f))

      } else {
        // --- 6-Player 17x17 Extended Board ---
        fun drawYard6P(player: LudoPlayer, colStart: Float, rowStart: Float) {
          val inGame = activeSet.contains(player)
          val yardColor = if (inGame) player.color else player.color.copy(alpha = 0.35f)
          val yardLeft = colStart * step
          val yardTop = rowStart * step
          val yardDim = 4.8f * step

          drawRoundRect(
            color = yardColor,
            topLeft = Offset(yardLeft, yardTop),
            size = Size(yardDim, yardDim),
            cornerRadius = CornerRadius(10f, 10f)
          )

          val innerMargin = 0.7f * step
          val innerDim = yardDim - (innerMargin * 2)
          drawRoundRect(
            color = Color.White,
            topLeft = Offset(yardLeft + innerMargin, yardTop + innerMargin),
            size = Size(innerDim, innerDim),
            cornerRadius = CornerRadius(6f, 6f)
          )

          for (i in 0 until 4) {
            val socketCoord = LudoBoardCoordinates.getBaseSocket6P(player, i)
            val cx = (socketCoord.first + 0.5f) * step
            val cy = (socketCoord.second + 0.5f) * step
            val radius = step * 0.36f
            drawCircle(color = yardColor, radius = radius, center = Offset(cx, cy))
            drawCircle(color = Color.White.copy(alpha = 0.45f), radius = radius * 0.55f, center = Offset(cx, cy))
          }
        }

        // Draw 6 Perimeter Yards
        drawYard6P(LudoPlayer.RED, 0.2f, 0.2f)        // Top-Left
        drawYard6P(LudoPlayer.GREEN, 12.0f, 0.2f)    // Top-Right
        drawYard6P(LudoPlayer.YELLOW, 12.0f, 6.1f)   // Middle-Right
        drawYard6P(LudoPlayer.BLUE, 12.0f, 12.0f)    // Bottom-Right
        drawYard6P(LudoPlayer.PURPLE, 0.2f, 12.0f)   // Bottom-Left
        drawYard6P(LudoPlayer.ORANGE, 0.2f, 6.1f)    // Middle-Left

        // Draw cells and home corridors
        for (col in 0 until 17) {
          for (row in 0 until 17) {
            val inYard = (col < 5 && row < 5) || (col > 11 && row < 5) ||
                         (col > 11 && row in 6..10) || (col > 11 && row > 11) ||
                         (col < 5 && row > 11) || (col < 5 && row in 6..10)
            val inCenter = col in 7..9 && row in 7..9

            if (!inYard && !inCenter) {
              val cellLeft = col * step
              val cellTop = row * step
              val cellSize = Size(step, step)

              val fillColor = when {
                // Private home lanes
                row == 8 && col in 2..6 -> LudoPlayer.RED.color
                col == 8 && row in 2..6 -> LudoPlayer.GREEN.color
                row == 8 && col in 10..14 -> LudoPlayer.YELLOW.color
                col == 8 && row in 10..14 -> LudoPlayer.PURPLE.color
                // Starts
                col == 1 && row == 7 -> LudoPlayer.RED.color
                col == 9 && row == 1 -> LudoPlayer.GREEN.color
                col == 15 && row == 8 -> LudoPlayer.YELLOW.color
                col == 15 && row == 10 -> LudoPlayer.BLUE.color
                col == 7 && row == 15 -> LudoPlayer.PURPLE.color
                col == 1 && row == 8 -> LudoPlayer.ORANGE.color
                else -> Color.White
              }

              drawRect(color = fillColor, topLeft = Offset(cellLeft, cellTop), size = cellSize)
              drawRect(color = borderPaint, topLeft = Offset(cellLeft, cellTop), size = cellSize, style = Stroke(width = borderWidth))

              // Safe stars
              val isStart = (col == 1 && row == 7) || (col == 9 && row == 1) || (col == 15 && row == 8) ||
                            (col == 15 && row == 10) || (col == 7 && row == 15) || (col == 1 && row == 8)
              val isSafeStar = (col == 7 && row == 5) || (col == 11 && row == 7) || (col == 11 && row == 9) ||
                               (col == 9 && row == 12) || (col == 5 && row == 9) || (col == 5 && row == 7)

              if (isStart || isSafeStar) {
                drawStar(col.toFloat(), row.toFloat(), if (isStart) Color.White else Color(0xFFF1C40F))
              }
            }
          }
        }

        // Center 6 Triangles (around center (8.5, 8.5))
        val cx = 8.5f * step
        val cy = 8.5f * step
        val cLeft = 7f * step
        val cTop = 7f * step
        val cRight = 10f * step
        val cBottom = 10f * step

        drawPath(Path().apply { moveTo(cLeft, cTop); lineTo(cx, cy); lineTo(cLeft, cBottom); close() }, color = LudoPlayer.RED.color)
        drawPath(Path().apply { moveTo(cLeft, cTop); lineTo(cRight, cTop); lineTo(cx, cy); close() }, color = LudoPlayer.GREEN.color)
        drawPath(Path().apply { moveTo(cRight, cTop); lineTo(cRight, cy); lineTo(cx, cy); close() }, color = LudoPlayer.YELLOW.color)
        drawPath(Path().apply { moveTo(cRight, cy); lineTo(cRight, cBottom); lineTo(cx, cy); close() }, color = LudoPlayer.BLUE.color)
        drawPath(Path().apply { moveTo(cLeft, cBottom); lineTo(cx, cy); lineTo(cRight, cBottom); close() }, color = LudoPlayer.PURPLE.color)
        drawPath(Path().apply { moveTo(cLeft, cy); lineTo(cx, cy); lineTo(cLeft, cBottom); close() }, color = LudoPlayer.ORANGE.color)
        drawRect(color = borderPaint, topLeft = Offset(cLeft, cTop), size = Size(3 * step, 3 * step), style = Stroke(width = 1.5f))
      }
    }

    // 2. Render Interactive Tokens on the Board
    val gridDiv = if (is6P) 17f else 15f
    val stepDp = boardPx / gridDiv
    val tokenSize = stepDp * 0.74f

    val tokensByPos = tokens.groupBy { it.position }

    tokens.forEach { token ->
      val isMovable = movableTokens.contains(token)
      val coord = LudoBoardCoordinates.getTokenCoordinate(token, activePlayers.size)

      val cellGroup = tokensByPos[token.position] ?: emptyList()
      val tokenIndexInCell = cellGroup.indexOf(token)
      val stackOffsetX = if (cellGroup.size > 1 && token.isOnTrack(activePlayers.size)) {
        (tokenIndexInCell - (cellGroup.size - 1) / 2f) * (stepDp.value * 0.16f)
      } else 0f
      val stackOffsetY = if (cellGroup.size > 1 && token.isOnTrack(activePlayers.size)) {
        (tokenIndexInCell - (cellGroup.size - 1) / 2f) * (stepDp.value * 0.16f)
      } else 0f

      val xOffset = stepDp * coord.first + (stepDp - tokenSize) / 2 + stackOffsetX.dp
      val yOffset = stepDp * coord.second + (stepDp - tokenSize) / 2 + stackOffsetY.dp

      Box(
        modifier = Modifier
          .offset(x = xOffset, y = yOffset)
          .size(tokenSize)
          .scale(if (isMovable) pulseScale else 1f)
          .testTag("ludo_token_${token.player.name.lowercase()}_${token.id}")
          .clickable(enabled = isMovable) {
            onTokenClicked(token)
          },
        contentAlignment = Alignment.Center
      ) {
        if (isMovable) {
          Box(
            modifier = Modifier
              .size(tokenSize * 1.15f)
              .clip(CircleShape)
              .background(Color(0xFFF1C40F).copy(alpha = 0.55f))
          )
        }

        Box(
          modifier = Modifier
            .size(tokenSize)
            .shadow(if (isMovable) 6.dp else 2.dp, CircleShape)
            .clip(CircleShape)
            .background(token.player.color)
            .border(
              width = if (isMovable) 2.5.dp else 1.5.dp,
              color = if (isMovable) Color.White else Color.White.copy(alpha = 0.8f),
              shape = CircleShape
            ),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = "${token.id + 1}",
            fontSize = if (is6P) 9.sp else 11.sp,
            fontWeight = FontWeight.Black,
            color = Color.White
          )
        }
      }
    }
  }
}
