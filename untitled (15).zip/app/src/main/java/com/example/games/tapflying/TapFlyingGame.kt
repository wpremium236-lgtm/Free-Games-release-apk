package com.example.games.tapflying

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.core.model.GameResultType
import com.example.games.common.GameOverDialog
import com.example.games.common.GamePauseDialog
import com.example.games.common.GameTopBar
import kotlinx.coroutines.delay
import java.util.UUID
import kotlin.random.Random

data class PipeObstacle(
  var x: Float,
  val gapTop: Float,
  val gapHeight: Float,
  var scored: Boolean = false
)

@Composable
fun TapFlyingGame(
  onBack: () -> Unit,
  onGameFinished: (gameId: String, score: Int, resultType: GameResultType, duration: Long, sessionId: String) -> Unit
) {
  val context = LocalContext.current
  val soundManager = remember { SoundManager.getInstance(context) }
  var sessionId by remember { mutableStateOf(UUID.randomUUID().toString()) }
  var startTimeMs by remember { mutableStateOf(System.currentTimeMillis()) }
  var hasSubmittedSession by remember { mutableStateOf(false) }

  var birdY by remember { mutableFloatStateOf(0.45f) }
  var birdVelocity by remember { mutableFloatStateOf(0f) }
  val gravity = 0.0016f
  val jumpStrength = -0.024f
  val pipes = remember { mutableStateListOf<PipeObstacle>() }
  var score by remember { mutableIntStateOf(0) }
  var highScore by remember { mutableIntStateOf(0) }
  var isPaused by remember { mutableStateOf(false) }
  var isMuted by remember { mutableStateOf(!soundManager.isSoundEnabled) }
  var isGameOver by remember { mutableStateOf(false) }
  var gameStarted by remember { mutableStateOf(false) }

  fun triggerGameFinished() {
    if (!hasSubmittedSession) {
      hasSubmittedSession = true
      val duration = ((System.currentTimeMillis() - startTimeMs) / 1000L).coerceAtLeast(1L)
      onGameFinished("tapflying", score, GameResultType.GAME_OVER, duration, sessionId)
    }
  }

  fun flap() {
    if (isGameOver) return
    if (!gameStarted) gameStarted = true
    birdVelocity = jumpStrength
    soundManager.playMoveSound()
  }

  fun resetGame() {
    birdY = 0.45f
    birdVelocity = 0f
    pipes.clear()
    score = 0
    isGameOver = false
    isPaused = false
    gameStarted = false
    sessionId = UUID.randomUUID().toString()
    startTimeMs = System.currentTimeMillis()
    hasSubmittedSession = false
  }

  // Physics and Pipe loop
  LaunchedEffect(isPaused, isGameOver, gameStarted) {
    if (!gameStarted) return@LaunchedEffect
    var pipeTick = 0
    val pipeGap = 0.28f

    while (!isPaused && !isGameOver) {
      delay(20)
      pipeTick++

      // Gravity
      birdVelocity += gravity
      birdY += birdVelocity

      // Spawn pipes
      if (pipeTick % 85 == 0) {
        val top = Random.nextFloat() * 0.4f + 0.1f
        pipes.add(PipeObstacle(x = 1.1f, gapTop = top, gapHeight = pipeGap))
      }

      // Update pipes
      val iterator = pipes.iterator()
      while (iterator.hasNext()) {
        val pipe = iterator.next()
        pipe.x -= 0.008f

        if (!pipe.scored && pipe.x < 0.25f) {
          pipe.scored = true
          score++
          soundManager.playScoreBeep()
        }

        // Collision check
        if (pipe.x in 0.18f..0.32f) {
          if (birdY < pipe.gapTop || birdY > pipe.gapTop + pipe.gapHeight) {
            isGameOver = true
            soundManager.playCollisionSound()
            soundManager.playLoseSound()
            triggerGameFinished()
            break
          }
        }

        if (pipe.x < -0.2f) {
          iterator.remove()
        }
      }

      // Floor & ceiling collision
      if (birdY > 0.95f || birdY < 0.02f) {
        isGameOver = true
        soundManager.playCollisionSound()
        soundManager.playLoseSound()
        triggerGameFinished()
        break
      }
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F0C20))
  ) {
    GameTopBar(
      title = "Tap Flying",
      score = score,
      highScore = highScore,
      isPaused = isPaused,
      isMuted = isMuted,
      onBack = onBack,
      onPauseToggle = { isPaused = !isPaused },
      onRestart = { resetGame() },
      onMuteToggle = {
        isMuted = !isMuted
        soundManager.isSoundEnabled = !isMuted
      }
    )

    // Canvas with Tap gesture
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .padding(16.dp),
      contentAlignment = Alignment.Center
    ) {
      BoxWithConstraints(
        modifier = Modifier
          .fillMaxSize()
          .clip(RoundedCornerShape(16.dp))
          .background(Color(0xFF141A29))
          .pointerInput(Unit) {
            detectTapGestures {
              flap()
            }
          }
          .testTag("tap_flying_canvas")
      ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
          val w = size.width
          val h = size.height

          // Cloud layers
          drawCircle(Color(0x22FFFFFF), radius = w * 0.15f, center = Offset(w * 0.3f, h * 0.2f))
          drawCircle(Color(0x22FFFFFF), radius = w * 0.18f, center = Offset(w * 0.75f, h * 0.35f))

          // Draw pipes
          val pipeWidth = w * 0.14f
          pipes.forEach { pipe ->
            val px = pipe.x * w
            val gapTopPx = pipe.gapTop * h
            val gapBottomPx = (pipe.gapTop + pipe.gapHeight) * h

            // Top pipe
            drawRoundRect(
              Color(0xFF2ED573),
              topLeft = Offset(px, 0f),
              size = Size(pipeWidth, gapTopPx),
              cornerRadius = CornerRadius(6f)
            )
            drawRoundRect(
              Color(0xFF26AF5F),
              topLeft = Offset(px - 4f, gapTopPx - 20f),
              size = Size(pipeWidth + 8f, 20f),
              cornerRadius = CornerRadius(4f)
            )

            // Bottom pipe
            drawRoundRect(
              Color(0xFF2ED573),
              topLeft = Offset(px, gapBottomPx),
              size = Size(pipeWidth, h - gapBottomPx),
              cornerRadius = CornerRadius(6f)
            )
            drawRoundRect(
              Color(0xFF26AF5F),
              topLeft = Offset(px - 4f, gapBottomPx),
              size = Size(pipeWidth + 8f, 20f),
              cornerRadius = CornerRadius(4f)
            )
          }

          // Ground bar
          drawRect(Color(0xFF241F42), Offset(0f, h * 0.95f), Size(w, h * 0.05f))

          // Draw Bird
          val bx = w * 0.25f
          val by = birdY * h
          val birdRadius = w * 0.045f

          // Body
          drawCircle(Color(0xFFFBC531), radius = birdRadius, center = Offset(bx, by))
          // Wing
          drawCircle(Color(0xFFE1B12C), radius = birdRadius * 0.6f, center = Offset(bx - 6f, by + 4f))
          // Eye
          drawCircle(Color.White, radius = birdRadius * 0.35f, center = Offset(bx + 8f, by - 4f))
          drawCircle(Color.Black, radius = birdRadius * 0.18f, center = Offset(bx + 10f, by - 4f))
          // Beak
          drawRoundRect(
            Color(0xFFFF7675),
            topLeft = Offset(bx + birdRadius - 2f, by - 2f),
            size = Size(16f, 10f),
            cornerRadius = CornerRadius(3f)
          )
        }

        if (!gameStarted) {
          Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
          ) {
            Text(
              "TAP ANYWHERE TO FLY",
              color = Color.White,
              fontWeight = FontWeight.Bold,
              fontSize = 18.sp,
              modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xAA000000))
                .padding(horizontal = 16.dp, vertical = 8.dp)
            )
          }
        }
      }
    }
  }

  if (isPaused) {
    GamePauseDialog(
      onResume = { isPaused = false },
      onRestart = { resetGame() },
      onExit = onBack
    )
  }

  if (isGameOver) {
    GameOverDialog(
      gameTitle = "Tap Flying",
      resultType = GameResultType.GAME_OVER,
      score = score,
      highScore = highScore,
      onPlayAgain = { resetGame() },
      onExit = onBack
    )
  }
}
