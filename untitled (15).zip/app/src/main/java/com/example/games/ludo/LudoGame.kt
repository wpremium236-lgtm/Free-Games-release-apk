package com.example.games.ludo

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.core.model.GameDifficulty
import com.example.core.model.GameResultType
import com.example.games.common.GameOverDialog
import com.example.games.common.GamePauseDialog
import com.example.games.common.GameTopBar
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.random.Random

enum class LudoGameMode {
  SELECTION,
  OFFLINE,
  ONLINE_LOBBY,
  ONLINE_PLAYING
}

@Composable
fun LudoGame(
  onBack: () -> Unit,
  onGameFinished: (gameId: String, score: Int, resultType: GameResultType, duration: Long, sessionId: String) -> Unit
) {
  val context = LocalContext.current
  val soundManager = remember { SoundManager.getInstance(context) }
  val scope = rememberCoroutineScope()
  val firebaseManager = remember { LudoFirebaseManager() }

  var gameMode by remember { mutableStateOf(LudoGameMode.SELECTION) }
  var sessionId by remember { mutableStateOf(UUID.randomUUID().toString()) }
  var startTimeMs by remember { mutableStateOf(System.currentTimeMillis()) }
  var hasSubmittedSession by remember { mutableStateOf(false) }

  // Online Multiplayer State
  var onlineRoomCode by remember { mutableStateOf("") }
  var joinCodeInput by remember { mutableStateOf("") }
  var onlineError by remember { mutableStateOf<String?>(null) }
  var onlineRoomState by remember { mutableStateOf<LudoOnlineRoomState?>(null) }
  var showLeaveConfirmDialog by remember { mutableStateOf(false) }

  // Default Player count = 4 (Classic 15x15 Ludo)
  var playerCount by remember { mutableIntStateOf(4) }
  var isAiMode by remember { mutableStateOf(false) } // Default: Same Device Pass & Play
  var aiDifficulty by remember { mutableStateOf(GameDifficulty.MEDIUM) }

  // Turn, dice and rules state for offline
  var currentPlayerIndex by remember { mutableIntStateOf(0) }
  var diceValue by remember { mutableIntStateOf(6) }
  var isRolling by remember { mutableStateOf(false) }
  var hasRolled by remember { mutableStateOf(false) }
  var consecutiveSixes by remember { mutableIntStateOf(0) }
  var turnStatusMessage by remember { mutableStateOf<String?>(null) }
  var isPaused by remember { mutableStateOf(false) }
  var isMuted by remember { mutableStateOf(!soundManager.isSoundEnabled) }
  var isGameOver by remember { mutableStateOf(false) }
  var winnerPlayer by remember { mutableStateOf<LudoPlayer?>(null) }

  val currentUser = remember {
    try {
      FirebaseAuth.getInstance().currentUser
    } catch (_: Exception) {
      null
    }
  }

  // Active players derived from LudoEngine
  val activePlayers = remember(playerCount, gameMode, onlineRoomState) {
    if (gameMode == LudoGameMode.ONLINE_PLAYING && onlineRoomState != null) {
      LudoEngine.getActivePlayers(onlineRoomState!!.playerCount)
    } else {
      LudoEngine.getActivePlayers(playerCount)
    }
  }

  // Tokens: 4 tokens per active player (24 tokens total for 6 players)
  val tokens = remember { mutableStateListOf<LudoToken>() }
  val playerDiceValues = remember { mutableStateMapOf<LudoPlayer, Int>() }

  fun initializeTokens() {
    tokens.clear()
    activePlayers.forEach { player ->
      for (i in 0 until 4) {
        tokens.add(LudoToken(id = i, player = player, position = -1))
      }
      if (!playerDiceValues.containsKey(player)) {
        playerDiceValues[player] = 6
      }
    }
  }

  LaunchedEffect(playerCount, activePlayers.size) {
    initializeTokens()
    activePlayers.forEach { p ->
      if (!playerDiceValues.containsKey(p)) {
        playerDiceValues[p] = 6
      }
    }
  }

  // Sync token list with online room state
  LaunchedEffect(onlineRoomState?.tokenPositions, onlineRoomState?.status) {
    val state = onlineRoomState
    if (gameMode == LudoGameMode.ONLINE_PLAYING && state != null && state.tokenPositions.isNotEmpty()) {
      tokens.clear()
      val pCount = state.playerCount
      val onlineActive = LudoEngine.getActivePlayers(pCount)
      onlineActive.forEachIndexed { pIdx, player ->
        for (tId in 0 until 4) {
          val posIdx = pIdx * 4 + tId
          val pos = state.tokenPositions.getOrElse(posIdx) { -1 }
          tokens.add(LudoToken(id = tId, player = player, position = pos))
        }
      }
      diceValue = state.diceValue
      currentPlayerIndex = state.currentTurnIndex
      hasRolled = state.hasRolled
      consecutiveSixes = state.consecutiveSixes
      if (state.winner.isNotBlank()) {
        isGameOver = true
        winnerPlayer = onlineActive.getOrNull(state.currentTurnIndex) ?: LudoPlayer.RED
      }
    }
  }

  // Handle hardware Back Button safely
  BackHandler {
    if (gameMode == LudoGameMode.ONLINE_PLAYING || (gameMode == LudoGameMode.OFFLINE && !isGameOver)) {
      showLeaveConfirmDialog = true
    } else if (gameMode != LudoGameMode.SELECTION) {
      if (gameMode == LudoGameMode.ONLINE_LOBBY) {
        firebaseManager.leaveRoom(onlineRoomCode)
      }
      gameMode = LudoGameMode.SELECTION
    } else {
      onBack()
    }
  }

  fun resetGame() {
    initializeTokens()
    playerDiceValues.clear()
    activePlayers.forEach { playerDiceValues[it] = 6 }
    currentPlayerIndex = 0
    diceValue = 6
    isRolling = false
    hasRolled = false
    consecutiveSixes = 0
    turnStatusMessage = null
    isGameOver = false
    winnerPlayer = null
    sessionId = UUID.randomUUID().toString()
    startTimeMs = System.currentTimeMillis()
    hasSubmittedSession = false
  }

  fun advanceTurn(bonusRoll: Boolean = false) {
    if (!bonusRoll) {
      currentPlayerIndex = LudoEngine.getNextPlayerIndex(currentPlayerIndex, activePlayers)
      consecutiveSixes = 0
      if (!isAiMode && gameMode == LudoGameMode.OFFLINE) {
        val nextP = activePlayers.getOrElse(currentPlayerIndex % activePlayers.size) { LudoPlayer.RED }
        turnStatusMessage = "👉 PASS PHONE TO ${nextP.displayName.uppercase()}"
      }
    }
    hasRolled = false
  }

  fun moveTokenOffline(token: LudoToken, roll: Int) {
    soundManager.playMoveSound()
    val pCount = activePlayers.size
    val newPos = LudoEngine.calculateNextPosition(token, roll, pCount)
    token.position = newPos

    var capturedOpponent = false
    val capturedTokens = LudoEngine.checkCaptures(token, newPos, tokens, pCount)
    if (capturedTokens.isNotEmpty()) {
      capturedTokens.forEach { opponentToken ->
        opponentToken.position = -1
        capturedOpponent = true
      }
      soundManager.playCollisionSound()
    }

    // Check winner: all 4 tokens finished in central home
    val playerTokens = tokens.filter { it.player == token.player }
    if (LudoEngine.hasPlayerWon(playerTokens, pCount)) {
      isGameOver = true
      winnerPlayer = token.player
      val isWin = token.player == LudoPlayer.RED
      val resType = if (isWin) GameResultType.WIN else GameResultType.LOSS
      val s = if (isWin) 1000 else 250
      if (isWin) soundManager.playWinSound() else soundManager.playLoseSound()
      if (!hasSubmittedSession) {
        hasSubmittedSession = true
        val duration = ((System.currentTimeMillis() - startTimeMs) / 1000L).coerceAtLeast(1L)
        onGameFinished("ludo", s, resType, duration, sessionId)
      }
      return
    }

    val reachedHome = token.isFinished(pCount)
    val getsBonus = LudoEngine.shouldGetBonusRoll(roll, capturedOpponent, reachedHome)

    if (getsBonus) {
      turnStatusMessage = when {
        roll == 6 -> "🎲 Rolled a 6! Roll Again!"
        capturedOpponent -> "⚔️ Token Captured! Bonus Turn!"
        reachedHome -> "🎉 Token Reached Home! Bonus Turn!"
        else -> null
      }
      advanceTurn(bonusRoll = true)
    } else {
      turnStatusMessage = null
      advanceTurn(bonusRoll = false)
    }
  }

  val currentPlayer = activePlayers.getOrElse(currentPlayerIndex % activePlayers.size) { LudoPlayer.RED }

  // Online active player check
  val isMyOnlineTurn = if (gameMode == LudoGameMode.ONLINE_PLAYING && onlineRoomState != null && currentUser != null) {
    val myPlayer = onlineRoomState!!.players[currentUser.uid]
    myPlayer != null && myPlayer.playerIndex == onlineRoomState!!.currentTurnIndex
  } else false

  val movableTokens = if (hasRolled) {
    val pCount = activePlayers.size
    if (gameMode == LudoGameMode.ONLINE_PLAYING) {
      if (isMyOnlineTurn) {
        tokens.filter { it.player == currentPlayer && LudoEngine.canMoveToken(it, diceValue, pCount) }
      } else emptyList()
    } else {
      tokens.filter { it.player == currentPlayer && LudoEngine.canMoveToken(it, diceValue, pCount) }
    }
  } else {
    emptyList()
  }

  fun rollDiceOffline() {
    if (isRolling || hasRolled || isGameOver) return
    isRolling = true
    turnStatusMessage = null
    soundManager.playDiceRoll()

    scope.launch {
      // Dice animation frames
      for (i in 0..6) {
        val r = Random.nextInt(1, 7)
        diceValue = r
        playerDiceValues[currentPlayer] = r
        delay(45)
      }
      isRolling = false
      hasRolled = true
      playerDiceValues[currentPlayer] = diceValue

      // Three-Six Rule verification
      if (diceValue == 6) {
        consecutiveSixes++
        if (LudoEngine.isThreeSixesForfeit(consecutiveSixes)) {
          turnStatusMessage = "⚠️ 3 Sixes in a row! Turn forfeited!"
          soundManager.playCollisionSound()
          consecutiveSixes = 0
          delay(1200)
          turnStatusMessage = null
          advanceTurn(bonusRoll = false)
          return@launch
        }
      } else {
        consecutiveSixes = 0
      }

      val pCount = activePlayers.size
      val legal = tokens.filter { it.player == currentPlayer && LudoEngine.canMoveToken(it, diceValue, pCount) }
      if (legal.isEmpty()) {
        turnStatusMessage = "No legal moves with $diceValue"
        delay(900)
        turnStatusMessage = null
        advanceTurn(bonusRoll = false)
      }
    }
  }

  // AI Turn Execution for vs AI Mode (Offline)
  LaunchedEffect(currentPlayerIndex, hasRolled, isRolling, isAiMode, isGameOver, gameMode) {
    if (gameMode != LudoGameMode.OFFLINE || isGameOver) return@LaunchedEffect
    if (isAiMode && currentPlayerIndex > 0) {
      val pCount = activePlayers.size
      if (!hasRolled && !isRolling) {
        delay(600)
        rollDiceOffline()
      } else if (hasRolled && !isRolling) {
        val legal = tokens.filter { it.player == currentPlayer && LudoEngine.canMoveToken(it, diceValue, pCount) }
        if (legal.isNotEmpty()) {
          delay(600)
          val chosen = when (aiDifficulty) {
            GameDifficulty.EASY -> legal.random()
            GameDifficulty.MEDIUM -> legal.firstOrNull { it.position != -1 } ?: legal.first()
            GameDifficulty.HARD -> {
              val trackLen = LudoEngine.getTrackLength(pCount)
              legal.firstOrNull { t ->
                val nextPos = LudoEngine.calculateNextPosition(t, diceValue, pCount)
                nextPos in 0 until trackLen && !LudoEngine.isSafeSpot(nextPos, pCount) &&
                  tokens.any { it.player != t.player && it.position == nextPos }
              } ?: legal.firstOrNull { it.isInHomeLane(pCount) }
              ?: legal.firstOrNull { it.isInBase() }
              ?: legal.maxByOrNull { it.position } ?: legal.first()
            }
          }
          moveTokenOffline(chosen, diceValue)
        }
      }
    }
  }

  // Cleanup Firebase listener on exit
  DisposableEffect(Unit) {
    onDispose {
      firebaseManager.detachListener()
    }
  }

  // Sync online dice value with playerDiceValues
  LaunchedEffect(onlineRoomState?.diceValue, onlineRoomState?.currentTurnIndex) {
    val state = onlineRoomState ?: return@LaunchedEffect
    val p = activePlayers.getOrNull(state.currentTurnIndex)
    if (p != null && state.diceValue in 1..6) {
      playerDiceValues[p] = state.diceValue
    }
  }

  val topRowPlayers = remember(activePlayers) {
    when (activePlayers.size) {
      2 -> listOf(activePlayers[0]) // RED
      3 -> listOf(activePlayers[0], activePlayers[1]) // RED, GREEN
      4 -> listOf(activePlayers[0], activePlayers[1]) // RED, GREEN
      5 -> listOf(activePlayers[0], activePlayers[1], activePlayers[2]) // RED, GREEN, YELLOW
      6 -> listOf(activePlayers[0], activePlayers[1], activePlayers[2]) // RED, GREEN, YELLOW
      else -> listOf(activePlayers[0])
    }
  }

  val bottomRowPlayers = remember(activePlayers) {
    when (activePlayers.size) {
      2 -> listOf(activePlayers[1]) // GREEN
      3 -> listOf(activePlayers[2]) // YELLOW
      4 -> listOf(activePlayers[3], activePlayers[2]) // BLUE, YELLOW
      5 -> listOf(activePlayers[4], activePlayers[3]) // PURPLE, BLUE
      6 -> listOf(activePlayers[5], activePlayers[4], activePlayers[3]) // ORANGE, PURPLE, BLUE
      else -> listOf(activePlayers.last())
    }
  }

  fun onPlayerDiceRollClicked(player: LudoPlayer) {
    if (player != currentPlayer) return
    if (gameMode == LudoGameMode.ONLINE_PLAYING) {
      if (!isMyOnlineTurn || isRolling || hasRolled || isGameOver) return
      soundManager.playDiceRoll()
      firebaseManager.rollDiceSecure(
        roomCode = onlineRoomCode,
        onSuccess = { roll, forfeited ->
          diceValue = roll
          playerDiceValues[player] = roll
          hasRolled = !forfeited
        },
        onError = { err -> onlineError = err }
      )
    } else {
      if (isRolling || hasRolled || isGameOver) return
      rollDiceOffline()
    }
  }

  // UI Root
  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0A0718))
  ) {
    GameTopBar(
      title = if (gameMode == LudoGameMode.ONLINE_PLAYING) "Online Ludo ($playerCount P)" else "Ludo (${playerCount} Players)",
      isPaused = isPaused,
      isMuted = isMuted,
      onBack = {
        if (gameMode == LudoGameMode.ONLINE_PLAYING || (gameMode == LudoGameMode.OFFLINE && !isGameOver)) {
          showLeaveConfirmDialog = true
        } else if (gameMode != LudoGameMode.SELECTION) {
          gameMode = LudoGameMode.SELECTION
        } else {
          onBack()
        }
      },
      onPauseToggle = { isPaused = !isPaused },
      onRestart = { resetGame() },
      onMuteToggle = {
        isMuted = !isMuted
        soundManager.isSoundEnabled = !isMuted
      }
    )

    when (gameMode) {
      LudoGameMode.SELECTION -> {
        // Universal Player & Mode Selection Screen
        LazyColumn(
          modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp, vertical = 8.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          item {
            Text(
              text = "🎲 CLASSIC LUDO",
              fontSize = 30.sp,
              fontWeight = FontWeight.Black,
              color = Color.White
            )
            Text(
              text = "Standard 15x15 Symmetrical Board",
              fontSize = 13.sp,
              color = Color(0xFF00CEC9),
              fontWeight = FontWeight.SemiBold,
              modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
            )

            // Player Selection Section (2, 3, 4 Players)
            Text(
              text = "SELECT NUMBER OF PLAYERS",
              color = Color(0xFFA4B0BE),
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
            )

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              listOf(
                Pair(2, "2 Players"),
                Pair(3, "3 Players"),
                Pair(4, "4 Players"),
                Pair(5, "5 Players"),
                Pair(6, "6 Players")
              ).forEach { (count, label) ->
                val isSelected = playerCount == count
                Card(
                  modifier = Modifier
                    .weight(1f)
                    .clickable {
                      playerCount = count
                    },
                  shape = RoundedCornerShape(10.dp),
                  colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) Color(0xFF6C5CE7) else Color(0xFF1E1B38)
                  ),
                  border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, Color(0xFF00CEC9)) else null
                ) {
                  Column(
                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 2.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                  ) {
                    Text(
                      text = "$count P",
                      color = Color.White,
                      fontSize = 16.sp,
                      fontWeight = FontWeight.Black
                    )
                    Text(
                      text = label,
                      color = if (isSelected) Color.White else Color(0xFFA4B0BE),
                      fontSize = 8.sp,
                      fontWeight = FontWeight.Bold,
                      textAlign = TextAlign.Center
                    )
                  }
                }
              }
            }
          }

          item {
            // Mode 1: Pass & Play (Same Device)
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .clickable {
                  isAiMode = false
                  gameMode = LudoGameMode.OFFLINE
                  resetGame()
                },
              shape = RoundedCornerShape(14.dp),
              colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1B38))
            ) {
              Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Box(
                  modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF2ED573).copy(alpha = 0.2f)),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(
                    imageVector = Icons.Default.Group,
                    contentDescription = null,
                    tint = Color(0xFF2ED573),
                    modifier = Modifier.size(28.dp)
                  )
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = "Pass & Play (Same Device)",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                  )
                  Text(
                    text = "6 Friends play together taking turns on one phone (Recommended)",
                    color = Color(0xFFA4B0BE),
                    fontSize = 11.sp
                  )
                }
              }
            }
          }

          item {
            // Mode 2: vs Computer (AI)
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .clickable {
                  isAiMode = true
                  gameMode = LudoGameMode.OFFLINE
                  resetGame()
                },
              shape = RoundedCornerShape(14.dp),
              colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1B38))
            ) {
              Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Box(
                  modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF00CEC9).copy(alpha = 0.2f)),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(
                    imageVector = Icons.Default.Casino,
                    contentDescription = null,
                    tint = Color(0xFF00CEC9),
                    modifier = Modifier.size(28.dp)
                  )
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = "Play vs Computer (AI)",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                  )
                  Text(
                    text = "Play as Red against intelligent AI bots in a 6-player match",
                    color = Color(0xFFA4B0BE),
                    fontSize = 11.sp
                  )
                }
              }
            }
          }

          item {
            // Mode 3: Online Multiplayer
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .clickable {
                  onlineError = null
                  gameMode = LudoGameMode.ONLINE_LOBBY
                },
              shape = RoundedCornerShape(14.dp),
              colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1B38))
            ) {
              Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Box(
                  modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFE84118).copy(alpha = 0.2f)),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(
                    imageVector = Icons.Default.Public,
                    contentDescription = null,
                    tint = Color(0xFFE84118),
                    modifier = Modifier.size(28.dp)
                  )
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = "Online Multiplayer (6 Players)",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                  )
                  Text(
                    text = "Create or join custom rooms with synchronized dice & moves",
                    color = Color(0xFFA4B0BE),
                    fontSize = 11.sp
                  )
                }
              }
            }
          }

          item {
            // Start Direct 6-Player Match Button
            Button(
              onClick = {
                gameMode = LudoGameMode.OFFLINE
                resetGame()
              },
              modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .navigationBarsPadding(),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6C5CE7)),
              shape = RoundedCornerShape(12.dp)
            ) {
              Text(
                text = "▶ START 6-PLAYER LUDO",
                fontWeight = FontWeight.Black,
                fontSize = 15.sp,
                color = Color.White
              )
            }
          }
        }
      }

      LudoGameMode.ONLINE_LOBBY -> {
        // Online 6-Player Room Management
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Top
        ) {
          Text(
            text = "6-Player Online Multiplayer",
            color = Color.White,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "Player: ${currentUser?.displayName ?: currentUser?.email ?: "Guest"}",
            color = Color(0xFF00CEC9),
            fontSize = 13.sp,
            modifier = Modifier.padding(top = 2.dp, bottom = 14.dp)
          )

          onlineError?.let { err ->
            Text(
              text = "⚠️ $err",
              color = Color(0xFFFF5252),
              fontSize = 13.sp,
              modifier = Modifier.padding(bottom = 10.dp)
            )
          }

          // Create Room Card
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1B38))
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Text("Create a Room", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
              Spacer(modifier = Modifier.height(6.dp))
              Text("Select Player Capacity:", color = Color(0xFFA4B0BE), fontSize = 11.sp)
              Row(modifier = Modifier.padding(vertical = 6.dp)) {
                listOf(2, 3, 4, 5, 6).forEach { count ->
                  Box(
                    modifier = Modifier
                      .padding(end = 6.dp)
                      .clip(RoundedCornerShape(8.dp))
                      .background(if (playerCount == count) Color(0xFF6C5CE7) else Color(0xFF2C2750))
                      .clickable { playerCount = count }
                      .padding(horizontal = 12.dp, vertical = 6.dp)
                  ) {
                    Text("$count P", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                  }
                }
              }
              Button(
                onClick = {
                  onlineError = null
                  firebaseManager.createRoom(
                    playerCount = playerCount,
                    onSuccess = { code ->
                      onlineRoomCode = code
                      firebaseManager.listenToRoom(code, onStateUpdated = { state ->
                        onlineRoomState = state
                        if (state.status == "PLAYING") {
                          gameMode = LudoGameMode.ONLINE_PLAYING
                        }
                      }, onError = { err -> onlineError = err })
                    },
                    onError = { err -> onlineError = err }
                  )
                },
                modifier = Modifier.fillMaxWidth().testTag("create_ludo_room_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6C5CE7))
              ) {
                Text("CREATE ${playerCount}-PLAYER ROOM")
              }
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Join Room Card
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1B38))
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Text("Join Existing Room", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
              Spacer(modifier = Modifier.height(6.dp))
              OutlinedTextField(
                value = joinCodeInput,
                onValueChange = { joinCodeInput = it.uppercase().take(6) },
                label = { Text("6-Digit Room Code (e.g. AB7K92)") },
                modifier = Modifier.fillMaxWidth().testTag("ludo_join_code_input"),
                colors = OutlinedTextFieldDefaults.colors(
                  focusedBorderColor = Color(0xFF6C5CE7),
                  unfocusedBorderColor = Color(0xFF3B336A),
                  focusedTextColor = Color.White,
                  unfocusedTextColor = Color.White
                ),
                singleLine = true
              )
              Spacer(modifier = Modifier.height(8.dp))
              Button(
                onClick = {
                  if (joinCodeInput.length == 6) {
                    onlineError = null
                    onlineRoomCode = joinCodeInput
                    firebaseManager.joinRoom(
                      roomCode = joinCodeInput,
                      onSuccess = {
                        firebaseManager.listenToRoom(joinCodeInput, onStateUpdated = { state ->
                          onlineRoomState = state
                          if (state.status == "PLAYING") {
                            gameMode = LudoGameMode.ONLINE_PLAYING
                          }
                        }, onError = { err -> onlineError = err })
                      },
                      onError = { err -> onlineError = err }
                    )
                  } else {
                    onlineError = "Please enter a valid 6-character room code"
                  }
                },
                modifier = Modifier.fillMaxWidth().testTag("join_ludo_room_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00CEC9))
              ) {
                Text("JOIN ROOM", color = Color.Black, fontWeight = FontWeight.Bold)
              }
            }
          }

          // Active Room Waiting State
          onlineRoomState?.let { room ->
            if (room.status == "WAITING") {
              Spacer(modifier = Modifier.height(14.dp))
              Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF2C2750))
              ) {
                Column(
                  modifier = Modifier.padding(14.dp),
                  horizontalAlignment = Alignment.CenterHorizontally
                ) {
                  Text("ROOM CODE", color = Color(0xFFA4B0BE), fontSize = 11.sp)
                  Text(
                    text = room.roomCode,
                    color = Color(0xFFFFD32A),
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 4.sp
                  )
                  Text(
                    text = "Players joined: ${room.players.size}/${room.playerCount}",
                    color = Color.White,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(vertical = 4.dp)
                  )

                  // Player Slot Status based on LudoEngine configuration
                  val activeRoomPlayers = LudoEngine.getActivePlayers(room.playerCount)

                  Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    for (i in 0 until room.playerCount) {
                      val slotPlayer = room.players.values.firstOrNull { it.playerIndex == i }
                      val assignedLudoPlayer = activeRoomPlayers.getOrElse(i) { LudoPlayer.RED }
                      val colorName = assignedLudoPlayer.displayName.uppercase()
                      val colorVal = assignedLudoPlayer.color
                      Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                      ) {
                        Box(
                          modifier = Modifier.size(10.dp).clip(CircleShape).background(colorVal)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                          text = "Player ${i + 1} ($colorName): ",
                          color = Color.White,
                          fontSize = 11.sp,
                          fontWeight = FontWeight.Bold
                        )
                        Text(
                          text = slotPlayer?.name ?: "Waiting...",
                          color = if (slotPlayer != null) Color(0xFF00CEC9) else Color(0xFFA4B0BE),
                          fontSize = 11.sp
                        )
                      }
                    }
                  }

                  if (room.hostUid == currentUser?.uid) {
                    Button(
                      onClick = {
                        firebaseManager.startGame(room.roomCode, onError = { onlineError = it })
                      },
                      colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2ED573)),
                      modifier = Modifier.padding(top = 8.dp)
                    ) {
                      Text("START MATCH NOW")
                    }
                  } else {
                    Text("Waiting for host to start...", color = Color(0xFFA4B0BE), fontSize = 11.sp)
                  }
                }
              }
            }
          }
        }
      }

      LudoGameMode.OFFLINE, LudoGameMode.ONLINE_PLAYING -> {
        // Player options bar (For Offline)
        if (gameMode == LudoGameMode.OFFLINE) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 12.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text("Players: ", color = Color(0xFFA4B0BE), fontSize = 11.sp)
              listOf(2, 3, 4, 5, 6).forEach { count ->
                Box(
                  modifier = Modifier
                    .padding(horizontal = 4.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (playerCount == count) Color(0xFF6C5CE7) else Color(0xFF1E1B38))
                    .clickable {
                      playerCount = count
                      resetGame()
                    }
                    .padding(horizontal = 10.dp, vertical = 3.dp)
                ) {
                  Text("${count}P", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
              }
            }

            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(if (isAiMode) Color(0xFF00CEC9) else Color(0xFF2ED573))
                .clickable { isAiMode = !isAiMode }
                .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
              Text(
                if (isAiMode) "🤖 vs AI" else "👥 Pass & Play",
                color = Color.Black,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        } else {
          // Online Header
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 14.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("Room: $onlineRoomCode", color = Color(0xFFFFD32A), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(
              if (isMyOnlineTurn) "🟢 YOUR TURN" else "Waiting for Player...",
              color = if (isMyOnlineTurn) Color(0xFF2ED573) else Color(0xFFA4B0BE),
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp
            )
          }
        }

        // Current Turn Indicator Banner
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 2.dp),
          shape = RoundedCornerShape(10.dp),
          colors = CardDefaults.cardColors(containerColor = currentPlayer.color.copy(alpha = 0.22f)),
          border = androidx.compose.foundation.BorderStroke(1.5.dp, currentPlayer.color)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 10.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(16.dp)
                  .clip(CircleShape)
                  .background(currentPlayer.color)
                  .border(1.5.dp, Color.White, CircleShape)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Column {
                Text(
                  text = "${currentPlayer.displayName.uppercase()} PLAYER'S TURN ${if (isAiMode && currentPlayerIndex > 0 && gameMode == LudoGameMode.OFFLINE) "(AI)" else ""}",
                  color = Color.White,
                  fontWeight = FontWeight.Black,
                  fontSize = 11.sp
                )
                Text(
                  text = turnStatusMessage ?: when {
                    isRolling -> "Rolling dice..."
                    !hasRolled -> "TAP YOUR DICE TO ROLL 🎲"
                    movableTokens.isEmpty() -> "No valid moves with $diceValue"
                    else -> "TAP A GLOWING GUITI ON BOARD TO MOVE"
                  },
                  color = if (turnStatusMessage != null) Color(0xFFFFD32A) else Color(0xFFA4B0BE),
                  fontSize = 10.sp,
                  fontWeight = FontWeight.SemiBold
                )
              }
            }

            if (consecutiveSixes > 0) {
              Text(
                text = "Six streak: $consecutiveSixes/3",
                color = Color(0xFFFFD32A),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }

        // Top Player-Wise Dice Row (Visually connected to top player bases)
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 2.dp),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          topRowPlayers.forEach { player ->
            val isActive = (player == currentPlayer)
            val canRollPlayer = isActive && !hasRolled && !isGameOver && (gameMode != LudoGameMode.ONLINE_PLAYING || isMyOnlineTurn) && (!isAiMode || currentPlayerIndex == 0)
            PlayerDiceZone(
              player = player,
              isActiveTurn = isActive,
              canRoll = canRollPlayer,
              isRolling = isRolling && isActive,
              diceValue = playerDiceValues[player] ?: 6,
              finishedCount = tokens.count { it.player == player && it.isFinished(activePlayers.size) },
              hasRolled = hasRolled,
              isAi = isAiMode && activePlayers.indexOf(player) > 0,
              onRollDice = { onPlayerDiceRollClicked(player) },
              modifier = Modifier.weight(1f)
            )
          }
        }

        // Authentic Original Ludo Board Canvas
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
            .padding(horizontal = 6.dp, vertical = 2.dp),
          contentAlignment = Alignment.Center
        ) {
          LudoBoardView(
            tokens = tokens,
            activePlayers = activePlayers,
            currentPlayer = currentPlayer,
            movableTokens = movableTokens,
            onTokenClicked = { token ->
              if (movableTokens.contains(token)) {
                if (gameMode == LudoGameMode.ONLINE_PLAYING) {
                  firebaseManager.moveTokenSecure(
                    roomCode = onlineRoomCode,
                    tokenId = token.id,
                    onSuccess = {
                      soundManager.playMoveSound()
                    },
                    onError = { err -> onlineError = err }
                  )
                } else {
                  moveTokenOffline(token, diceValue)
                }
              }
            }
          )
        }

        // Bottom Player-Wise Zones (Player details & finish counters)
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 2.dp),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          bottomRowPlayers.forEach { player ->
            val isActive = (player == currentPlayer)
            val canRollPlayer = isActive && !hasRolled && !isGameOver && (gameMode != LudoGameMode.ONLINE_PLAYING || isMyOnlineTurn) && (!isAiMode || currentPlayerIndex == 0)
            PlayerDiceZone(
              player = player,
              isActiveTurn = isActive,
              canRoll = canRollPlayer,
              isRolling = isRolling && isActive,
              diceValue = playerDiceValues[player] ?: 6,
              finishedCount = tokens.count { it.player == player && it.isFinished(activePlayers.size) },
              hasRolled = hasRolled,
              isAi = isAiMode && activePlayers.indexOf(player) > 0,
              onRollDice = { onPlayerDiceRollClicked(player) },
              modifier = Modifier.weight(1f)
            )
          }
        }

        // Dedicated Prominent ROLL DICE Action Bar (Always safely above system navigation bar)
        val canMainRoll = !hasRolled && !isRolling && !isGameOver && (gameMode != LudoGameMode.ONLINE_PLAYING || isMyOnlineTurn) && (!isAiMode || currentPlayerIndex == 0)
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .testTag("ludo_main_dice_panel"),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFF191630)),
          border = androidx.compose.foundation.BorderStroke(2.dp, currentPlayer.color)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            // Player avatar badge & Turn status
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
              Box(
                modifier = Modifier
                  .size(38.dp)
                  .clip(CircleShape)
                  .background(currentPlayer.color)
                  .border(2.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = currentPlayer.displayName.take(1),
                  color = Color.White,
                  fontWeight = FontWeight.Black,
                  fontSize = 16.sp
                )
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = "${currentPlayer.displayName.uppercase()}'S TURN ${if (isAiMode && currentPlayerIndex > 0) "(AI)" else ""}",
                  color = Color.White,
                  fontWeight = FontWeight.Black,
                  fontSize = 13.sp
                )
                Text(
                  text = when {
                    isRolling -> "Rolling..."
                    !hasRolled -> "Tap ROLL to roll dice"
                    movableTokens.isNotEmpty() -> "Tap glowing token to move"
                    else -> "No legal move with $diceValue"
                  },
                  color = if (!hasRolled) Color(0xFFFFD32A) else if (movableTokens.isNotEmpty()) Color(0xFF2ED573) else Color(0xFFA4B0BE),
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }

            // Large Animated Dice
            LudoDiceView(
              value = diceValue,
              isRolling = isRolling,
              diceSize = 46.dp,
              highlightColor = currentPlayer.color,
              isLocked = hasRolled
            )

            Spacer(modifier = Modifier.width(10.dp))

            // Large, easy-to-tap ROLL DICE button
            Button(
              onClick = { onPlayerDiceRollClicked(currentPlayer) },
              enabled = canMainRoll,
              colors = ButtonDefaults.buttonColors(
                containerColor = currentPlayer.color,
                disabledContainerColor = Color(0xFF2A2542)
              ),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier
                .height(46.dp)
                .testTag("ludo_main_roll_dice_btn")
            ) {
              Text(
                text = if (isRolling) "ROLLING..." else "ROLL 🎲",
                fontSize = 14.sp,
                fontWeight = FontWeight.Black,
                color = if (canMainRoll) Color.White else Color(0xFF88849E)
              )
            }
          }
        }
      }
    }
  }

  // Leave Game Confirmation Dialog
  if (showLeaveConfirmDialog) {
    AlertDialog(
      onDismissRequest = { showLeaveConfirmDialog = false },
      title = { Text("Leave Ludo Match?") },
      text = { Text("Leaving will forfeit the current match progress.") },
      confirmButton = {
        Button(
          onClick = {
            showLeaveConfirmDialog = false
            if (gameMode == LudoGameMode.ONLINE_PLAYING) {
              firebaseManager.leaveRoom(onlineRoomCode)
            }
            gameMode = LudoGameMode.SELECTION
          },
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5252))
        ) {
          Text("Leave Game")
        }
      },
      dismissButton = {
        TextButton(onClick = { showLeaveConfirmDialog = false }) {
          Text("Continue Playing")
        }
      }
    )
  }

  if (isPaused) {
    GamePauseDialog(
      onResume = { isPaused = false },
      onRestart = {
        isPaused = false
        resetGame()
      },
      onExit = {
        if (gameMode != LudoGameMode.SELECTION) {
          gameMode = LudoGameMode.SELECTION
        } else {
          onBack()
        }
      }
    )
  }

  if (isGameOver) {
    val isWin = winnerPlayer == LudoPlayer.RED
    val resType = if (isWin) GameResultType.WIN else GameResultType.LOSS
    val s = if (isWin) 1000 else 250
    GameOverDialog(
      gameTitle = "Ludo (${winnerPlayer?.displayName ?: ""} Player Wins!)",
      resultType = resType,
      score = s,
      highScore = 1000,
      onPlayAgain = { resetGame() },
      onExit = {
        gameMode = LudoGameMode.SELECTION
      }
    )
  }
}
