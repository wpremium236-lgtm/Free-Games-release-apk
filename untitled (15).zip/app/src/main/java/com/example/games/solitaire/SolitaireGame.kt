package com.example.games.solitaire

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.games.common.GameOverDialog
import com.example.games.common.GamePauseDialog
import com.example.games.common.GameTopBar
import kotlinx.coroutines.delay

enum class Suit(val symbol: String, val isRed: Boolean) {
  HEARTS("♥", true),
  DIAMONDS("♦", true),
  CLUBS("♣", false),
  SPADES("♠", false)
}

data class PlayingCard(
  val rank: Int, // 1 (Ace) .. 13 (King)
  val suit: Suit,
  var isFaceUp: Boolean = false
) {
  val rankLabel: String
    get() = when (rank) {
      1 -> "A"
      11 -> "J"
      12 -> "Q"
      13 -> "K"
      else -> "$rank"
    }
}

@Composable
fun SolitaireGame(
  onBack: () -> Unit,
  onGameFinished: (score: Int) -> Unit
) {
  val context = LocalContext.current
  val soundManager = remember { SoundManager.getInstance(context) }
  var score by remember { mutableIntStateOf(0) }
  var timerSeconds by remember { mutableIntStateOf(0) }
  var isPaused by remember { mutableStateOf(false) }
  var isMuted by remember { mutableStateOf(!soundManager.isSoundEnabled) }
  var isGameOver by remember { mutableStateOf(false) }

  // 7 Tableau columns
  val tableaus = remember {
    List(7) { mutableStateListOf<PlayingCard>() }
  }

  // 4 Foundations (Hearts, Diamonds, Clubs, Spades)
  val foundations = remember {
    List(4) { mutableStateListOf<PlayingCard>() }
  }

  // Stock and Waste piles
  val stock = remember { mutableStateListOf<PlayingCard>() }
  val waste = remember { mutableStateListOf<PlayingCard>() }

  fun setupGame() {
    val deck = mutableListOf<PlayingCard>()
    Suit.values().forEach { suit ->
      for (r in 1..13) {
        deck.add(PlayingCard(rank = r, suit = suit, isFaceUp = false))
      }
    }
    deck.shuffle()

    tableaus.forEach { it.clear() }
    foundations.forEach { it.clear() }
    stock.clear()
    waste.clear()

    // Deal 7 tableau columns
    for (i in 0 until 7) {
      for (j in 0..i) {
        val card = deck.removeAt(0)
        card.isFaceUp = (j == i)
        tableaus[i].add(card)
      }
    }

    // Remaining to stock
    stock.addAll(deck)
    score = 0
    timerSeconds = 0
    isGameOver = false
  }

  remember {
    setupGame()
    true
  }

  fun drawFromStock() {
    soundManager.playCardSound()
    if (stock.isNotEmpty()) {
      val card = stock.removeAt(stock.size - 1)
      card.isFaceUp = true
      waste.add(card)
    } else {
      // Recycle waste back to stock
      while (waste.isNotEmpty()) {
        val c = waste.removeAt(waste.size - 1)
        c.isFaceUp = false
        stock.add(c)
      }
    }
  }

  fun canPlaceOnFoundation(card: PlayingCard, fIndex: Int): Boolean {
    val pile = foundations[fIndex]
    if (pile.isEmpty()) return card.rank == 1
    val top = pile.last()
    return top.suit == card.suit && card.rank == top.rank + 1
  }

  fun canPlaceOnTableau(card: PlayingCard, tIndex: Int): Boolean {
    val pile = tableaus[tIndex]
    if (pile.isEmpty()) return card.rank == 13 // Only King on empty spot
    val top = pile.last()
    if (!top.isFaceUp) return false
    return top.suit.isRed != card.suit.isRed && card.rank == top.rank - 1
  }

  fun checkWin() {
    if (foundations.all { it.size == 13 }) {
      isGameOver = true
      soundManager.playWinSound()
      val finalScore = maxOf(200, score + 1000 - timerSeconds * 2)
      onGameFinished(finalScore)
    }
  }

  fun tryAutoMoveCard(card: PlayingCard, sourceList: MutableList<PlayingCard>): Boolean {
    // 1. Try Foundation
    for (f in 0..3) {
      if (canPlaceOnFoundation(card, f)) {
        sourceList.remove(card)
        foundations[f].add(card)
        score += 15
        soundManager.playScoreBeep()
        checkWin()
        return true
      }
    }
    // 2. Try Tableau
    for (t in 0..6) {
      if (tableaus[t] !== sourceList && canPlaceOnTableau(card, t)) {
        sourceList.remove(card)
        tableaus[t].add(card)
        score += 5
        soundManager.playMoveSound()
        return true
      }
    }
    return false
  }

  fun onTableauCardClicked(columnIndex: Int, cardIndex: Int) {
    val pile = tableaus[columnIndex]
    val card = pile[cardIndex]
    if (!card.isFaceUp) {
      // If clicking top face-down card, flip it
      if (cardIndex == pile.size - 1) {
        card.isFaceUp = true
        soundManager.playCardSound()
        score += 5
      }
      return
    }

    // If clicking the top face-up card, try auto-move to foundation or tableau
    if (cardIndex == pile.size - 1) {
      if (tryAutoMoveCard(card, pile)) {
        if (pile.isNotEmpty()) pile.last().isFaceUp = true
        return
      }
    }

    // Or moving a cascade of cards to another tableau
    val subList = pile.subList(cardIndex, pile.size).toList()
    for (t in 0..6) {
      if (t != columnIndex && canPlaceOnTableau(subList.first(), t)) {
        tableaus[t].addAll(subList)
        for (k in subList.size - 1 downTo 0) {
          pile.removeAt(cardIndex + k)
        }
        if (pile.isNotEmpty()) pile.last().isFaceUp = true
        score += 10
        soundManager.playMoveSound()
        return
      }
    }
  }

  // Timer loop
  LaunchedEffect(isPaused, isGameOver) {
    while (!isPaused && !isGameOver) {
      delay(1000)
      timerSeconds++
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F0C20))
  ) {
    GameTopBar(
      title = "Solitaire",
      score = score,
      timeRemainingSec = timerSeconds,
      isPaused = isPaused,
      isMuted = isMuted,
      onBack = onBack,
      onPauseToggle = { isPaused = !isPaused },
      onRestart = { setupGame() },
      onMuteToggle = {
        isMuted = !isMuted
        soundManager.isSoundEnabled = !isMuted
      }
    )

    // Top Area: Stock/Waste & 4 Foundations
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 8.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Stock & Waste
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        // Stock
        Box(
          modifier = Modifier
            .size(42.dp, 58.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(if (stock.isNotEmpty()) Color(0xFF6C5CE7) else Color(0xFF1E1B38))
            .border(1.dp, Color(0xFF3B336A), RoundedCornerShape(6.dp))
            .clickable { drawFromStock() }
            .testTag("solitaire_stock"),
          contentAlignment = Alignment.Center
        ) {
          if (stock.isNotEmpty()) {
            Text("🂠", fontSize = 24.sp, color = Color.White)
          } else {
            Icon(Icons.Default.Refresh, contentDescription = "Recycle", tint = Color.Gray)
          }
        }

        // Waste
        Box(
          modifier = Modifier
            .size(42.dp, 58.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(if (waste.isNotEmpty()) Color.White else Color(0xFF141128))
            .border(1.dp, Color(0xFF3B336A), RoundedCornerShape(6.dp))
            .clickable(enabled = waste.isNotEmpty()) {
              if (waste.isNotEmpty()) {
                val card = waste.last()
                tryAutoMoveCard(card, waste)
              }
            }
            .testTag("solitaire_waste"),
          contentAlignment = Alignment.Center
        ) {
          waste.lastOrNull()?.let { card ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text(card.rankLabel, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = if (card.suit.isRed) Color(0xFFFF5252) else Color.Black)
              Text(card.suit.symbol, fontSize = 14.sp, color = if (card.suit.isRed) Color(0xFFFF5252) else Color.Black)
            }
          }
        }
      }

      // 4 Foundations
      Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        foundations.forEachIndexed { idx, pile ->
          Box(
            modifier = Modifier
              .size(40.dp, 56.dp)
              .clip(RoundedCornerShape(6.dp))
              .background(if (pile.isNotEmpty()) Color.White else Color(0xFF18152E))
              .border(1.dp, Color(0xFF3B336A), RoundedCornerShape(6.dp))
              .testTag("solitaire_found_$idx"),
            contentAlignment = Alignment.Center
          ) {
            val top = pile.lastOrNull()
            if (top != null) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(top.rankLabel, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = if (top.suit.isRed) Color(0xFFFF5252) else Color.Black)
                Text(top.suit.symbol, fontSize = 13.sp, color = if (top.suit.isRed) Color(0xFFFF5252) else Color.Black)
              }
            } else {
              Text("A", color = Color(0x44FFFFFF), fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }

    // 7 Tableau Columns
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .padding(horizontal = 6.dp)
        .verticalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      tableaus.forEachIndexed { colIndex, pile ->
        Box(
          modifier = Modifier
            .weight(1f)
            .padding(horizontal = 2.dp)
            .height(420.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF141128))
            .border(1.dp, Color(0xFF241F42), RoundedCornerShape(6.dp))
            .clickable {
              if (pile.isEmpty() && waste.isNotEmpty() && waste.last().rank == 13) {
                val card = waste.removeAt(waste.size - 1)
                pile.add(card)
                score += 5
                soundManager.playMoveSound()
              }
            }
        ) {
          pile.forEachIndexed { cardIndex, card ->
            Box(
              modifier = Modifier
                .offset(y = (cardIndex * 22).dp)
                .fillMaxWidth()
                .height(52.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(if (card.isFaceUp) Color.White else Color(0xFF6C5CE7))
                .border(1.dp, if (card.isFaceUp) Color(0xFFE2E8F0) else Color(0xFF4834D4), RoundedCornerShape(6.dp))
                .clickable { onTableauCardClicked(colIndex, cardIndex) }
                .testTag("tableau_${colIndex}_$cardIndex"),
              contentAlignment = Alignment.Center
            ) {
              if (card.isFaceUp) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                  Text(
                    card.rankLabel,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = if (card.suit.isRed) Color(0xFFFF5252) else Color.Black
                  )
                  Text(
                    card.suit.symbol,
                    fontSize = 12.sp,
                    color = if (card.suit.isRed) Color(0xFFFF5252) else Color.Black
                  )
                }
              } else {
                Text("🂠", color = Color.White.copy(alpha = 0.5f), fontSize = 16.sp)
              }
            }
          }
        }
      }
    }
  }

  if (isPaused) {
    GamePauseDialog(
      onResume = { isPaused = false },
      onRestart = { setupGame() },
      onExit = onBack
    )
  }

  if (isGameOver) {
    GameOverDialog(
      isWin = true,
      score = score,
      highScore = score,
      onPlayAgain = { setupGame() },
      onExit = onBack
    )
  }
}
