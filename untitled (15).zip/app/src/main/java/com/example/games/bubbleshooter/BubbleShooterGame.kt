package com.example.games.bubbleshooter

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.games.common.GameOverDialog
import com.example.games.common.GamePauseDialog
import com.example.games.common.GameTopBar
import kotlinx.coroutines.delay
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

val BubblePalette = listOf(
  Color(0xFFFF5252), // Red
  Color(0xFF00CEC9), // Cyan
  Color(0xFFFFB142), // Yellow
  Color(0xFF2ED573), // Green
  Color(0xFF9C88FF)  // Purple
)

data class GridBubble(
  val r: Int, val c: Int,
  var color: Color?
)

@Composable
fun BubbleShooterGame(
  onBack: () -> Unit,
  onGameFinished: (score: Int) -> Unit
) {
  val context = LocalContext.current
  val soundManager = remember { SoundManager.getInstance(context) }
  val numRows = 9
  val numCols = 8

  var score by remember { mutableIntStateOf(0) }
  var highScore by remember { mutableIntStateOf(0) }
  var isPaused by remember { mutableStateOf(false) }
  var isMuted by remember { mutableStateOf(!soundManager.isSoundEnabled) }
  var isGameOver by remember { mutableStateOf(false) }
  var hasWon by remember { mutableStateOf(false) }

  var currentBubbleColor by remember { mutableStateOf(BubblePalette.random()) }
  var nextBubbleColor by remember { mutableStateOf(BubblePalette.random()) }

  // Active shot projectile
  var projectilePos by remember { mutableStateOf<Offset?>(null) }
  var projectileVel by remember { mutableStateOf(Offset.Zero) }
  var aimAngle by remember { mutableFloatStateOf(-1.57f) } // default pointing up (-90 deg)

  val grid = remember {
    mutableStateListOf<GridBubble>().apply {
      for (r in 0 until numRows) {
        for (c in 0 until numCols) {
          val col = if (r < 4) BubblePalette.random() else null
          add(GridBubble(r, c, col))
        }
      }
    }
  }

  fun getBubble(r: Int, c: Int): GridBubble? {
    if (r !in 0 until numRows || c !in 0 until numCols) return null
    return grid[r * numCols + c]
  }

  fun resetGame() {
    grid.clear()
    for (r in 0 until numRows) {
      for (c in 0 until numCols) {
        val col = if (r < 4) BubblePalette.random() else null
        grid.add(GridBubble(r, c, col))
      }
    }
    currentBubbleColor = BubblePalette.random()
    nextBubbleColor = BubblePalette.random()
    projectilePos = null
    projectileVel = Offset.Zero
    score = 0
    isGameOver = false
    hasWon = false
  }

  fun findCluster(startR: Int, startC: Int, targetColor: Color): Set<Pair<Int, Int>> {
    val visited = mutableSetOf<Pair<Int, Int>>()
    val queue = mutableListOf(Pair(startR, startC))
    visited.add(Pair(startR, startC))
    val dirs = listOf(Pair(-1, 0), Pair(1, 0), Pair(0, -1), Pair(0, 1), Pair(-1, -1), Pair(-1, 1))

    while (queue.isNotEmpty()) {
      val (currR, currC) = queue.removeAt(0)
      for ((dr, dc) in dirs) {
        val nr = currR + dr
        val nc = currC + dc
        if (nr in 0 until numRows && nc in 0 until numCols) {
          val neighbor = getBubble(nr, nc)
          if (neighbor?.color == targetColor && !visited.contains(Pair(nr, nc))) {
            visited.add(Pair(nr, nc))
            queue.add(Pair(nr, nc))
          }
        }
      }
    }
    return visited
  }

  fun shoot() {
    if (projectilePos != null || isGameOver) return
    soundManager.playMoveSound()
    val speed = 26f
    projectileVel = Offset(cos(aimAngle) * speed, sin(aimAngle) * speed)
    projectilePos = Offset(0.5f, 0.92f)
  }

  fun attachBubble(hitR: Int, hitC: Int, color: Color) {
    val target = getBubble(hitR, hitC) ?: return
    target.color = color
    projectilePos = null
    projectileVel = Offset.Zero

    // Check cluster of 3+
    val cluster = findCluster(hitR, hitC, color)
    if (cluster.size >= 3) {
      soundManager.playCollisionSound()
      cluster.forEach { (cr, cc) ->
        getBubble(cr, cc)?.color = null
      }
      score += cluster.size * 20
      soundManager.playScoreBeep()
    }

    // Check if ceiling is cleared (Victory)
    if (grid.none { it.color != null }) {
      hasWon = true
      isGameOver = true
      soundManager.playWinSound()
      onGameFinished(score + 1000)
      return
    }

    // Check danger line reached (Row 8)
    if ((0 until numCols).any { getBubble(numRows - 1, it)?.color != null }) {
      isGameOver = true
      soundManager.playLoseSound()
      onGameFinished(score)
      return
    }

    currentBubbleColor = nextBubbleColor
    nextBubbleColor = BubblePalette.random()
  }

  // Physics animation loop for shot bubble
  LaunchedEffect(projectilePos, isPaused, isGameOver) {
    if (projectilePos == null || isPaused || isGameOver) return@LaunchedEffect
    while (projectilePos != null && !isPaused && !isGameOver) {
      delay(16)
      val pos = projectilePos ?: break

      var newX = pos.x + projectileVel.x / 500f
      var newY = pos.y + projectileVel.y / 700f

      // Wall bounce
      if (newX <= 0.05f || newX >= 0.95f) {
        projectileVel = Offset(-projectileVel.x, projectileVel.y)
        newX = newX.coerceIn(0.05f, 0.95f)
        soundManager.playButtonClick()
      }

      // Ceiling hit
      if (newY <= 0.06f) {
        val col = ((newX / 1f) * numCols).toInt().coerceIn(0, numCols - 1)
        attachBubble(0, col, currentBubbleColor)
        break
      }

      // Check collision with existing bubbles in grid
      val cellHeight = 0.07f
      val cellWidth = 1f / numCols
      var collided = false
      for (r in 0 until numRows) {
        for (c in 0 until numCols) {
          val b = getBubble(r, c)
          if (b?.color != null) {
            val bx = (c + 0.5f) * cellWidth
            val by = (r + 0.5f) * cellHeight
            val dist = sqrt((newX - bx) * (newX - bx) + (newY - by) * (newY - by))
            if (dist < cellWidth * 0.85f) {
              val targetR = (r + 1).coerceAtMost(numRows - 1)
              val targetC = c.coerceIn(0, numCols - 1)
              attachBubble(targetR, targetC, currentBubbleColor)
              collided = true
              break
            }
          }
        }
        if (collided) break
      }

      if (!collided) {
        projectilePos = Offset(newX, newY)
      }
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F0C20))
  ) {
    GameTopBar(
      title = "Bubble Shooter",
      score = score,
      highScore = highScore,
      isPaused = isPaused,
      isMuted = isMuted,
      onBack = onBack,
      onPauseToggle = { isPaused = !isPaused },
      onRestart = { resetGame() },
      onMuteToggle = {
        isMuted = !isMuted
        soundManager.isSoundEnabled = !isMuted
      }
    )

    // Canvas Playfield
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .padding(12.dp),
      contentAlignment = Alignment.Center
    ) {
      BoxWithConstraints(
        modifier = Modifier
          .fillMaxSize()
          .clip(RoundedCornerShape(16.dp))
          .background(Color(0xFF141128))
          .pointerInput(Unit) {
            detectDragGestures { change, _ ->
              change.consume()
              val touchPos = change.position
              val w = size.width
              val h = size.height
              val dx = touchPos.x - w / 2f
              val dy = touchPos.y - h * 0.92f
              if (dy < 0) {
                aimAngle = atan2(dy, dx)
              }
            }
          }
          .pointerInput(Unit) {
            detectTapGestures {
              shoot()
            }
          }
          .testTag("bubble_shooter_canvas")
      ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
          val w = size.width
          val h = size.height
          val bubbleRadius = (w / numCols) * 0.45f

          // Danger line at bottom
          drawLine(
            Color(0xFFFF5252).copy(alpha = 0.5f),
            Offset(0f, h * 0.75f),
            Offset(w, h * 0.75f),
            strokeWidth = 2f
          )

          // Draw Aiming Guide Line
          val aimEndX = w / 2f + cos(aimAngle) * 120f
          val aimEndY = h * 0.92f + sin(aimAngle) * 120f
          drawLine(
            Color.White.copy(alpha = 0.6f),
            Offset(w / 2f, h * 0.92f),
            Offset(aimEndX, aimEndY),
            strokeWidth = 3f
          )

          // Draw Grid Bubbles
          val cellW = w / numCols
          val cellH = h * 0.07f
          grid.forEach { bubble ->
            bubble.color?.let { color ->
              val cx = (bubble.c + 0.5f) * cellW
              val cy = (bubble.r + 0.5f) * cellH + 20f
              drawCircle(color, radius = bubbleRadius, center = Offset(cx, cy))
              drawCircle(Color.White.copy(alpha = 0.4f), radius = bubbleRadius * 0.35f, center = Offset(cx - 3f, cy - 3f))
            }
          }

          // Draw Active Shot Projectile
          projectilePos?.let { pos ->
            val px = pos.x * w
            val py = pos.y * h
            drawCircle(currentBubbleColor, radius = bubbleRadius, center = Offset(px, py))
          }

          // Draw Cannon Base & Loaded Bubble
          drawCircle(Color(0xFF241F42), radius = bubbleRadius * 1.5f, center = Offset(w / 2f, h * 0.92f))
          if (projectilePos == null) {
            drawCircle(currentBubbleColor, radius = bubbleRadius, center = Offset(w / 2f, h * 0.92f))
            drawCircle(Color.White.copy(alpha = 0.4f), radius = bubbleRadius * 0.35f, center = Offset(w / 2f - 3f, h * 0.92f - 3f))
          }
          // Draw Next Bubble Indicator
          drawCircle(nextBubbleColor, radius = bubbleRadius * 0.75f, center = Offset(w * 0.25f, h * 0.92f))
        }
      }
    }

    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 24.dp, vertical = 8.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text("Drag to Aim • Tap to Shoot", fontSize = 12.sp, color = Color(0xFFA4B0BE))
      Text("Clear the board!", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00CEC9))
    }
  }

  if (isPaused) {
    GamePauseDialog(
      onResume = { isPaused = false },
      onRestart = { resetGame() },
      onExit = onBack
    )
  }

  if (isGameOver) {
    GameOverDialog(
      isWin = hasWon,
      score = score,
      highScore = highScore,
      onPlayAgain = { resetGame() },
      onExit = onBack
    )
  }
}
