package com.example.games.fruitslicer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.games.common.GameOverDialog
import com.example.games.common.GamePauseDialog
import com.example.games.common.GameTopBar
import kotlinx.coroutines.delay
import kotlin.math.sqrt
import kotlin.random.Random

data class FlyingFruit(
  var x: Float,
  var y: Float,
  var vx: Float,
  var vy: Float,
  val icon: String,
  val isBomb: Boolean = false,
  var isSliced: Boolean = false
)

@Composable
fun FruitSlicerGame(
  onBack: () -> Unit,
  onGameFinished: (score: Int) -> Unit
) {
  val context = LocalContext.current
  val soundManager = remember { SoundManager.getInstance(context) }
  var score by remember { mutableIntStateOf(0) }
  var lives by remember { mutableIntStateOf(3) }
  var highScore by remember { mutableIntStateOf(0) }
  var isPaused by remember { mutableStateOf(false) }
  var isMuted by remember { mutableStateOf(!soundManager.isSoundEnabled) }
  var isGameOver by remember { mutableStateOf(false) }

  val fruits = remember { mutableStateListOf<FlyingFruit>() }
  val swipeTrail = remember { mutableStateListOf<Offset>() }
  val fruitIcons = listOf("🍉", "🍎", "🍌", "🍓", "🍍", "🍇")

  fun resetGame() {
    fruits.clear()
    swipeTrail.clear()
    score = 0
    lives = 3
    isGameOver = false
  }

  fun checkSlice(p1: Offset, p2: Offset, canvasW: Float, canvasH: Float) {
    val iterator = fruits.iterator()
    while (iterator.hasNext()) {
      val f = iterator.next()
      if (!f.isSliced) {
        val fx = f.x * canvasW
        val fy = f.y * canvasH
        val midX = (p1.x + p2.x) / 2
        val midY = (p1.y + p2.y) / 2
        val dist = sqrt((fx - midX) * (fx - midX) + (fy - midY) * (fy - midY))
        if (dist < 55f) {
          f.isSliced = true
          if (f.isBomb) {
            soundManager.playCollisionSound()
            soundManager.playLoseSound()
            isGameOver = true
            onGameFinished(score)
            break
          } else {
            score += 10
            soundManager.playScoreBeep()
          }
        }
      }
    }
  }

  // Game loop (Spawning fruits & physics)
  LaunchedEffect(isPaused, isGameOver) {
    var tick = 0
    while (!isPaused && !isGameOver) {
      delay(20)
      tick++

      if (swipeTrail.size > 8) {
        swipeTrail.removeAt(0)
      }

      // Spawn fruits
      if (tick % 50 == 0) {
        val isBomb = Random.nextFloat() < 0.20f
        val spawnX = Random.nextFloat() * 0.6f + 0.2f
        val vx = (0.5f - spawnX) * 0.015f
        val vy = -0.022f - Random.nextFloat() * 0.006f
        fruits.add(
          FlyingFruit(
            x = spawnX,
            y = 1.05f,
            vx = vx,
            vy = vy,
            icon = if (isBomb) "💣" else fruitIcons.random(),
            isBomb = isBomb
          )
        )
      }

      // Update positions
      val iterator = fruits.iterator()
      while (iterator.hasNext()) {
        val f = iterator.next()
        f.x += f.vx
        f.y += f.vy
        f.vy += 0.0006f // Gravity

        // Fall out of bottom
        if (f.y > 1.15f) {
          if (!f.isSliced && !f.isBomb) {
            lives--
            soundManager.playLoseSound()
            if (lives <= 0) {
              isGameOver = true
              onGameFinished(score)
              break
            }
          }
          iterator.remove()
        }
      }
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F0C20))
  ) {
    GameTopBar(
      title = "Fruit Slicer",
      score = score,
      highScore = highScore,
      lives = lives,
      isPaused = isPaused,
      isMuted = isMuted,
      onBack = onBack,
      onPauseToggle = { isPaused = !isPaused },
      onRestart = { resetGame() },
      onMuteToggle = {
        isMuted = !isMuted
        soundManager.isSoundEnabled = !isMuted
      }
    )

    // Canvas Playfield with Swipe Blade
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .padding(12.dp),
      contentAlignment = Alignment.Center
    ) {
      BoxWithConstraints(
        modifier = Modifier
          .fillMaxSize()
          .clip(RoundedCornerShape(16.dp))
          .background(Color(0xFF141926))
          .pointerInput(Unit) {
            detectDragGestures(
              onDragStart = { offset ->
                swipeTrail.clear()
                swipeTrail.add(offset)
              },
              onDrag = { change, _ ->
                change.consume()
                val newPt = change.position
                if (swipeTrail.isNotEmpty()) {
                  val lastPt = swipeTrail.last()
                  checkSlice(lastPt, newPt, size.width.toFloat(), size.height.toFloat())
                }
                swipeTrail.add(newPt)
              },
              onDragEnd = {
                swipeTrail.clear()
              }
            )
          }
          .testTag("fruit_slicer_canvas")
      ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
          for (i in 0 until swipeTrail.size - 1) {
            val p1 = swipeTrail[i]
            val p2 = swipeTrail[i + 1]
            drawLine(
              color = Color.White.copy(alpha = (i + 1f) / swipeTrail.size),
              start = p1,
              end = p2,
              strokeWidth = 6f
            )
          }
        }

        // Render fruit texts
        fruits.forEach { f ->
          if (!f.isSliced) {
            Box(
              modifier = Modifier
                .offset(
                  x = (maxWidth * f.x) - 24.dp,
                  y = (maxHeight * f.y) - 24.dp
                )
            ) {
              Text(f.icon, fontSize = 38.sp)
            }
          } else {
            Box(
              modifier = Modifier
                .offset(
                  x = (maxWidth * f.x) - 34.dp,
                  y = (maxHeight * f.y) - 24.dp
                )
            ) {
              Text("✨", fontSize = 32.sp)
            }
          }
        }
      }
    }

    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 12.dp),
      horizontalArrangement = Arrangement.Center
    ) {
      Text("SWIPE ACROSS FRUITS • AVOID BOMBS 💣", fontSize = 12.sp, color = Color(0xFFA4B0BE), fontWeight = FontWeight.Bold)
    }
  }

  if (isPaused) {
    GamePauseDialog(
      onResume = { isPaused = false },
      onRestart = { resetGame() },
      onExit = onBack
    )
  }

  if (isGameOver) {
    GameOverDialog(
      isWin = false,
      score = score,
      highScore = highScore,
      onPlayAgain = { resetGame() },
      onExit = onBack
    )
  }
}
