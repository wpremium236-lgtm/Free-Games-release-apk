package com.example.games.minesweeper

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.core.model.GameDifficulty
import com.example.core.model.GameResultType
import com.example.games.common.GameOverDialog
import com.example.games.common.GamePauseDialog
import com.example.games.common.GameTopBar
import kotlinx.coroutines.delay
import java.util.UUID
import kotlin.random.Random

data class MineCell(
  val r: Int,
  val c: Int,
  var isMine: Boolean = false,
  var isRevealed: Boolean = false,
  var isFlagged: Boolean = false,
  var adjacentMines: Int = 0
)

@Composable
fun MinesweeperGame(
  onBack: () -> Unit,
  onGameFinished: (gameId: String, score: Int, resultType: GameResultType, duration: Long, sessionId: String) -> Unit
) {
  val context = LocalContext.current
  val soundManager = remember { SoundManager.getInstance(context) }
  var sessionId by remember { mutableStateOf(UUID.randomUUID().toString()) }
  var startTimeMs by remember { mutableStateOf(System.currentTimeMillis()) }
  var hasSubmittedSession by remember { mutableStateOf(false) }

  var difficulty by remember { mutableStateOf(GameDifficulty.EASY) }
  val (rows, cols, totalMines) = when (difficulty) {
    GameDifficulty.EASY -> Triple(8, 8, 10)
    GameDifficulty.MEDIUM -> Triple(10, 10, 20)
    GameDifficulty.HARD -> Triple(12, 12, 35)
  }

  var isFlagMode by remember { mutableStateOf(false) }
  var timerSeconds by remember { mutableIntStateOf(0) }
  var isPaused by remember { mutableStateOf(false) }
  var isMuted by remember { mutableStateOf(!soundManager.isSoundEnabled) }
  var isGameOver by remember { mutableStateOf(false) }
  var hasWon by remember { mutableStateOf(false) }
  var firstClickDone by remember { mutableStateOf(false) }

  fun triggerGameFinished(resultType: GameResultType, finalScore: Int) {
    if (!hasSubmittedSession) {
      hasSubmittedSession = true
      val duration = timerSeconds.toLong().coerceAtLeast(1L)
      onGameFinished("minesweeper", finalScore, resultType, duration, sessionId)
    }
  }

  val grid = remember(difficulty) {
    mutableStateListOf<MineCell>().apply {
      for (r in 0 until rows) {
        for (c in 0 until cols) {
          add(MineCell(r, c))
        }
      }
    }
  }

  fun getCell(r: Int, c: Int): MineCell? {
    if (r !in 0 until rows || c !in 0 until cols) return null
    return grid[r * cols + c]
  }

  fun populateMines(safeR: Int, safeC: Int) {
    var placed = 0
    while (placed < totalMines) {
      val r = Random.nextInt(rows)
      val c = Random.nextInt(cols)
      if (r == safeR && c == safeC) continue
      val cell = getCell(r, c)
      if (cell != null && !cell.isMine) {
        cell.isMine = true
        placed++
      }
    }

    // Calculate adjacencies
    for (r in 0 until rows) {
      for (c in 0 until cols) {
        val cell = getCell(r, c) ?: continue
        if (cell.isMine) continue
        var count = 0
        for (dr in -1..1) {
          for (dc in -1..1) {
            if (dr == 0 && dc == 0) continue
            if (getCell(r + dr, c + dc)?.isMine == true) count++
          }
        }
        cell.adjacentMines = count
      }
    }
  }

  fun revealCascade(r: Int, c: Int) {
    val cell = getCell(r, c) ?: return
    if (cell.isRevealed || cell.isFlagged) return
    cell.isRevealed = true
    if (cell.adjacentMines == 0 && !cell.isMine) {
      for (dr in -1..1) {
        for (dc in -1..1) {
          if (dr == 0 && dc == 0) continue
          revealCascade(r + dr, c + dc)
        }
      }
    }
  }

  fun checkWin() {
    val nonMineCount = rows * cols - totalMines
    val revealedCount = grid.count { it.isRevealed && !it.isMine }
    if (revealedCount == nonMineCount) {
      hasWon = true
      isGameOver = true
      soundManager.playWinSound()
      val score = maxOf(100, 1000 - timerSeconds * 3)
      triggerGameFinished(GameResultType.WIN, score)
    }
  }

  fun handleCellClick(cell: MineCell) {
    if (cell.isRevealed || isGameOver) return
    if (isFlagMode) {
      cell.isFlagged = !cell.isFlagged
      soundManager.playButtonClick()
      return
    }
    if (cell.isFlagged) return

    if (!firstClickDone) {
      firstClickDone = true
      populateMines(cell.r, cell.c)
    }

    if (cell.isMine) {
      // Game over hit mine
      grid.forEach { if (it.isMine) it.isRevealed = true }
      isGameOver = true
      hasWon = false
      soundManager.playCollisionSound()
      soundManager.playLoseSound()
      triggerGameFinished(GameResultType.LOSS, 0)
    } else {
      revealCascade(cell.r, cell.c)
      soundManager.playMoveSound()
      checkWin()
    }
  }

  fun resetGame() {
    grid.clear()
    for (r in 0 until rows) {
      for (c in 0 until cols) {
        grid.add(MineCell(r, c))
      }
    }
    firstClickDone = false
    timerSeconds = 0
    isGameOver = false
    hasWon = false
    sessionId = UUID.randomUUID().toString()
    startTimeMs = System.currentTimeMillis()
    hasSubmittedSession = false
  }

  // Timer loop
  LaunchedEffect(firstClickDone, isPaused, isGameOver) {
    if (!firstClickDone) return@LaunchedEffect
    while (!isPaused && !isGameOver) {
      delay(1000)
      timerSeconds++
    }
  }

  val remainingFlags = totalMines - grid.count { it.isFlagged }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F0C20))
  ) {
    GameTopBar(
      title = "Minesweeper",
      score = remainingFlags,
      timeRemainingSec = timerSeconds,
      isPaused = isPaused,
      isMuted = isMuted,
      onBack = onBack,
      onPauseToggle = { isPaused = !isPaused },
      onRestart = { resetGame() },
      onMuteToggle = {
        isMuted = !isMuted
        soundManager.isSoundEnabled = !isMuted
      }
    )

    // Controls bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row {
        listOf(GameDifficulty.EASY, GameDifficulty.MEDIUM, GameDifficulty.HARD).forEach { diff ->
          Text(
            text = diff.labelEn,
            fontSize = 12.sp,
            color = if (difficulty == diff) Color(0xFF00CEC9) else Color(0xFFA4B0BE),
            fontWeight = if (difficulty == diff) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier
              .padding(end = 12.dp)
              .clickable {
                difficulty = diff
                resetGame()
              }
          )
        }
      }

      Button(
        onClick = { isFlagMode = !isFlagMode },
        colors = ButtonDefaults.buttonColors(containerColor = if (isFlagMode) Color(0xFFFF5252) else Color(0xFF241F42)),
        modifier = Modifier.height(34.dp).testTag("minesweeper_flag_mode_btn")
      ) {
        Icon(Icons.Default.Flag, contentDescription = "Flag Mode", tint = Color.White, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(if (isFlagMode) "FLAG MODE" else "DIG MODE", fontSize = 11.sp, fontWeight = FontWeight.Bold)
      }
    }

    // Grid View
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .padding(12.dp),
      contentAlignment = Alignment.Center
    ) {
      BoxWithConstraints(
        modifier = Modifier
          .aspectRatio(1f)
          .clip(RoundedCornerShape(12.dp))
          .background(Color(0xFF18152E))
          .border(2.dp, Color(0xFF3B336A), RoundedCornerShape(12.dp))
          .padding(4.dp)
      ) {
        Column(modifier = Modifier.fillMaxSize()) {
          for (r in 0 until rows) {
            Row(modifier = Modifier.weight(1f)) {
              for (c in 0 until cols) {
                val cell = getCell(r, c) ?: continue
                Box(
                  modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .padding(1.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(
                      when {
                        cell.isRevealed && cell.isMine -> Color(0xFFFF5252)
                        cell.isRevealed -> Color(0xFF141128)
                        else -> Color(0xFF241F42)
                      }
                    )
                    .pointerInput(cell) {
                      detectTapGestures(
                        onTap = { handleCellClick(cell) },
                        onLongPress = {
                          if (!cell.isRevealed) {
                            cell.isFlagged = !cell.isFlagged
                            soundManager.playButtonClick()
                          }
                        }
                      )
                    }
                    .testTag("mine_cell_${r}_${c}"),
                  contentAlignment = Alignment.Center
                ) {
                  if (cell.isFlagged) {
                    Text("🚩", fontSize = 12.sp)
                  } else if (cell.isRevealed) {
                    if (cell.isMine) {
                      Text("💣", fontSize = 12.sp)
                    } else if (cell.adjacentMines > 0) {
                      val color = when (cell.adjacentMines) {
                        1 -> Color(0xFF00A8FF)
                        2 -> Color(0xFF44BD32)
                        3 -> Color(0xFFFF5252)
                        4 -> Color(0xFF9C88FF)
                        else -> Color(0xFFFFB142)
                      }
                      Text(
                        "${cell.adjacentMines}",
                        fontWeight = FontWeight.Bold,
                        color = color,
                        fontSize = 13.sp
                      )
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  if (isPaused) {
    GamePauseDialog(
      onResume = { isPaused = false },
      onRestart = { resetGame() },
      onExit = onBack
    )
  }

  if (isGameOver) {
    val score = if (hasWon) maxOf(100, 1000 - timerSeconds * 3) else 0
    GameOverDialog(
      gameTitle = "Minesweeper",
      resultType = if (hasWon) GameResultType.WIN else GameResultType.LOSS,
      score = score,
      highScore = score,
      durationSec = timerSeconds.toLong(),
      onPlayAgain = { resetGame() },
      onExit = onBack
    )
  }
}
