package com.example.games.knifehit

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.games.common.GameOverDialog
import com.example.games.common.GamePauseDialog
import com.example.games.common.GameTopBar
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun KnifeHitGame(
  onBack: () -> Unit,
  onGameFinished: (score: Int) -> Unit
) {
  val context = LocalContext.current
  val soundManager = remember { SoundManager.getInstance(context) }
  var currentStage by remember { mutableIntStateOf(1) }
  var knivesRemaining by remember { mutableIntStateOf(7) }
  var score by remember { mutableIntStateOf(0) }
  var highScore by remember { mutableIntStateOf(0) }
  var isPaused by remember { mutableStateOf(false) }
  var isMuted by remember { mutableStateOf(!soundManager.isSoundEnabled) }
  var isGameOver by remember { mutableStateOf(false) }

  var isFlyingKnife by remember { mutableStateOf(false) }
  var flyingKnifeY by remember { mutableFloatStateOf(0.85f) }

  // Target log rotation angle in radians
  var targetAngle by remember { mutableFloatStateOf(0f) }
  var rotSpeed by remember { mutableFloatStateOf(0.04f) }

  val embeddedKnifeAngles = remember { mutableStateListOf<Float>() }

  fun setupStage(stage: Int) {
    embeddedKnifeAngles.clear()
    knivesRemaining = 6 + stage
    if (stage > 1) {
      embeddedKnifeAngles.add(0f)
      if (stage > 2) embeddedKnifeAngles.add(PI.toFloat())
    }
    rotSpeed = if (stage % 2 == 0) -0.05f else 0.045f
    isFlyingKnife = false
    flyingKnifeY = 0.85f
  }

  fun resetGame() {
    currentStage = 1
    score = 0
    setupStage(1)
    isGameOver = false
  }

  remember {
    setupStage(1)
    true
  }

  fun throwKnife() {
    if (isFlyingKnife || knivesRemaining <= 0 || isGameOver) return
    soundManager.playMoveSound()
    isFlyingKnife = true
    flyingKnifeY = 0.85f
  }

  // Target rotation and flying knife loop
  LaunchedEffect(isPaused, isGameOver, rotSpeed) {
    while (!isPaused && !isGameOver) {
      delay(16)
      targetAngle = (targetAngle + rotSpeed) % (2f * PI.toFloat())

      if (isFlyingKnife) {
        flyingKnifeY -= 0.07f

        // Check impact with log (log bottom is at y = 0.38f)
        if (flyingKnifeY <= 0.38f) {
          isFlyingKnife = false
          flyingKnifeY = 0.85f
          knivesRemaining--

          val hitAngle = (PI.toFloat() / 2f - targetAngle + 2f * PI.toFloat()) % (2f * PI.toFloat())
          val minAngularDist = 0.22f
          val hitAnotherKnife = embeddedKnifeAngles.any { angle ->
            val diff = abs(angle - hitAngle)
            val circDiff = if (diff > PI.toFloat()) 2f * PI.toFloat() - diff else diff
            circDiff < minAngularDist
          }

          if (hitAnotherKnife) {
            isGameOver = true
            soundManager.playCollisionSound()
            soundManager.playLoseSound()
            onGameFinished(score)
          } else {
            embeddedKnifeAngles.add(hitAngle)
            score += 10
            soundManager.playScoreBeep()

            if (knivesRemaining <= 0) {
              soundManager.playWinSound()
              score += 100
              currentStage++
              setupStage(currentStage)
            }
          }
        }
      }
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F0C20))
  ) {
    GameTopBar(
      title = "Knife Hit",
      score = score,
      highScore = highScore,
      lives = knivesRemaining,
      isPaused = isPaused,
      isMuted = isMuted,
      onBack = onBack,
      onPauseToggle = { isPaused = !isPaused },
      onRestart = { resetGame() },
      onMuteToggle = {
        isMuted = !isMuted
        soundManager.isSoundEnabled = !isMuted
      }
    )

    // Stage Info
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text("STAGE $currentStage", color = Color(0xFFFFB142), fontWeight = FontWeight.Bold, fontSize = 14.sp)
      Text("Knives: $knivesRemaining", color = Color(0xFF00CEC9), fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }

    // Canvas Playfield
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .padding(16.dp),
      contentAlignment = Alignment.Center
    ) {
      BoxWithConstraints(
        modifier = Modifier
          .fillMaxSize()
          .clip(RoundedCornerShape(16.dp))
          .background(Color(0xFF141926))
          .pointerInput(Unit) {
            detectTapGestures {
              throwKnife()
            }
          }
          .testTag("knife_hit_canvas")
      ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
          val w = size.width
          val h = size.height
          val logCenterX = w / 2f
          val logCenterY = h * 0.30f
          val logRadius = w * 0.22f

          // Draw Rotating Log Base
          drawCircle(Color(0xFF634123), radius = logRadius, center = Offset(logCenterX, logCenterY))
          drawCircle(Color(0xFF4B2E15), radius = logRadius * 0.85f, center = Offset(logCenterX, logCenterY))
          drawCircle(Color(0xFF8B5A2B), radius = logRadius * 0.4f, center = Offset(logCenterX, logCenterY))

          // Draw Embedded Knives sticking out of the log
          embeddedKnifeAngles.forEach { angleOffset ->
            val totalAngle = angleOffset + targetAngle
            val kx = logCenterX + cos(totalAngle) * logRadius
            val ky = logCenterY + sin(totalAngle) * logRadius
            val tipX = logCenterX + cos(totalAngle) * (logRadius + 45f)
            val tipY = logCenterY + sin(totalAngle) * (logRadius + 45f)
            drawLine(Color(0xFFDFE6E9), Offset(kx, ky), Offset(tipX, tipY), strokeWidth = 5f)
            // Handle
            val hx = logCenterX + cos(totalAngle) * (logRadius + 60f)
            val hy = logCenterY + sin(totalAngle) * (logRadius + 60f)
            drawLine(Color(0xFFE84118), Offset(tipX, tipY), Offset(hx, hy), strokeWidth = 8f)
          }

          // Draw Ready / Flying Knife at bottom
          val knifeY = if (isFlyingKnife) flyingKnifeY * h else h * 0.85f
          val knifeX = w / 2f
          // Blade
          drawRoundRect(
            Color(0xFFDFE6E9),
            topLeft = Offset(knifeX - 4f, knifeY - 40f),
            size = Size(8f, 40f),
            cornerRadius = CornerRadius(3f)
          )
          // Handle
          drawRoundRect(
            Color(0xFFE84118),
            topLeft = Offset(knifeX - 6f, knifeY),
            size = Size(12f, 25f),
            cornerRadius = CornerRadius(4f)
          )
        }
      }
    }

    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 12.dp),
      horizontalArrangement = Arrangement.Center
    ) {
      Text("TAP ANYWHERE TO THROW KNIFE", fontSize = 12.sp, color = Color(0xFFA4B0BE), fontWeight = FontWeight.Bold)
    }
  }

  if (isPaused) {
    GamePauseDialog(
      onResume = { isPaused = false },
      onRestart = { resetGame() },
      onExit = onBack
    )
  }

  if (isGameOver) {
    GameOverDialog(
      isWin = false,
      score = score,
      highScore = highScore,
      onPlayAgain = { resetGame() },
      onExit = onBack
    )
  }
}
