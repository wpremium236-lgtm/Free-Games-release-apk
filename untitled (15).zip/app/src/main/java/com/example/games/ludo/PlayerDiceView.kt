package com.example.games.ludo

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * 3D Pip Dice View that renders authentic dots (1..6) and rolling rotation animation.
 */
@Composable
fun LudoDiceView(
  value: Int,
  isRolling: Boolean,
  diceSize: Dp = 44.dp,
  highlightColor: Color = Color(0xFF6C5CE7),
  isLocked: Boolean = false,
  modifier: Modifier = Modifier
) {
  val rotationAnim = remember { Animatable(0f) }

  LaunchedEffect(isRolling) {
    if (isRolling) {
      rotationAnim.animateTo(
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
          animation = tween(220, easing = LinearEasing),
          repeatMode = RepeatMode.Restart
        )
      )
    } else {
      rotationAnim.snapTo(0f)
    }
  }

  val displayValue = value.coerceIn(1, 6)
  val alpha = if (isLocked) 0.45f else 1.0f

  Box(
    modifier = modifier
      .size(diceSize)
      .rotate(if (isRolling) rotationAnim.value else 0f)
      .shadow(elevation = if (isLocked) 1.dp else 4.dp, shape = RoundedCornerShape(10.dp))
      .clip(RoundedCornerShape(10.dp))
      .background(
        Brush.linearGradient(
          colors = if (isLocked) {
            listOf(Color(0xFF333044), Color(0xFF252233))
          } else {
            listOf(Color(0xFFFFFFFF), Color(0xFFE8E8E8))
          }
        )
      )
      .border(
        width = if (!isLocked && highlightColor != Color.Transparent) 2.5.dp else 1.dp,
        color = if (isLocked) Color(0xFF4A4466) else highlightColor,
        shape = RoundedCornerShape(10.dp)
      ),
    contentAlignment = Alignment.Center
  ) {
    Canvas(modifier = Modifier.size(diceSize)) {
      val w = size.width
      val h = size.height
      val pipRadius = w * 0.088f
      val pipColor = if (isLocked) Color(0xFF756F8C) else Color(0xFF1E1B2E)

      val left = w * 0.25f
      val center = w * 0.5f
      val right = w * 0.75f

      val top = h * 0.25f
      val middle = h * 0.5f
      val bottom = h * 0.75f

      when (displayValue) {
        1 -> {
          drawCircle(pipColor.copy(alpha = alpha), pipRadius * 1.15f, Offset(center, middle))
        }
        2 -> {
          drawCircle(pipColor.copy(alpha = alpha), pipRadius, Offset(left, top))
          drawCircle(pipColor.copy(alpha = alpha), pipRadius, Offset(right, bottom))
        }
        3 -> {
          drawCircle(pipColor.copy(alpha = alpha), pipRadius, Offset(left, top))
          drawCircle(pipColor.copy(alpha = alpha), pipRadius, Offset(center, middle))
          drawCircle(pipColor.copy(alpha = alpha), pipRadius, Offset(right, bottom))
        }
        4 -> {
          drawCircle(pipColor.copy(alpha = alpha), pipRadius, Offset(left, top))
          drawCircle(pipColor.copy(alpha = alpha), pipRadius, Offset(right, top))
          drawCircle(pipColor.copy(alpha = alpha), pipRadius, Offset(left, bottom))
          drawCircle(pipColor.copy(alpha = alpha), pipRadius, Offset(right, bottom))
        }
        5 -> {
          drawCircle(pipColor.copy(alpha = alpha), pipRadius, Offset(left, top))
          drawCircle(pipColor.copy(alpha = alpha), pipRadius, Offset(right, top))
          drawCircle(pipColor.copy(alpha = alpha), pipRadius, Offset(center, middle))
          drawCircle(pipColor.copy(alpha = alpha), pipRadius, Offset(left, bottom))
          drawCircle(pipColor.copy(alpha = alpha), pipRadius, Offset(right, bottom))
        }
        6 -> {
          drawCircle(pipColor.copy(alpha = alpha), pipRadius, Offset(left, top))
          drawCircle(pipColor.copy(alpha = alpha), pipRadius, Offset(right, top))
          drawCircle(pipColor.copy(alpha = alpha), pipRadius, Offset(left, middle))
          drawCircle(pipColor.copy(alpha = alpha), pipRadius, Offset(right, middle))
          drawCircle(pipColor.copy(alpha = alpha), pipRadius, Offset(left, bottom))
          drawCircle(pipColor.copy(alpha = alpha), pipRadius, Offset(right, bottom))
        }
      }
    }
  }
}

/**
 * Individual Player Home/Profile Zone with their visually connected personal Dice.
 * Displays player color, name, turn status, finished token counter, and interactive/locked dice.
 */
@Composable
fun PlayerDiceZone(
  player: LudoPlayer,
  isActiveTurn: Boolean,
  canRoll: Boolean,
  isRolling: Boolean,
  diceValue: Int,
  finishedCount: Int,
  hasRolled: Boolean,
  isAi: Boolean,
  onRollDice: () -> Unit,
  modifier: Modifier = Modifier
) {
  val infiniteTransition = rememberInfiniteTransition(label = "diceGlow")
  val diceScale by infiniteTransition.animateFloat(
    initialValue = 1f,
    targetValue = 1.14f,
    animationSpec = infiniteRepeatable(
      animation = tween(450, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "dicePulse"
  )

  val isDiceClickable = isActiveTurn && canRoll && !isRolling

  Card(
    modifier = modifier
      .testTag("player_zone_${player.name.lowercase()}"),
    shape = RoundedCornerShape(10.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (isActiveTurn) {
        player.color.copy(alpha = 0.22f)
      } else {
        Color(0xFF141224)
      }
    ),
    border = androidx.compose.foundation.BorderStroke(
      width = if (isActiveTurn) 2.dp else 1.dp,
      color = if (isActiveTurn) player.color else Color(0xFF2C2744)
    )
  ) {
    Row(
      modifier = Modifier
        .padding(horizontal = 6.dp, vertical = 4.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      // Left: Player info & status
      Column(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.Center
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(10.dp)
              .clip(CircleShape)
              .background(player.color)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "${player.displayName}${if (isAi) " (AI)" else ""}",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }

        Spacer(modifier = Modifier.height(2.dp))

        // Status text
        val statusText = when {
          isActiveTurn && isRolling -> "Rolling..."
          isActiveTurn && !hasRolled -> "🎲 TAP ROLL"
          isActiveTurn && hasRolled -> "👉 MOVE"
          else -> "WAITING"
        }
        val statusColor = when {
          isActiveTurn && !hasRolled -> Color(0xFFFFD32A)
          isActiveTurn && hasRolled -> Color(0xFF2ED573)
          else -> Color(0xFF88849E)
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = statusText,
            color = statusColor,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 9.sp,
            maxLines = 1
          )
          if (finishedCount > 0) {
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "🏠$finishedCount/4",
              color = Color(0xFFFFD32A),
              fontSize = 8.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }

      Spacer(modifier = Modifier.width(4.dp))

      // Right: Dedicated Dice
      Box(
        modifier = Modifier
          .scale(if (isDiceClickable) diceScale else 1f)
          .testTag("player_dice_${player.name.lowercase()}")
          .clickable(enabled = isDiceClickable) {
            onRollDice()
          },
        contentAlignment = Alignment.Center
      ) {
        LudoDiceView(
          value = diceValue,
          isRolling = isRolling && isActiveTurn,
          diceSize = 38.dp,
          highlightColor = if (isActiveTurn) player.color else Color.Transparent,
          isLocked = !isActiveTurn
        )
      }
    }
  }
}
