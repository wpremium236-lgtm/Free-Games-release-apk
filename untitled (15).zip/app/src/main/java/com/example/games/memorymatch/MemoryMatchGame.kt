package com.example.games.memorymatch

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.core.model.GameDifficulty
import com.example.core.model.GameResultType
import com.example.games.common.GameOverDialog
import com.example.games.common.GamePauseDialog
import com.example.games.common.GameTopBar
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.UUID

data class MemoryCard(
  val id: Int,
  val icon: String,
  var isFlipped: Boolean = false,
  var isMatched: Boolean = false
)

@Composable
fun MemoryMatchGame(
  onBack: () -> Unit,
  onGameFinished: (gameId: String, score: Int, resultType: GameResultType, duration: Long, sessionId: String) -> Unit
) {
  val context = LocalContext.current
  val soundManager = remember { SoundManager.getInstance(context) }
  val scope = rememberCoroutineScope()
  var sessionId by remember { mutableStateOf(UUID.randomUUID().toString()) }
  var startTimeMs by remember { mutableStateOf(System.currentTimeMillis()) }
  var hasSubmittedSession by remember { mutableStateOf(false) }

  var difficulty by remember { mutableStateOf(GameDifficulty.MEDIUM) }
  val (rows, cols) = when (difficulty) {
    GameDifficulty.EASY -> Pair(2, 3) // 6 cards, 3 pairs
    GameDifficulty.MEDIUM -> Pair(3, 4) // 12 cards, 6 pairs
    GameDifficulty.HARD -> Pair(4, 4) // 16 cards, 8 pairs
  }

  val totalCards = rows * cols
  val cardIcons = listOf("🐱", "🐶", "🦊", "🐼", "🦁", "🐯", "🐵", "🦄", "🐸", "🐧")

  val cards = remember(difficulty) {
    mutableStateListOf<MemoryCard>().apply {
      val neededPairs = totalCards / 2
      val selectedIcons = cardIcons.shuffled().take(neededPairs)
      val allIcons = (selectedIcons + selectedIcons).shuffled()
      allIcons.forEachIndexed { i, icon ->
        add(MemoryCard(id = i, icon = icon))
      }
    }
  }

  val flippedIndices = remember { mutableStateListOf<Int>() }
  var movesCount by remember { mutableIntStateOf(0) }
  var timerSeconds by remember { mutableIntStateOf(0) }
  var isPaused by remember { mutableStateOf(false) }
  var isMuted by remember { mutableStateOf(!soundManager.isSoundEnabled) }
  var isGameOver by remember { mutableStateOf(false) }
  var isProcessing by remember { mutableStateOf(false) }

  fun resetGame() {
    cards.clear()
    val neededPairs = totalCards / 2
    val selectedIcons = cardIcons.shuffled().take(neededPairs)
    val allIcons = (selectedIcons + selectedIcons).shuffled()
    allIcons.forEachIndexed { i, icon ->
      cards.add(MemoryCard(id = i, icon = icon))
    }
    flippedIndices.clear()
    movesCount = 0
    timerSeconds = 0
    isGameOver = false
    isProcessing = false
    sessionId = UUID.randomUUID().toString()
    startTimeMs = System.currentTimeMillis()
    hasSubmittedSession = false
  }

  fun onCardClick(index: Int) {
    val card = cards[index]
    if (isProcessing || card.isMatched || card.isFlipped || flippedIndices.size >= 2) return

    card.isFlipped = true
    flippedIndices.add(index)
    soundManager.playCardSound()

    if (flippedIndices.size == 2) {
      movesCount++
      isProcessing = true
      val first = cards[flippedIndices[0]]
      val second = cards[flippedIndices[1]]
      if (first.icon == second.icon) {
        soundManager.playWinSound()
        first.isMatched = true
        second.isMatched = true
        flippedIndices.clear()
        isProcessing = false

        if (cards.all { it.isMatched }) {
          isGameOver = true
          val score = maxOf(100, (1000 - movesCount * 25 - timerSeconds * 5))
          if (!hasSubmittedSession) {
            hasSubmittedSession = true
            val duration = timerSeconds.toLong().coerceAtLeast(1L)
            onGameFinished("memorymatch", score, GameResultType.WIN, duration, sessionId)
          }
        }
      } else {
        scope.launch {
          delay(800)
          first.isFlipped = false
          second.isFlipped = false
          flippedIndices.clear()
          isProcessing = false
        }
      }
    }
  }

  // Timer loop
  LaunchedEffect(isPaused, isGameOver) {
    while (!isPaused && !isGameOver) {
      delay(1000)
      timerSeconds++
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F0C20))
  ) {
    GameTopBar(
      title = "Memory Match",
      score = movesCount,
      timeRemainingSec = timerSeconds,
      isPaused = isPaused,
      isMuted = isMuted,
      onBack = onBack,
      onPauseToggle = { isPaused = !isPaused },
      onRestart = { resetGame() },
      onMuteToggle = {
        isMuted = !isMuted
        soundManager.isSoundEnabled = !isMuted
      }
    )

    // Difficulty selection
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 8.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row {
        listOf(GameDifficulty.EASY, GameDifficulty.MEDIUM, GameDifficulty.HARD).forEach { diff ->
          Text(
            text = "${diff.labelEn} (${when(diff){GameDifficulty.EASY->"2x3"; GameDifficulty.MEDIUM->"3x4"; else->"4x4"}})",
            fontSize = 12.sp,
            color = if (difficulty == diff) Color(0xFF00CEC9) else Color(0xFFA4B0BE),
            fontWeight = if (difficulty == diff) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier
              .padding(end = 12.dp)
              .clickable {
                difficulty = diff
                resetGame()
              }
          )
        }
      }
      Text("Moves: $movesCount", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }

    // Cards Grid
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .padding(16.dp),
      contentAlignment = Alignment.Center
    ) {
      BoxWithConstraints(
        modifier = Modifier
          .aspectRatio(1f)
          .clip(RoundedCornerShape(16.dp))
          .background(Color(0xFF18152E))
          .padding(8.dp)
      ) {
        Column(modifier = Modifier.fillMaxSize()) {
          for (r in 0 until rows) {
            Row(modifier = Modifier.weight(1f)) {
              for (c in 0 until cols) {
                val index = r * cols + c
                if (index < cards.size) {
                  val card = cards[index]
                  val isFaceUp = card.isFlipped || card.isMatched

                  Box(
                    modifier = Modifier
                      .weight(1f)
                      .fillMaxSize()
                      .padding(4.dp)
                      .clip(RoundedCornerShape(10.dp))
                      .background(
                        when {
                          card.isMatched -> Color(0xFF2ED573).copy(alpha = 0.25f)
                          isFaceUp -> Color(0xFF241F42)
                          else -> Color(0xFF6C5CE7)
                        }
                      )
                      .border(
                        1.dp,
                        if (card.isMatched) Color(0xFF2ED573) else Color(0xFF3B336A),
                        RoundedCornerShape(10.dp)
                      )
                      .clickable(enabled = !isFaceUp && !isProcessing) {
                        onCardClick(index)
                      }
                      .testTag("memory_card_$index"),
                    contentAlignment = Alignment.Center
                  ) {
                    if (isFaceUp) {
                      Text(card.icon, fontSize = 28.sp)
                    } else {
                      Text("?", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White.copy(alpha = 0.7f))
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  if (isPaused) {
    GamePauseDialog(
      onResume = { isPaused = false },
      onRestart = { resetGame() },
      onExit = onBack
    )
  }

  if (isGameOver) {
    val score = maxOf(100, (1000 - movesCount * 25 - timerSeconds * 5))
    GameOverDialog(
      gameTitle = "Memory Match",
      resultType = GameResultType.WIN,
      score = score,
      highScore = score,
      durationSec = timerSeconds.toLong(),
      onPlayAgain = { resetGame() },
      onExit = onBack
    )
  }
}
