package com.example.games.snake

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.audio.SoundManager
import com.example.core.model.GameResultType
import com.example.games.common.GameOverDialog
import com.example.games.common.GamePauseDialog
import com.example.games.common.GameTopBar
import kotlinx.coroutines.delay
import java.util.UUID
import kotlin.math.abs
import kotlin.random.Random

enum class SnakeDirection { UP, DOWN, LEFT, RIGHT }
data class SnakePoint(val x: Int, val y: Int)

@Composable
fun SnakeGame(
  onBack: () -> Unit,
  onGameFinished: (gameId: String, score: Int, resultType: GameResultType, duration: Long, sessionId: String) -> Unit
) {
  val context = LocalContext.current
  val soundManager = remember { SoundManager.getInstance(context) }
  var sessionId by remember { mutableStateOf(UUID.randomUUID().toString()) }
  var startTimeMs by remember { mutableStateOf(System.currentTimeMillis()) }
  var hasSubmittedSession by remember { mutableStateOf(false) }

  val gridSize = 20
  var direction by remember { mutableStateOf(SnakeDirection.RIGHT) }
  var nextDirection by remember { mutableStateOf(SnakeDirection.RIGHT) }
  val snake = remember {
    mutableStateListOf(
      SnakePoint(6, 10),
      SnakePoint(5, 10),
      SnakePoint(4, 10)
    )
  }
  var food by remember { mutableStateOf(SnakePoint(14, 10)) }
  var bonusFood by remember { mutableStateOf<SnakePoint?>(null) }
  var score by remember { mutableIntStateOf(0) }
  var highScore by remember { mutableIntStateOf(0) }
  var isPaused by remember { mutableStateOf(false) }
  var isMuted by remember { mutableStateOf(!soundManager.isSoundEnabled) }
  var isGameOver by remember { mutableStateOf(false) }

  fun triggerGameFinished() {
    if (!hasSubmittedSession) {
      hasSubmittedSession = true
      val duration = ((System.currentTimeMillis() - startTimeMs) / 1000L).coerceAtLeast(1L)
      onGameFinished("snake", score, GameResultType.GAME_OVER, duration, sessionId)
    }
  }

  fun spawnFood(): SnakePoint {
    var p: SnakePoint
    do {
      p = SnakePoint(Random.nextInt(gridSize), Random.nextInt(gridSize))
    } while (snake.contains(p))
    return p
  }

  fun resetGame() {
    snake.clear()
    snake.addAll(listOf(SnakePoint(6, 10), SnakePoint(5, 10), SnakePoint(4, 10)))
    direction = SnakeDirection.RIGHT
    nextDirection = SnakeDirection.RIGHT
    food = SnakePoint(14, 10)
    bonusFood = null
    score = 0
    isPaused = false
    isGameOver = false
    sessionId = UUID.randomUUID().toString()
    startTimeMs = System.currentTimeMillis()
    hasSubmittedSession = false
  }

  // Game loop
  LaunchedEffect(isPaused, isGameOver) {
    while (!isPaused && !isGameOver) {
      val speedDelay = (200 - (score * 2)).coerceAtLeast(80).toLong()
      delay(speedDelay)
      direction = nextDirection
      val head = snake.first()
      val newHead = when (direction) {
        SnakeDirection.UP -> SnakePoint(head.x, head.y - 1)
        SnakeDirection.DOWN -> SnakePoint(head.x, head.y + 1)
        SnakeDirection.LEFT -> SnakePoint(head.x - 1, head.y)
        SnakeDirection.RIGHT -> SnakePoint(head.x + 1, head.y)
      }

      // Check wall collision
      if (newHead.x < 0 || newHead.x >= gridSize || newHead.y < 0 || newHead.y >= gridSize) {
        isGameOver = true
        soundManager.playCollisionSound()
        soundManager.playLoseSound()
        triggerGameFinished()
        break
      }

      // Check self collision
      if (snake.contains(newHead)) {
        isGameOver = true
        soundManager.playCollisionSound()
        soundManager.playLoseSound()
        triggerGameFinished()
        break
      }

      snake.add(0, newHead)

      // Check food
      if (newHead == food) {
        score += 10
        soundManager.playScoreBeep()
        food = spawnFood()
        if (score % 50 == 0) {
          bonusFood = spawnFood()
        }
      } else if (newHead == bonusFood) {
        score += 30
        soundManager.playWinSound()
        bonusFood = null
      } else {
        snake.removeAt(snake.size - 1)
      }
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F0C20))
  ) {
    GameTopBar(
      title = "Snake",
      score = score,
      highScore = highScore,
      isPaused = isPaused,
      isMuted = isMuted,
      onBack = onBack,
      onPauseToggle = { isPaused = !isPaused },
      onRestart = { resetGame() },
      onMuteToggle = {
        isMuted = !isMuted
        soundManager.isSoundEnabled = !isMuted
      }
    )

    // Game Board Canvas with Swipe Gesture
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .padding(16.dp),
      contentAlignment = Alignment.Center
    ) {
      BoxWithConstraints(
        modifier = Modifier
          .aspectRatio(1f)
          .clip(RoundedCornerShape(12.dp))
          .background(Color(0xFF141128))
          .pointerInput(Unit) {
            detectDragGestures { change, dragAmount ->
              change.consume()
              val (dx, dy) = dragAmount
              if (abs(dx) > abs(dy)) {
                if (dx > 20 && direction != SnakeDirection.LEFT) nextDirection = SnakeDirection.RIGHT
                else if (dx < -20 && direction != SnakeDirection.RIGHT) nextDirection = SnakeDirection.LEFT
              } else {
                if (dy > 20 && direction != SnakeDirection.UP) nextDirection = SnakeDirection.DOWN
                else if (dy < -20 && direction != SnakeDirection.DOWN) nextDirection = SnakeDirection.UP
              }
            }
          }
      ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
          val cellW = size.width / gridSize
          val cellH = size.height / gridSize

          // Subtle grid pattern
          for (x in 0 until gridSize) {
            for (y in 0 until gridSize) {
              if ((x + y) % 2 == 0) {
                drawRect(
                  Color(0xFF18152E),
                  Offset(x * cellW, y * cellH),
                  Size(cellW, cellH)
                )
              }
            }
          }

          // Draw normal food (Apple)
          drawCircle(
            color = Color(0xFFFF5252),
            radius = cellW * 0.42f,
            center = Offset((food.x + 0.5f) * cellW, (food.y + 0.5f) * cellH)
          )

          // Draw bonus food if active
          bonusFood?.let { bf ->
            drawCircle(
              color = Color(0xFFFFB142),
              radius = cellW * 0.48f,
              center = Offset((bf.x + 0.5f) * cellW, (bf.y + 0.5f) * cellH)
            )
          }

          // Draw snake body & head
          snake.forEachIndexed { index, part ->
            val isHead = index == 0
            val color = if (isHead) Color(0xFF2ED573) else Color(0xFF26AF5F)
            drawRoundRect(
              color = color,
              topLeft = Offset(part.x * cellW + 1f, part.y * cellH + 1f),
              size = Size(cellW - 2f, cellH - 2f),
              cornerRadius = CornerRadius(if (isHead) cellW * 0.35f else cellW * 0.15f)
            )
            // Draw eye on head
            if (isHead) {
              drawCircle(
                color = Color.Black,
                radius = cellW * 0.12f,
                center = Offset((part.x + 0.5f) * cellW, (part.y + 0.5f) * cellH)
              )
            }
          }
        }
      }
    }

    // Directional Controller D-Pad
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 20.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      IconButton(
        onClick = { if (direction != SnakeDirection.DOWN) nextDirection = SnakeDirection.UP },
        colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFF241F42)),
        modifier = Modifier.size(52.dp).testTag("snake_up")
      ) {
        Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Up", tint = Color.White, modifier = Modifier.size(32.dp))
      }
      Row(
        horizontalArrangement = Arrangement.spacedBy(40.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        IconButton(
          onClick = { if (direction != SnakeDirection.RIGHT) nextDirection = SnakeDirection.LEFT },
          colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFF241F42)),
          modifier = Modifier.size(52.dp).testTag("snake_left")
        ) {
          Icon(Icons.Default.KeyboardArrowLeft, contentDescription = "Left", tint = Color.White, modifier = Modifier.size(32.dp))
        }
        IconButton(
          onClick = { if (direction != SnakeDirection.LEFT) nextDirection = SnakeDirection.RIGHT },
          colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFF241F42)),
          modifier = Modifier.size(52.dp).testTag("snake_right")
        ) {
          Icon(Icons.Default.KeyboardArrowRight, contentDescription = "Right", tint = Color.White, modifier = Modifier.size(32.dp))
        }
      }
      IconButton(
        onClick = { if (direction != SnakeDirection.UP) nextDirection = SnakeDirection.DOWN },
        colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFF241F42)),
        modifier = Modifier.size(52.dp).testTag("snake_down")
      ) {
        Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Down", tint = Color.White, modifier = Modifier.size(32.dp))
      }
    }
  }

  if (isPaused) {
    GamePauseDialog(
      onResume = { isPaused = false },
      onRestart = { resetGame() },
      onExit = onBack
    )
  }

  if (isGameOver) {
    GameOverDialog(
      gameTitle = "Snake",
      resultType = GameResultType.GAME_OVER,
      score = score,
      highScore = highScore,
      onPlayAgain = { resetGame() },
      onExit = onBack
    )
  }
}
