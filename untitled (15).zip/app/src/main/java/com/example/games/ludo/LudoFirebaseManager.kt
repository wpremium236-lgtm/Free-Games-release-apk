package com.example.games.ludo

import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.database.Transaction
import com.google.firebase.database.ValueEventListener
import java.util.UUID
import kotlin.random.Random

data class LudoOnlinePlayer(
  val uid: String = "",
  val name: String = "",
  val playerIndex: Int = 0, // 0..5 corresponding to RED, GREEN, YELLOW, BLUE, PURPLE, ORANGE
  val isHost: Boolean = false,
  val isConnected: Boolean = true
)

data class LudoOnlineRoomState(
  val roomCode: String = "",
  val hostUid: String = "",
  val playerCount: Int = 6, // Default 6-player Ludo
  val status: String = "WAITING", // WAITING, PLAYING, FINISHED
  val currentTurnIndex: Int = 0,
  val turnId: Int = 0,
  val diceValue: Int = 6,
  val hasRolled: Boolean = false,
  val consecutiveSixes: Int = 0,
  val winner: String = "",
  val winnerPlayerName: String = "",
  val players: Map<String, LudoOnlinePlayer> = emptyMap(),
  val tokenPositions: List<Int> = emptyList(), // size = playerCount * 4 (24 tokens for 6 players)
  val lastActionId: String = "",
  val stateVersion: Long = 0L,
  val lastUpdated: Long = 0L
)

/**
 * Authoritative, cheat-resistant Firebase Realtime Database manager for 6-Player Ludo.
 * Enforces server-like turn validation, atomic actions, duplicate-roll protection,
 * legal move verification using LudoEngine, and player reconnection.
 */
class LudoFirebaseManager {
  private val database: FirebaseDatabase by lazy {
    try {
      FirebaseDatabase.getInstance("https://free-games-462d1-default-rtdb.firebaseio.com")
    } catch (_: Exception) {
      FirebaseDatabase.getInstance()
    }
  }

  private val roomsRef: DatabaseReference
    get() = database.getReference("games/ludo_v2")

  private var activeListener: ValueEventListener? = null
  private var activeRoomRef: DatabaseReference? = null

  /**
   * Creates an online room with deterministic slot 0 (RED) assigned to the host.
   */
  fun createRoom(
    playerCount: Int = 6,
    onSuccess: (roomCode: String) -> Unit,
    onError: (String) -> Unit
  ) {
    val user = FirebaseAuth.getInstance().currentUser
    if (user == null) {
      onError("Please sign in or continue as Guest to create a room")
      return
    }

    val roomCode = generateRoomCode()
    val initialTokens = MutableList(playerCount * 4) { -1 }

    val hostPlayer = LudoOnlinePlayer(
      uid = user.uid,
      name = user.displayName ?: user.email?.substringBefore("@") ?: "Player 1 (Host)",
      playerIndex = 0,
      isHost = true,
      isConnected = true
    )

    val roomData = mapOf(
      "roomCode" to roomCode,
      "hostUid" to user.uid,
      "playerCount" to playerCount,
      "status" to "WAITING",
      "currentTurnIndex" to 0,
      "turnId" to 1,
      "diceValue" to 6,
      "hasRolled" to false,
      "consecutiveSixes" to 0,
      "winner" to "",
      "winnerPlayerName" to "",
      "players" to mapOf(user.uid to mapOf(
        "uid" to hostPlayer.uid,
        "name" to hostPlayer.name,
        "playerIndex" to 0,
        "isHost" to true,
        "isConnected" to true
      )),
      "tokenPositions" to initialTokens,
      "lastActionId" to UUID.randomUUID().toString(),
      "stateVersion" to 1L,
      "lastUpdated" to System.currentTimeMillis()
    )

    roomsRef.child(roomCode).setValue(roomData)
      .addOnSuccessListener {
        onSuccess(roomCode)
      }
      .addOnFailureListener { e ->
        Log.e("LudoFirebase", "Create room failed", e)
        onError(e.message ?: "Failed to create room in Firebase")
      }
  }

  /**
   * Joins an existing room or reconnects to an already-assigned player slot.
   */
  fun joinRoom(
    roomCode: String,
    onSuccess: () -> Unit,
    onError: (String) -> Unit
  ) {
    val user = FirebaseAuth.getInstance().currentUser
    if (user == null) {
      onError("Please sign in or continue as Guest to join a room")
      return
    }

    val cleanCode = roomCode.uppercase().trim()
    val roomRef = roomsRef.child(cleanCode)

    roomRef.get().addOnSuccessListener { snapshot ->
      if (!snapshot.exists()) {
        onError("Room not found with code: $cleanCode")
        return@addOnSuccessListener
      }

      val maxPlayers = snapshot.child("playerCount").getValue(Int::class.java) ?: 6
      val status = snapshot.child("status").getValue(String::class.java) ?: "WAITING"
      val playersSnap = snapshot.child("players")

      // Reconnect: Player already has a slot in this room
      if (playersSnap.hasChild(user.uid)) {
        roomRef.child("players/${user.uid}/isConnected").setValue(true)
        onSuccess()
        return@addOnSuccessListener
      }

      val currentCount = playersSnap.childrenCount.toInt()
      if (currentCount >= maxPlayers) {
        onError("Room is full ($currentCount/$maxPlayers players)")
        return@addOnSuccessListener
      }

      if (status == "FINISHED") {
        onError("This game has already finished")
        return@addOnSuccessListener
      }

      // Find lowest available playerIndex in 0 until maxPlayers
      val takenIndices = playersSnap.children.mapNotNull { it.child("playerIndex").getValue(Int::class.java) }.toSet()
      var assignedIndex = 0
      for (i in 0 until maxPlayers) {
        if (!takenIndices.contains(i)) {
          assignedIndex = i
          break
        }
      }

      val activePlayers = LudoEngine.getActivePlayers(maxPlayers)
      val assignedPlayer = activePlayers.getOrElse(assignedIndex) { LudoPlayer.RED }
      val colorLabel = assignedPlayer.displayName
      val defaultName = user.displayName ?: user.email?.substringBefore("@") ?: "$colorLabel Player"

      val playerObj = mapOf(
        "uid" to user.uid,
        "name" to defaultName,
        "playerIndex" to assignedIndex,
        "isHost" to false,
        "isConnected" to true
      )

      val updates = mutableMapOf<String, Any>(
        "players/${user.uid}" to playerObj,
        "lastUpdated" to System.currentTimeMillis()
      )

      // Auto start if all player slots are filled
      if (currentCount + 1 >= maxPlayers) {
        updates["status"] = "PLAYING"
      }

      roomRef.updateChildren(updates)
        .addOnSuccessListener { onSuccess() }
        .addOnFailureListener { e -> onError(e.message ?: "Failed to join room") }
    }.addOnFailureListener { e ->
      onError(e.message ?: "Network error connecting to Firebase")
    }
  }

  fun startGame(roomCode: String, onError: (String) -> Unit) {
    val user = FirebaseAuth.getInstance().currentUser ?: return
    val roomRef = roomsRef.child(roomCode)
    roomRef.get().addOnSuccessListener { snapshot ->
      val hostUid = snapshot.child("hostUid").getValue(String::class.java)
      if (hostUid != user.uid) {
        onError("Only the host can start the match")
        return@addOnSuccessListener
      }
      val playersCount = snapshot.child("players").childrenCount.toInt()
      if (playersCount < 2) {
        onError("Waiting for at least 2 players to join")
        return@addOnSuccessListener
      }
      roomRef.child("status").setValue("PLAYING")
    }
  }

  /**
   * Secure, cheat-resistant dice roll performed via Firebase transaction.
   * Enforces:
   * 1. Status == PLAYING
   * 2. Turn matches user's slot
   * 3. hasRolled == false (prevents duplicate rolls)
   * 4. Three-six forfeiture check
   * 5. No legal moves auto-pass check
   */
  fun rollDiceSecure(
    roomCode: String,
    onSuccess: (roll: Int, forfeited: Boolean) -> Unit,
    onError: (String) -> Unit
  ) {
    val user = FirebaseAuth.getInstance().currentUser
    if (user == null) {
      onError("Not signed in")
      return
    }

    val roomRef = roomsRef.child(roomCode)
    roomRef.runTransaction(object : Transaction.Handler {
      var rolledValue = 1
      var forfeited = false
      var hasLegalMoves = true

      override fun doTransaction(mutableData: MutableData): Transaction.Result {
        val status = mutableData.child("status").getValue(String::class.java)
        if (status != "PLAYING") {
          return Transaction.abort()
        }

        val currentTurn = mutableData.child("currentTurnIndex").getValue(Int::class.java) ?: 0
        val pCount = mutableData.child("playerCount").getValue(Int::class.java) ?: 6
        val hasRolled = mutableData.child("hasRolled").getValue(Boolean::class.java) ?: false

        val playerSnap = mutableData.child("players").child(user.uid)
        val myIndex = playerSnap.child("playerIndex").getValue(Int::class.java) ?: -1

        // Security check: Must be current user's turn and not yet rolled
        if (myIndex != currentTurn || hasRolled) {
          return Transaction.abort()
        }

        // Authoritative random roll (1..6)
        rolledValue = Random.nextInt(1, 7)
        val oldSixes = mutableData.child("consecutiveSixes").getValue(Int::class.java) ?: 0
        val newSixes = if (rolledValue == 6) oldSixes + 1 else 0

        // Active player configuration for this match
        val activePlayers = LudoEngine.getActivePlayers(pCount)
        val activePlayer = activePlayers.getOrElse(currentTurn % activePlayers.size) { LudoPlayer.RED }

        // Check Three-Six rule
        if (LudoEngine.isThreeSixesForfeit(newSixes)) {
          forfeited = true
          mutableData.child("hasRolled").value = false
          mutableData.child("consecutiveSixes").value = 0
          mutableData.child("currentTurnIndex").value = (currentTurn + 1) % activePlayers.size
        } else {
          // Verify if any legal moves exist for this player's 4 tokens
          val tokensSnap = mutableData.child("tokenPositions")
          val tokenPositions = mutableListOf<Int>()
          tokensSnap.children.forEach { child ->
            tokenPositions.add(child.getValue(Int::class.java) ?: -1)
          }

          val playerTokenOffset = currentTurn * 4
          val playerTokens = (0..3).map { id ->
            val pos = tokenPositions.getOrElse(playerTokenOffset + id) { -1 }
            LudoToken(id = id, player = activePlayer, position = pos)
          }

          hasLegalMoves = playerTokens.any { LudoEngine.canMoveToken(it, rolledValue, pCount) }

          if (!hasLegalMoves) {
            // Auto advance turn if no moves possible
            mutableData.child("hasRolled").value = false
            mutableData.child("consecutiveSixes").value = 0
            mutableData.child("currentTurnIndex").value = (currentTurn + 1) % activePlayers.size
          } else {
            mutableData.child("hasRolled").value = true
            mutableData.child("consecutiveSixes").value = newSixes
          }
        }

        mutableData.child("diceValue").value = rolledValue
        mutableData.child("lastActionId").value = UUID.randomUUID().toString()
        val currentVer = mutableData.child("stateVersion").getValue(Long::class.java) ?: 0L
        mutableData.child("stateVersion").value = currentVer + 1L
        mutableData.child("lastUpdated").value = System.currentTimeMillis()

        return Transaction.success(mutableData)
      }

      override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
        if (committed && error == null) {
          onSuccess(rolledValue, forfeited)
        } else {
          onError(error?.message ?: "Dice roll transaction was rejected or out of turn")
        }
      }
    })
  }

  /**
   * Secure, cheat-resistant token move performed via Firebase transaction.
   * Validates move legality using LudoEngine, calculates captures, updates turn,
   * and declares winner if all 4 tokens finished.
   */
  fun moveTokenSecure(
    roomCode: String,
    tokenId: Int,
    onSuccess: () -> Unit,
    onError: (String) -> Unit
  ) {
    val user = FirebaseAuth.getInstance().currentUser
    if (user == null) {
      onError("Not signed in")
      return
    }

    val roomRef = roomsRef.child(roomCode)
    roomRef.runTransaction(object : Transaction.Handler {
      override fun doTransaction(mutableData: MutableData): Transaction.Result {
        val status = mutableData.child("status").getValue(String::class.java)
        if (status != "PLAYING") {
          return Transaction.abort()
        }

        val currentTurn = mutableData.child("currentTurnIndex").getValue(Int::class.java) ?: 0
        val pCount = mutableData.child("playerCount").getValue(Int::class.java) ?: 6
        val hasRolled = mutableData.child("hasRolled").getValue(Boolean::class.java) ?: false
        val diceValue = mutableData.child("diceValue").getValue(Int::class.java) ?: 1

        val playerSnap = mutableData.child("players").child(user.uid)
        val myIndex = playerSnap.child("playerIndex").getValue(Int::class.java) ?: -1

        // Security check: Must be current user's turn and dice must be rolled
        if (myIndex != currentTurn || !hasRolled || tokenId !in 0..3) {
          return Transaction.abort()
        }

        val activePlayers = LudoEngine.getActivePlayers(pCount)
        val activePlayer = activePlayers.getOrElse(currentTurn % activePlayers.size) { LudoPlayer.RED }
        val tokensSnap = mutableData.child("tokenPositions")
        val currentPositions = mutableListOf<Int>()
        tokensSnap.children.forEach { child ->
          currentPositions.add(child.getValue(Int::class.java) ?: -1)
        }

        // Ensure list has enough items
        while (currentPositions.size < pCount * 4) {
          currentPositions.add(-1)
        }

        val movingTokenIndex = currentTurn * 4 + tokenId
        val currentTokenPos = currentPositions[movingTokenIndex]
        val movingToken = LudoToken(id = tokenId, player = activePlayer, position = currentTokenPos)

        // Engine verification: Is this move legal?
        if (!LudoEngine.canMoveToken(movingToken, diceValue, pCount)) {
          return Transaction.abort()
        }

        val newPos = LudoEngine.calculateNextPosition(movingToken, diceValue, pCount)
        currentPositions[movingTokenIndex] = newPos

        // Check opponent captures
        var capturedOpponent = false
        val trackLen = LudoEngine.getTrackLength(pCount)
        if (newPos in 0 until trackLen && !LudoEngine.isSafeSpot(newPos, pCount)) {
          for (i in 0 until (pCount * 4)) {
            val ownerPlayerIdx = i / 4
            if (ownerPlayerIdx != currentTurn && currentPositions[i] == newPos) {
              currentPositions[i] = -1 // Reset captured opponent to base
              capturedOpponent = true
            }
          }
        }

        // Check if player won (all 4 tokens finished in central home)
        val finishedPos = LudoEngine.getFinishedPos(pCount)
        val myTokensFinished = (0..3).all { id ->
          currentPositions[currentTurn * 4 + id] >= finishedPos
        }

        if (myTokensFinished) {
          mutableData.child("winner").value = user.uid
          val playerName = playerSnap.child("name").getValue(String::class.java) ?: activePlayer.displayName
          mutableData.child("winnerPlayerName").value = playerName
          mutableData.child("status").value = "FINISHED"
        }

        // Determine if player gets bonus turn
        val reachedHome = newPos >= finishedPos
        val getsBonus = LudoEngine.shouldGetBonusRoll(diceValue, capturedOpponent, reachedHome)

        if (!getsBonus && !myTokensFinished) {
          mutableData.child("currentTurnIndex").value = (currentTurn + 1) % activePlayers.size
          mutableData.child("consecutiveSixes").value = 0
        }

        mutableData.child("hasRolled").value = false
        mutableData.child("tokenPositions").value = currentPositions
        mutableData.child("lastActionId").value = UUID.randomUUID().toString()
        val currentVer = mutableData.child("stateVersion").getValue(Long::class.java) ?: 0L
        mutableData.child("stateVersion").value = currentVer + 1L
        mutableData.child("lastUpdated").value = System.currentTimeMillis()

        return Transaction.success(mutableData)
      }

      override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
        if (committed && error == null) {
          onSuccess()
        } else {
          onError(error?.message ?: "Token move was rejected or invalid")
        }
      }
    })
  }

  fun listenToRoom(
    roomCode: String,
    onStateUpdated: (LudoOnlineRoomState) -> Unit,
    onError: (String) -> Unit
  ) {
    detachListener()
    val roomRef = roomsRef.child(roomCode.uppercase().trim())
    activeRoomRef = roomRef

    val listener = object : ValueEventListener {
      override fun onDataChange(snapshot: DataSnapshot) {
        if (!snapshot.exists()) {
          onError("Room not found or has been closed")
          return
        }

        try {
          val code = snapshot.child("roomCode").getValue(String::class.java) ?: roomCode
          val host = snapshot.child("hostUid").getValue(String::class.java) ?: ""
          val pCount = snapshot.child("playerCount").getValue(Int::class.java) ?: 6
          val stat = snapshot.child("status").getValue(String::class.java) ?: "WAITING"
          val turn = snapshot.child("currentTurnIndex").getValue(Int::class.java) ?: 0
          val turnId = snapshot.child("turnId").getValue(Int::class.java) ?: 1
          val dice = snapshot.child("diceValue").getValue(Int::class.java) ?: 6
          val rolled = snapshot.child("hasRolled").getValue(Boolean::class.java) ?: false
          val sixes = snapshot.child("consecutiveSixes").getValue(Int::class.java) ?: 0
          val win = snapshot.child("winner").getValue(String::class.java) ?: ""
          val winName = snapshot.child("winnerPlayerName").getValue(String::class.java) ?: ""
          val actionId = snapshot.child("lastActionId").getValue(String::class.java) ?: ""
          val version = snapshot.child("stateVersion").getValue(Long::class.java) ?: 0L
          val updated = snapshot.child("lastUpdated").getValue(Long::class.java) ?: 0L

          val playersMap = mutableMapOf<String, LudoOnlinePlayer>()
          snapshot.child("players").children.forEach { child ->
            val uid = child.child("uid").getValue(String::class.java) ?: child.key ?: ""
            val name = child.child("name").getValue(String::class.java) ?: "Player"
            val idx = child.child("playerIndex").getValue(Int::class.java) ?: 0
            val isH = child.child("isHost").getValue(Boolean::class.java) ?: false
            val isConn = child.child("isConnected").getValue(Boolean::class.java) ?: true
            playersMap[uid] = LudoOnlinePlayer(uid, name, idx, isH, isConn)
          }

          val tokensList = mutableListOf<Int>()
          snapshot.child("tokenPositions").children.forEach { t ->
            val pos = t.getValue(Int::class.java) ?: -1
            tokensList.add(pos)
          }

          val state = LudoOnlineRoomState(
            roomCode = code,
            hostUid = host,
            playerCount = pCount,
            status = stat,
            currentTurnIndex = turn,
            turnId = turnId,
            diceValue = dice,
            hasRolled = rolled,
            consecutiveSixes = sixes,
            winner = win,
            winnerPlayerName = winName,
            players = playersMap,
            tokenPositions = if (tokensList.isEmpty()) List(pCount * 4) { -1 } else tokensList,
            lastActionId = actionId,
            stateVersion = version,
            lastUpdated = updated
          )
          onStateUpdated(state)
        } catch (e: Exception) {
          Log.e("LudoFirebase", "Error parsing room state", e)
        }
      }

      override fun onCancelled(error: DatabaseError) {
        Log.e("LudoFirebase", "Room listener cancelled: ${error.message}")
        onError(error.message)
      }
    }
    activeListener = listener
    roomRef.addValueEventListener(listener)
  }

  fun passTurnOnline(roomCode: String) {
    val user = FirebaseAuth.getInstance().currentUser ?: return
    val roomRef = roomsRef.child(roomCode.uppercase().trim())
    roomRef.runTransaction(object : Transaction.Handler {
      override fun doTransaction(mutableData: MutableData): Transaction.Result {
        val status = mutableData.child("status").getValue(String::class.java)
        if (status != "PLAYING") return Transaction.abort()
        val currentTurn = mutableData.child("currentTurnIndex").getValue(Int::class.java) ?: 0
        val pCount = mutableData.child("playerCount").getValue(Int::class.java) ?: 6
        val playerSnap = mutableData.child("players").child(user.uid)
        val myIndex = playerSnap.child("playerIndex").getValue(Int::class.java) ?: -1
        if (myIndex != currentTurn) return Transaction.abort()

        val activePlayers = LudoEngine.getActivePlayers(pCount)
        mutableData.child("hasRolled").value = false
        mutableData.child("consecutiveSixes").value = 0
        mutableData.child("currentTurnIndex").value = (currentTurn + 1) % activePlayers.size
        val currentVer = mutableData.child("stateVersion").getValue(Long::class.java) ?: 0L
        mutableData.child("stateVersion").value = currentVer + 1L
        mutableData.child("lastUpdated").value = System.currentTimeMillis()
        return Transaction.success(mutableData)
      }
      override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {}
    })
  }

  fun leaveRoom(roomCode: String) {
    val user = FirebaseAuth.getInstance().currentUser
    detachListener()
    if (user != null && roomCode.isNotBlank()) {
      val roomRef = roomsRef.child(roomCode.uppercase().trim())
      // Mark as disconnected rather than deleting player slot to allow reconnecting
      roomRef.child("players/${user.uid}/isConnected").setValue(false)
    }
  }

  fun detachListener() {
    activeListener?.let { listener ->
      activeRoomRef?.removeEventListener(listener)
    }
    activeListener = null
    activeRoomRef = null
  }

  private fun generateRoomCode(): String {
    val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    return (1..6)
      .map { chars[Random.nextInt(chars.length)] }
      .joinToString("")
  }
}
