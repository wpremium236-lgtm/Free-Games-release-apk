package com.example.games.blockpuzzle

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.audio.SoundManager
import com.example.games.common.GameOverDialog
import com.example.games.common.GamePauseDialog
import com.example.games.common.GameTopBar

data class PuzzleShape(
  val id: Int,
  val matrix: List<List<Int>>,
  val color: Color
)

@Composable
fun BlockPuzzleGame(
  onBack: () -> Unit,
  onGameFinished: (score: Int) -> Unit
) {
  val context = LocalContext.current
  val soundManager = remember { SoundManager.getInstance(context) }
  var score by remember { mutableIntStateOf(0) }
  var highScore by remember { mutableIntStateOf(0) }
  var isPaused by remember { mutableStateOf(false) }
  var isMuted by remember { mutableStateOf(!soundManager.isSoundEnabled) }
  var isGameOver by remember { mutableStateOf(false) }

  // 8x8 Board: null = empty, Color = filled
  val board = remember {
    mutableStateListOf<MutableList<Color?>>().apply {
      for (r in 0..7) {
        add(MutableList(8) { null })
      }
    }
  }

  val shapeTemplates = listOf(
    Pair(listOf(listOf(1)), Color(0xFFFF5252)),
    Pair(listOf(listOf(1, 1)), Color(0xFF00CEC9)),
    Pair(listOf(listOf(1), listOf(1)), Color(0xFF00CEC9)),
    Pair(listOf(listOf(1, 1, 1)), Color(0xFFFFB142)),
    Pair(listOf(listOf(1), listOf(1), listOf(1)), Color(0xFFFFB142)),
    Pair(listOf(listOf(1, 1), listOf(1, 1)), Color(0xFF2ED573)),
    Pair(listOf(listOf(1, 0), listOf(1, 1)), Color(0xFF9C88FF)),
    Pair(listOf(listOf(1, 1, 1), listOf(0, 1, 0)), Color(0xFFE84118))
  )

  val currentShapes = remember { mutableStateListOf<PuzzleShape>() }
  var selectedShapeIndex by remember { mutableStateOf<Int?>(null) }

  fun spawnShapes() {
    currentShapes.clear()
    for (i in 0..2) {
      val (matrix, col) = shapeTemplates.random()
      currentShapes.add(PuzzleShape(i, matrix, col))
    }
  }

  fun resetGame() {
    for (r in 0..7) {
      for (c in 0..7) {
        board[r][c] = null
      }
    }
    score = 0
    selectedShapeIndex = null
    spawnShapes()
    isGameOver = false
  }

  remember {
    spawnShapes()
    true
  }

  fun canPlaceShape(shape: PuzzleShape, atR: Int, atC: Int): Boolean {
    val h = shape.matrix.size
    val w = shape.matrix[0].size
    if (atR + h > 8 || atC + w > 8) return false
    for (r in 0 until h) {
      for (c in 0 until w) {
        if (shape.matrix[r][c] == 1) {
          if (board[atR + r][atC + c] != null) return false
        }
      }
    }
    return true
  }

  fun canPlaceShapeAnywhere(shape: PuzzleShape): Boolean {
    for (r in 0..7) {
      for (c in 0..7) {
        if (canPlaceShape(shape, r, c)) return true
      }
    }
    return false
  }

  fun clearFullLines() {
    val fullRows = mutableListOf<Int>()
    val fullCols = mutableListOf<Int>()
    for (r in 0..7) {
      if ((0..7).all { board[r][it] != null }) fullRows.add(r)
    }
    for (c in 0..7) {
      if ((0..7).all { board[it][c] != null }) fullCols.add(c)
    }
    val linesCleared = fullRows.size + fullCols.size
    if (linesCleared > 0) {
      fullRows.forEach { r ->
        for (c in 0..7) board[r][c] = null
      }
      fullCols.forEach { c ->
        for (r in 0..7) board[r][c] = null
      }
      score += linesCleared * 100 * linesCleared
      soundManager.playWinSound()
    }
  }

  fun tryPlaceShape(atR: Int, atC: Int) {
    val selIdx = selectedShapeIndex ?: return
    if (selIdx !in currentShapes.indices) return
    val shape = currentShapes[selIdx]

    if (canPlaceShape(shape, atR, atC)) {
      val h = shape.matrix.size
      val w = shape.matrix[0].size
      for (r in 0 until h) {
        for (c in 0 until w) {
          if (shape.matrix[r][c] == 1) {
            board[atR + r][atC + c] = shape.color
          }
        }
      }
      score += h * w * 10
      soundManager.playScoreBeep()
      currentShapes.removeAt(selIdx)
      selectedShapeIndex = null
      clearFullLines()

      if (currentShapes.isEmpty()) {
        spawnShapes()
      }

      // Check game over
      if (currentShapes.all { !canPlaceShapeAnywhere(it) }) {
        isGameOver = true
        soundManager.playLoseSound()
        onGameFinished(score)
      }
    } else {
      soundManager.playButtonClick()
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F0C20))
  ) {
    GameTopBar(
      title = "Block Puzzle",
      score = score,
      highScore = highScore,
      isPaused = isPaused,
      isMuted = isMuted,
      onBack = onBack,
      onPauseToggle = { isPaused = !isPaused },
      onRestart = { resetGame() },
      onMuteToggle = {
        isMuted = !isMuted
        soundManager.isSoundEnabled = !isMuted
      }
    )

    // 8x8 Grid
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .padding(16.dp),
      contentAlignment = Alignment.Center
    ) {
      BoxWithConstraints(
        modifier = Modifier
          .aspectRatio(1f)
          .clip(RoundedCornerShape(12.dp))
          .background(Color(0xFF18152E))
          .border(2.dp, Color(0xFF3B336A), RoundedCornerShape(12.dp))
          .padding(4.dp)
      ) {
        Column(modifier = Modifier.fillMaxSize()) {
          for (r in 0..7) {
            Row(modifier = Modifier.weight(1f)) {
              for (c in 0..7) {
                val cellColor = board[r][c]
                Box(
                  modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .padding(2.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(cellColor ?: Color(0xFF241F42))
                    .border(0.5.dp, Color(0xFF332B5E), RoundedCornerShape(4.dp))
                    .clickable { tryPlaceShape(r, c) }
                    .testTag("block_cell_${r}_${c}")
                )
              }
            }
          }
        }
      }
    }

    // Available Shapes Selector at bottom
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      horizontalArrangement = Arrangement.SpaceEvenly,
      verticalAlignment = Alignment.CenterVertically
    ) {
      currentShapes.forEachIndexed { idx, shape ->
        val isSelected = selectedShapeIndex == idx
        Box(
          modifier = Modifier
            .size(80.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) Color(0xFF6C5CE7).copy(alpha = 0.35f) else Color(0xFF18152E))
            .border(
              width = if (isSelected) 2.dp else 1.dp,
              color = if (isSelected) Color(0xFF6C5CE7) else Color(0xFF3B336A),
              shape = RoundedCornerShape(10.dp)
            )
            .clickable {
              selectedShapeIndex = if (isSelected) null else idx
              soundManager.playButtonClick()
            }
            .padding(6.dp),
          contentAlignment = Alignment.Center
        ) {
          Column {
            shape.matrix.forEach { row ->
              Row {
                row.forEach { cell ->
                  Box(
                    modifier = Modifier
                      .size(14.dp)
                      .padding(1.dp)
                      .clip(RoundedCornerShape(2.dp))
                      .background(if (cell == 1) shape.color else Color.Transparent)
                  )
                }
              }
            }
          }
        }
      }
    }
  }

  if (isPaused) {
    GamePauseDialog(
      onResume = { isPaused = false },
      onRestart = { resetGame() },
      onExit = onBack
    )
  }

  if (isGameOver) {
    GameOverDialog(
      isWin = false,
      score = score,
      highScore = highScore,
      onPlayAgain = { resetGame() },
      onExit = onBack
    )
  }
}
