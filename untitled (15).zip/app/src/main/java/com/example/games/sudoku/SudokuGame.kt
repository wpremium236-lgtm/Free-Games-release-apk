package com.example.games.sudoku

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.ads.AdManager
import com.example.core.audio.SoundManager
import com.example.core.model.GameDifficulty
import com.example.core.model.GameResultType
import com.example.games.common.GameOverDialog
import com.example.games.common.GamePauseDialog
import com.example.games.common.GameTopBar
import kotlinx.coroutines.delay
import java.util.UUID

@Composable
fun SudokuGame(
  onBack: () -> Unit,
  onGameFinished: (gameId: String, score: Int, resultType: GameResultType, duration: Long, sessionId: String) -> Unit
) {
  val context = LocalContext.current
  val soundManager = remember { SoundManager.getInstance(context) }
  val adManager = remember { AdManager.getInstance(context) }
  var sessionId by remember { mutableStateOf(UUID.randomUUID().toString()) }
  var startTimeMs by remember { mutableStateOf(System.currentTimeMillis()) }
  var hasSubmittedSession by remember { mutableStateOf(false) }

  var difficulty by remember { mutableStateOf(GameDifficulty.EASY) }
  var timerSeconds by remember { mutableIntStateOf(0) }
  var isPaused by remember { mutableStateOf(false) }
  var isMuted by remember { mutableStateOf(!soundManager.isSoundEnabled) }
  var isGameOver by remember { mutableStateOf(false) }
  var selectedCell by remember { mutableStateOf<Pair<Int, Int>?>(null) }
  var hintsRemaining by remember { mutableIntStateOf(3) }

  LaunchedEffect(Unit) {
    if (adManager.isRewardedEnabled()) {
      adManager.loadRewarded()
    }
  }

  // Sample valid Sudoku solution
  val solution = remember {
    listOf(
      listOf(5, 3, 4, 6, 7, 8, 9, 1, 2),
      listOf(6, 7, 2, 1, 9, 5, 3, 4, 8),
      listOf(1, 9, 8, 3, 4, 2, 5, 6, 7),
      listOf(8, 5, 9, 7, 6, 1, 4, 2, 3),
      listOf(4, 2, 6, 8, 5, 3, 7, 9, 1),
      listOf(7, 1, 3, 9, 2, 4, 8, 5, 6),
      listOf(9, 6, 1, 5, 3, 7, 2, 8, 4),
      listOf(2, 8, 7, 4, 1, 9, 6, 3, 5),
      listOf(3, 4, 5, 2, 8, 6, 1, 7, 9)
    )
  }

  // Initial fixed masks based on difficulty
  val initialBoard = remember(difficulty) {
    val removeCount = when (difficulty) {
      GameDifficulty.EASY -> 30
      GameDifficulty.MEDIUM -> 42
      GameDifficulty.HARD -> 54
    }
    val b = Array(9) { r -> IntArray(9) { c -> solution[r][c] } }
    var removed = 0
    while (removed < removeCount) {
      val r = (0..8).random()
      val c = (0..8).random()
      if (b[r][c] != 0) {
        b[r][c] = 0
        removed++
      }
    }
    b
  }

  val userBoard = remember {
    mutableStateListOf<MutableList<Int>>().apply {
      for (r in 0..8) {
        add(MutableList(9) { c -> initialBoard[r][c] })
      }
    }
  }

  fun resetPuzzle() {
    userBoard.clear()
    for (r in 0..8) {
      userBoard.add(MutableList(9) { c -> initialBoard[r][c] })
    }
    timerSeconds = 0
    isGameOver = false
    selectedCell = null
    hintsRemaining = 3
    sessionId = UUID.randomUUID().toString()
    startTimeMs = System.currentTimeMillis()
    hasSubmittedSession = false
  }

  fun checkCompletion() {
    for (r in 0..8) {
      for (c in 0..8) {
        if (userBoard[r][c] != solution[r][c]) return
      }
    }
    isGameOver = true
    soundManager.playWinSound()
    val calculatedScore = maxOf(100, 1000 - timerSeconds * 2)
    if (!hasSubmittedSession) {
      hasSubmittedSession = true
      val duration = timerSeconds.toLong().coerceAtLeast(1L)
      onGameFinished("sudoku", calculatedScore, GameResultType.WIN, duration, sessionId)
    }
  }

  fun fillCell(digit: Int) {
    selectedCell?.let { (r, c) ->
      if (initialBoard[r][c] == 0) {
        userBoard[r][c] = digit
        soundManager.playButtonClick()
        checkCompletion()
      }
    }
  }

  fun useHint() {
    if (hintsRemaining <= 0) {
      val activity = context as? Activity
      if (adManager.isRewardedEnabled()) {
        adManager.showRewarded(
          activity = activity,
          onRewardEarned = {
            hintsRemaining += 2
          },
          onDismiss = {}
        )
      }
      return
    }
    selectedCell?.let { (r, c) ->
      if (initialBoard[r][c] == 0 && userBoard[r][c] != solution[r][c]) {
        userBoard[r][c] = solution[r][c]
        hintsRemaining--
        soundManager.playScoreBeep()
        checkCompletion()
      }
    }
  }

  // Timer loop
  LaunchedEffect(isPaused, isGameOver) {
    while (!isPaused && !isGameOver) {
      delay(1000)
      timerSeconds++
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F0C20))
  ) {
    GameTopBar(
      title = "Sudoku",
      timeRemainingSec = timerSeconds,
      isPaused = isPaused,
      isMuted = isMuted,
      onBack = onBack,
      onPauseToggle = { isPaused = !isPaused },
      onRestart = { resetPuzzle() },
      onMuteToggle = {
        isMuted = !isMuted
        soundManager.isSoundEnabled = !isMuted
      }
    )

    // Difficulty and Hints bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row {
        listOf(GameDifficulty.EASY, GameDifficulty.MEDIUM, GameDifficulty.HARD).forEach { diff ->
          Text(
            text = diff.labelEn,
            fontSize = 12.sp,
            color = if (difficulty == diff) Color(0xFF00CEC9) else Color(0xFFA4B0BE),
            fontWeight = if (difficulty == diff) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier
              .padding(end = 12.dp)
              .clickable {
                difficulty = diff
                resetPuzzle()
              }
          )
        }
      }

      Button(
        onClick = { useHint() },
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF241F42)),
        modifier = Modifier.height(34.dp).testTag("sudoku_hint_btn")
      ) {
        Icon(Icons.Default.Lightbulb, contentDescription = "Hint", tint = Color(0xFFFFB142), modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("Hint ($hintsRemaining)", fontSize = 11.sp, color = Color.White)
      }
    }

    // 9x9 Sudoku Grid
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .padding(12.dp),
      contentAlignment = Alignment.Center
    ) {
      BoxWithConstraints(
        modifier = Modifier
          .aspectRatio(1f)
          .clip(RoundedCornerShape(12.dp))
          .background(Color(0xFF18152E))
          .border(2.dp, Color(0xFF6C5CE7), RoundedCornerShape(12.dp))
          .padding(4.dp)
      ) {
        Column(modifier = Modifier.fillMaxSize()) {
          for (r in 0..8) {
            Row(modifier = Modifier.weight(1f)) {
              for (c in 0..8) {
                val value = userBoard[r][c]
                val isFixed = initialBoard[r][c] != 0
                val isSelected = selectedCell == Pair(r, c)
                val isWrong = value != 0 && !isFixed && value != solution[r][c]

                val borderBottom = if (r % 3 == 2 && r != 8) 2.dp else 0.5.dp
                val borderRight = if (c % 3 == 2 && c != 8) 2.dp else 0.5.dp

                Box(
                  modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .border(borderRight, if (c % 3 == 2 && c != 8) Color(0xFF6C5CE7) else Color(0xFF2E2954))
                    .border(borderBottom, if (r % 3 == 2 && r != 8) Color(0xFF6C5CE7) else Color(0xFF2E2954))
                    .background(
                      when {
                        isSelected -> Color(0xFF6C5CE7).copy(alpha = 0.45f)
                        isWrong -> Color(0xFFFF5252).copy(alpha = 0.35f)
                        isFixed -> Color(0xFF241F42)
                        else -> Color.Transparent
                      }
                    )
                    .clickable { selectedCell = Pair(r, c) }
                    .testTag("sudoku_cell_${r}_${c}"),
                  contentAlignment = Alignment.Center
                ) {
                  if (value != 0) {
                    Text(
                      text = "$value",
                      fontSize = 18.sp,
                      fontWeight = if (isFixed) FontWeight.Bold else FontWeight.SemiBold,
                      color = when {
                        isWrong -> Color(0xFFFF5252)
                        isFixed -> Color.White
                        else -> Color(0xFF00CEC9)
                      }
                    )
                  }
                }
              }
            }
          }
        }
      }
    }

    // Number Pad (1..9 and Erase)
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 12.dp),
      horizontalArrangement = Arrangement.SpaceEvenly,
      verticalAlignment = Alignment.CenterVertically
    ) {
      (1..9).forEach { digit ->
        Box(
          modifier = Modifier
            .size(34.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF241F42))
            .clickable { fillCell(digit) }
            .testTag("sudoku_pad_$digit"),
          contentAlignment = Alignment.Center
        ) {
          Text("$digit", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
      }
      Box(
        modifier = Modifier
          .size(34.dp)
          .clip(RoundedCornerShape(8.dp))
          .background(Color(0xFFE84118))
          .clickable { fillCell(0) }
          .testTag("sudoku_erase"),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Default.Clear, contentDescription = "Erase", tint = Color.White, modifier = Modifier.size(16.dp))
      }
    }
  }

  if (isPaused) {
    GamePauseDialog(
      onResume = { isPaused = false },
      onRestart = { resetPuzzle() },
      onExit = onBack
    )
  }

  if (isGameOver) {
    val score = maxOf(100, 1000 - timerSeconds * 2)
    GameOverDialog(
      gameTitle = "Sudoku",
      resultType = GameResultType.WIN,
      score = score,
      highScore = score,
      durationSec = timerSeconds.toLong(),
      onPlayAgain = { resetPuzzle() },
      onExit = onBack
    )
  }
}
