package com.example.games.archery

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.games.common.GameOverDialog
import com.example.games.common.GamePauseDialog
import com.example.games.common.GameTopBar
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.sqrt
import kotlin.random.Random

data class ArrowShot(
  var x: Float,
  var y: Float,
  var vx: Float,
  var vy: Float,
  var isStuck: Boolean = false,
  var points: Int = 0
)

@Composable
fun ArcheryGame(
  onBack: () -> Unit,
  onGameFinished: (score: Int) -> Unit
) {
  val context = LocalContext.current
  val soundManager = remember { SoundManager.getInstance(context) }
  var arrowsRemaining by remember { mutableIntStateOf(5) }
  var score by remember { mutableIntStateOf(0) }
  var highScore by remember { mutableIntStateOf(0) }
  var isPaused by remember { mutableStateOf(false) }
  var isMuted by remember { mutableStateOf(!soundManager.isSoundEnabled) }
  var isGameOver by remember { mutableStateOf(false) }

  // Target movement (vertical bobbing)
  var targetY by remember { mutableFloatStateOf(0.5f) }
  var targetDirection by remember { mutableFloatStateOf(1f) }
  var windX by remember { mutableFloatStateOf(0f) }

  // Pullback bow controls
  var bowPullOffset by remember { mutableStateOf<Offset?>(null) }
  val activeArrows = remember { mutableStateListOf<ArrowShot>() }

  fun resetGame() {
    arrowsRemaining = 5
    score = 0
    activeArrows.clear()
    bowPullOffset = null
    windX = (Random.nextFloat() - 0.5f) * 0.008f
    isGameOver = false
  }

  // Target movement & physics loop
  LaunchedEffect(isPaused, isGameOver) {
    while (!isPaused && !isGameOver) {
      delay(20)

      targetY += 0.004f * targetDirection
      if (targetY > 0.75f) targetDirection = -1f
      else if (targetY < 0.25f) targetDirection = 1f

      // Update active arrows
      val iterator = activeArrows.iterator()
      while (iterator.hasNext()) {
        val arrow = iterator.next()
        if (!arrow.isStuck) {
          arrow.x += arrow.vx
          arrow.y += arrow.vy
          arrow.vy += 0.0006f // Gravity
          arrow.x += windX // Wind push

          // Check hit on target (target is at x = 0.82f)
          if (arrow.x >= 0.80f) {
            arrow.isStuck = true
            val dist = abs(arrow.y - targetY)
            val ringPoints = when {
              dist < 0.03f -> 100 // Bullseye
              dist < 0.06f -> 80
              dist < 0.10f -> 60
              dist < 0.14f -> 40
              dist < 0.18f -> 20
              else -> 0
            }
            arrow.points = ringPoints
            score += ringPoints
            if (ringPoints >= 80) {
              soundManager.playWinSound()
            } else if (ringPoints > 0) {
              soundManager.playScoreBeep()
            } else {
              soundManager.playCollisionSound()
            }

            windX = (Random.nextFloat() - 0.5f) * 0.008f
            if (arrowsRemaining <= 0) {
              isGameOver = true
              onGameFinished(score)
            }
          }
        }
      }
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F0C20))
  ) {
    GameTopBar(
      title = "Archery Master",
      score = score,
      lives = arrowsRemaining,
      isPaused = isPaused,
      isMuted = isMuted,
      onBack = onBack,
      onPauseToggle = { isPaused = !isPaused },
      onRestart = { resetGame() },
      onMuteToggle = {
        isMuted = !isMuted
        soundManager.isSoundEnabled = !isMuted
      }
    )

    // Wind Indicator
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "WIND: ${if (windX > 0) ">>> RIGHT" else if (windX < 0) "<<< LEFT" else "CALM"} ${(abs(windX) * 1000).toInt()}",
        color = Color(0xFF00CEC9),
        fontWeight = FontWeight.Bold,
        fontSize = 12.sp
      )
      Text("Pull bow & release to shoot", fontSize = 12.sp, color = Color(0xFFA4B0BE))
    }

    // Archery Field Canvas
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .padding(12.dp),
      contentAlignment = Alignment.Center
    ) {
      BoxWithConstraints(
        modifier = Modifier
          .fillMaxSize()
          .clip(RoundedCornerShape(16.dp))
          .background(Color(0xFF141926))
          .pointerInput(arrowsRemaining, isGameOver) {
            if (arrowsRemaining > 0 && !isGameOver) {
              detectDragGestures(
                onDragStart = { offset ->
                  bowPullOffset = offset
                },
                onDrag = { change, dragAmount ->
                  change.consume()
                  bowPullOffset = bowPullOffset?.let { Offset(it.x + dragAmount.x, it.y + dragAmount.y) }
                },
                onDragEnd = {
                  bowPullOffset?.let { pull ->
                    val bowPos = Offset(size.width * 0.15f, size.height * 0.5f)
                    val dx = (bowPos.x - pull.x) / 300f
                    val dy = (bowPos.y - pull.y) / 300f
                    val power = sqrt(dx * dx + dy * dy).coerceIn(0.015f, 0.045f)
                    soundManager.playMoveSound()
                    activeArrows.add(
                      ArrowShot(
                        x = 0.15f,
                        y = 0.5f,
                        vx = power * 1.2f,
                        vy = dy * 0.6f
                      )
                    )
                    arrowsRemaining--
                  }
                  bowPullOffset = null
                },
                onDragCancel = {
                  bowPullOffset = null
                }
              )
            }
          }
          .testTag("archery_canvas")
      ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
          val w = size.width
          val h = size.height

          // Draw Target on the right (x = 0.82f)
          val tx = w * 0.82f
          val ty = targetY * h
          val tr = w * 0.16f

          drawLine(Color(0xFF747D8C), Offset(tx + 6f, 0f), Offset(tx + 6f, h), strokeWidth = 8f)

          drawCircle(Color.White, radius = tr, center = Offset(tx, ty))
          drawCircle(Color(0xFF2F3542), radius = tr * 0.8f, center = Offset(tx, ty))
          drawCircle(Color(0xFF0984E3), radius = tr * 0.6f, center = Offset(tx, ty))
          drawCircle(Color(0xFFFF5252), radius = tr * 0.4f, center = Offset(tx, ty))
          drawCircle(Color(0xFFFBC531), radius = tr * 0.2f, center = Offset(tx, ty))

          // Draw Bow on the left (x = 0.15f)
          val bx = w * 0.15f
          val by = h * 0.5f
          val bowHeight = 100f

          drawLine(Color(0xFFE17055), Offset(bx, by - bowHeight / 2), Offset(bx, by + bowHeight / 2), strokeWidth = 6f)

          val stringPullPoint = bowPullOffset ?: Offset(bx, by)
          drawLine(Color.White, Offset(bx, by - bowHeight / 2), stringPullPoint, strokeWidth = 2f)
          drawLine(Color.White, stringPullPoint, Offset(bx, by + bowHeight / 2), strokeWidth = 2f)

          // Draw Active Arrows
          activeArrows.forEach { arrow ->
            val ax = arrow.x * w
            val ay = arrow.y * h
            drawLine(Color(0xFFDFE6E9), Offset(ax - 28f, ay), Offset(ax, ay), strokeWidth = 3f)
            drawCircle(Color(0xFFFF7675), radius = 4f, center = Offset(ax, ay))
            drawLine(Color(0xFF00CEC9), Offset(ax - 28f, ay - 4f), Offset(ax - 20f, ay), strokeWidth = 2f)
            drawLine(Color(0xFF00CEC9), Offset(ax - 28f, ay + 4f), Offset(ax - 20f, ay), strokeWidth = 2f)
          }
        }
      }
    }
  }

  if (isPaused) {
    GamePauseDialog(
      onResume = { isPaused = false },
      onRestart = { resetGame() },
      onExit = onBack
    )
  }

  if (isGameOver) {
    GameOverDialog(
      isWin = score >= 200,
      score = score,
      highScore = highScore,
      onPlayAgain = { resetGame() },
      onExit = onBack
    )
  }
}
