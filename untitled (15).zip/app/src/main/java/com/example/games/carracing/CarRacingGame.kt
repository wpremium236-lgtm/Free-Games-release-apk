package com.example.games.carracing

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.core.model.GameDifficulty
import com.example.core.model.GameResultType
import com.example.games.common.GameOverDialog
import com.example.games.common.GamePauseDialog
import com.example.games.common.GameTopBar
import kotlinx.coroutines.delay
import java.util.UUID

data class EnemyCar(var x: Float, var y: Float, val color: Color, val speed: Float)
data class RoadItem(var x: Float, var y: Float, val isFuel: Boolean)

@Composable
fun CarRacingGame(
  onBack: () -> Unit,
  onGameFinished: (gameId: String, score: Int, resultType: GameResultType, duration: Long, sessionId: String) -> Unit
) {
  val context = LocalContext.current
  val soundManager = remember { SoundManager.getInstance(context) }
  var sessionId by remember { mutableStateOf(UUID.randomUUID().toString()) }
  var startTimeMs by remember { mutableStateOf(System.currentTimeMillis()) }
  var hasSubmittedSession by remember { mutableStateOf(false) }

  var playerLaneX by remember { mutableFloatStateOf(0.5f) }
  var targetLaneX by remember { mutableFloatStateOf(0.5f) }
  var roadOffset by remember { mutableFloatStateOf(0f) }
  var speed by remember { mutableFloatStateOf(8f) }
  var score by remember { mutableIntStateOf(0) }
  var highScore by remember { mutableIntStateOf(0) }
  var isPaused by remember { mutableStateOf(false) }
  var isMuted by remember { mutableStateOf(!soundManager.isSoundEnabled) }
  var isGameOver by remember { mutableStateOf(false) }
  var difficulty by remember { mutableStateOf(GameDifficulty.MEDIUM) }

  val enemies = remember { mutableStateListOf<EnemyCar>() }
  val items = remember { mutableStateListOf<RoadItem>() }

  fun triggerGameFinished() {
    if (!hasSubmittedSession) {
      hasSubmittedSession = true
      val duration = ((System.currentTimeMillis() - startTimeMs) / 1000L).coerceAtLeast(1L)
      onGameFinished("carracing", score, GameResultType.GAME_OVER, duration, sessionId)
    }
  }

  fun resetGame() {
    playerLaneX = 0.5f
    targetLaneX = 0.5f
    speed = when (difficulty) {
      GameDifficulty.EASY -> 6f
      GameDifficulty.MEDIUM -> 8f
      GameDifficulty.HARD -> 11f
    }
    score = 0
    enemies.clear()
    items.clear()
    isGameOver = false
    isPaused = false
    sessionId = UUID.randomUUID().toString()
    startTimeMs = System.currentTimeMillis()
    hasSubmittedSession = false
  }

  // Game loop
  LaunchedEffect(isPaused, isGameOver, difficulty) {
    var spawnTick = 0
    while (!isPaused && !isGameOver) {
      delay(30)
      spawnTick++

      playerLaneX += (targetLaneX - playerLaneX) * 0.35f
      playerLaneX = playerLaneX.coerceIn(0.2f, 0.8f)

      roadOffset = (roadOffset + speed) % 60f
      score += (speed * 0.1f).toInt().coerceAtLeast(1)

      if (score % 250 == 0) {
        speed = (speed + 0.3f).coerceAtMost(18f)
      }

      val spawnRate = when (difficulty) {
        GameDifficulty.EASY -> 45
        GameDifficulty.MEDIUM -> 32
        GameDifficulty.HARD -> 22
      }
      if (spawnTick % spawnRate == 0) {
        val lanePos = listOf(0.28f, 0.5f, 0.72f).random()
        val colors = listOf(Color(0xFFFF5252), Color(0xFF00CEC9), Color(0xFFFFB142), Color(0xFF9C88FF))
        enemies.add(EnemyCar(x = lanePos, y = -0.1f, color = colors.random(), speed = speed * 0.5f))
      }

      if (spawnTick % 60 == 0) {
        val itemPos = listOf(0.28f, 0.5f, 0.72f).random()
        items.add(RoadItem(x = itemPos, y = -0.08f, isFuel = true))
      }

      val iterator = enemies.iterator()
      while (iterator.hasNext()) {
        val enemy = iterator.next()
        enemy.y += (speed - enemy.speed) * 0.0015f + 0.015f

        if (enemy.y in 0.78f..0.92f && kotlin.math.abs(enemy.x - playerLaneX) < 0.16f) {
          isGameOver = true
          soundManager.playCollisionSound()
          soundManager.playLoseSound()
          triggerGameFinished()
          break
        }
        if (enemy.y > 1.2f) {
          iterator.remove()
        }
      }

      val itemIterator = items.iterator()
      while (itemIterator.hasNext()) {
        val item = itemIterator.next()
        item.y += speed * 0.001f + 0.012f
        if (item.y in 0.78f..0.92f && kotlin.math.abs(item.x - playerLaneX) < 0.16f) {
          score += 50
          soundManager.playScoreBeep()
          itemIterator.remove()
        } else if (item.y > 1.2f) {
          itemIterator.remove()
        }
      }
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F0C20))
  ) {
    GameTopBar(
      title = "Car Racing",
      score = score,
      highScore = highScore,
      isPaused = isPaused,
      isMuted = isMuted,
      onBack = onBack,
      onPauseToggle = { isPaused = !isPaused },
      onRestart = { resetGame() },
      onMuteToggle = {
        isMuted = !isMuted
        soundManager.isSoundEnabled = !isMuted
      }
    )

    // Racing Track Canvas with Drag Steering
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .padding(horizontal = 16.dp, vertical = 8.dp),
      contentAlignment = Alignment.Center
    ) {
      BoxWithConstraints(
        modifier = Modifier
          .fillMaxSize()
          .clip(RoundedCornerShape(16.dp))
          .background(Color(0xFF1E272E))
          .pointerInput(Unit) {
            detectDragGestures { change, dragAmount ->
              change.consume()
              targetLaneX += dragAmount.x / 400f
              targetLaneX = targetLaneX.coerceIn(0.2f, 0.8f)
            }
          }
      ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
          val w = size.width
          val h = size.height

          // Road boundaries
          drawRect(Color(0xFF2F3640), Offset(w * 0.15f, 0f), Size(w * 0.7f, h))

          // Road shoulder strips (red & white curbs)
          val curbH = 40f
          val numCurbs = (h / curbH).toInt() + 2
          for (i in 0..numCurbs) {
            val yPos = (i * curbH + roadOffset) % (h + curbH) - curbH
            val curbColor = if (i % 2 == 0) Color(0xFFFF5252) else Color.White
            drawRect(curbColor, Offset(w * 0.12f, yPos), Size(w * 0.03f, curbH))
            drawRect(curbColor, Offset(w * 0.85f, yPos), Size(w * 0.03f, curbH))
          }

          // Lane dividing dashed lines
          val dashH = 50f
          val numDashes = (h / (dashH * 2)).toInt() + 2
          for (i in 0..numDashes) {
            val yPos = (i * dashH * 2 + roadOffset * 1.5f) % (h + dashH * 2) - dashH
            drawLine(Color.White.copy(alpha = 0.7f), Offset(w * 0.38f, yPos), Offset(w * 0.38f, yPos + dashH), strokeWidth = 4f)
            drawLine(Color.White.copy(alpha = 0.7f), Offset(w * 0.62f, yPos), Offset(w * 0.62f, yPos + dashH), strokeWidth = 4f)
          }

          // Draw bonus items (Fuel cans)
          items.forEach { item ->
            val ix = item.x * w
            val iy = item.y * h
            drawRoundRect(
              Color(0xFFFFB142),
              topLeft = Offset(ix - 14f, iy - 16f),
              size = Size(28f, 32f),
              cornerRadius = CornerRadius(6f)
            )
            drawCircle(Color.White, radius = 5f, center = Offset(ix, iy))
          }

          // Draw enemy cars
          enemies.forEach { enemy ->
            val ex = enemy.x * w
            val ey = enemy.y * h
            // Body
            drawRoundRect(
              enemy.color,
              topLeft = Offset(ex - 22f, ey - 38f),
              size = Size(44f, 76f),
              cornerRadius = CornerRadius(10f)
            )
            // Windshield
            drawRoundRect(
              Color(0xFF1E272E),
              topLeft = Offset(ex - 16f, ey - 10f),
              size = Size(32f, 24f),
              cornerRadius = CornerRadius(4f)
            )
            // Headlights
            drawCircle(Color(0xFFFFF200), radius = 4f, center = Offset(ex - 14f, ey + 34f))
            drawCircle(Color(0xFFFFF200), radius = 4f, center = Offset(ex + 14f, ey + 34f))
          }

          // Draw player car
          val px = playerLaneX * w
          val py = h * 0.85f

          // Body (Sleek red sports car)
          drawRoundRect(
            Color(0xFFE84118),
            topLeft = Offset(px - 24f, py - 42f),
            size = Size(48f, 84f),
            cornerRadius = CornerRadius(12f)
          )
          // Windshield & roof
          drawRoundRect(
            Color(0xFF2F3640),
            topLeft = Offset(px - 17f, py - 18f),
            size = Size(34f, 30f),
            cornerRadius = CornerRadius(5f)
          )
          // Racing stripes
          drawLine(Color.White, Offset(px - 4f, py - 40f), Offset(px - 4f, py + 40f), strokeWidth = 3f)
          drawLine(Color.White, Offset(px + 4f, py - 40f), Offset(px + 4f, py + 40f), strokeWidth = 3f)
          // Tail lights
          drawCircle(Color(0xFFFF5252), radius = 4f, center = Offset(px - 16f, py + 38f))
          drawCircle(Color(0xFFFF5252), radius = 4f, center = Offset(px + 16f, py + 38f))
        }
      }
    }

    // Touch Steering Buttons & Speedometer
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 24.dp, vertical = 12.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      IconButton(
        onClick = { targetLaneX = (targetLaneX - 0.22f).coerceAtLeast(0.28f) },
        colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFF241F42)),
        modifier = Modifier.size(60.dp).testTag("car_left")
      ) {
        Icon(Icons.Default.KeyboardArrowLeft, contentDescription = "Steer Left", tint = Color.White, modifier = Modifier.size(36.dp))
      }
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("SPEED", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFA4B0BE))
        Text("${(speed * 12).toInt()} KM/H", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00CEC9))
      }
      IconButton(
        onClick = { targetLaneX = (targetLaneX + 0.22f).coerceAtMost(0.72f) },
        colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFF241F42)),
        modifier = Modifier.size(60.dp).testTag("car_right")
      ) {
        Icon(Icons.Default.KeyboardArrowRight, contentDescription = "Steer Right", tint = Color.White, modifier = Modifier.size(36.dp))
      }
    }
  }

  if (isPaused) {
    GamePauseDialog(
      onResume = { isPaused = false },
      onRestart = { resetGame() },
      onExit = onBack
    )
  }

  if (isGameOver) {
    GameOverDialog(
      gameTitle = "Car Racing",
      resultType = GameResultType.GAME_OVER,
      score = score,
      highScore = highScore,
      onPlayAgain = { resetGame() },
      onExit = onBack
    )
  }
}
