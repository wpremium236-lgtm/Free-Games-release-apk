package com.example.games.connectfour

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.core.model.GameDifficulty
import com.example.core.model.GameResultType
import com.example.games.common.GameOverDialog
import com.example.games.common.GamePauseDialog
import com.example.games.common.GameTopBar
import kotlinx.coroutines.delay
import java.util.UUID
import kotlin.random.Random

enum class ConnectPlayer(val color: Color, val label: String) {
  RED(Color(0xFFFF4757), "Player 1 (Red)"),
  YELLOW(Color(0xFFFFA502), "Player 2 (Yellow)")
}

enum class ConnectGameMode {
  SELECTION,
  VS_AI,
  LOCAL_2P
}

@Composable
fun ConnectFourGame(
  onBack: () -> Unit,
  onGameFinished: (gameId: String, score: Int, resultType: GameResultType, duration: Long, sessionId: String) -> Unit
) {
  val context = LocalContext.current
  val soundManager = remember { SoundManager.getInstance(context) }
  var mode by remember { mutableStateOf(ConnectGameMode.SELECTION) }
  var difficulty by remember { mutableStateOf(GameDifficulty.MEDIUM) }
  var sessionId by remember { mutableStateOf(UUID.randomUUID().toString()) }
  var startTimeMs by remember { mutableStateOf(System.currentTimeMillis()) }

  BackHandler {
    if (mode != ConnectGameMode.SELECTION) {
      mode = ConnectGameMode.SELECTION
    } else {
      onBack()
    }
  }

  // 6 rows x 7 columns. 0 = empty, 1 = RED, 2 = YELLOW
  val board = remember { mutableStateListOf<Int>().apply { addAll(List(42) { 0 }) } }
  var currentPlayer by remember { mutableStateOf(ConnectPlayer.RED) }
  var winningCells by remember { mutableStateOf<List<Int>>(emptyList()) }
  var isGameOver by remember { mutableStateOf(false) }
  var winner by remember { mutableStateOf<ConnectPlayer?>(null) }
  var isDraw by remember { mutableStateOf(false) }
  var isPaused by remember { mutableStateOf(false) }
  var isMuted by remember { mutableStateOf(!soundManager.isSoundEnabled) }
  var redScore by remember { mutableIntStateOf(0) }
  var yellowScore by remember { mutableIntStateOf(0) }
  var isAiThinking by remember { mutableStateOf(false) }

  fun checkWinnerOnGrid(grid: List<Int>): Pair<ConnectPlayer?, List<Int>> {
    // Check horizontal
    for (r in 0 until 6) {
      for (c in 0 until 4) {
        val idx = r * 7 + c
        val p = grid[idx]
        if (p != 0 && p == grid[idx + 1] && p == grid[idx + 2] && p == grid[idx + 3]) {
          val pl = if (p == 1) ConnectPlayer.RED else ConnectPlayer.YELLOW
          return Pair(pl, listOf(idx, idx + 1, idx + 2, idx + 3))
        }
      }
    }
    // Check vertical
    for (c in 0 until 7) {
      for (r in 0 until 3) {
        val idx = r * 7 + c
        val p = grid[idx]
        if (p != 0 && p == grid[idx + 7] && p == grid[idx + 14] && p == grid[idx + 21]) {
          val pl = if (p == 1) ConnectPlayer.RED else ConnectPlayer.YELLOW
          return Pair(pl, listOf(idx, idx + 7, idx + 14, idx + 21))
        }
      }
    }
    // Check diagonal (down-right)
    for (r in 0 until 3) {
      for (c in 0 until 4) {
        val idx = r * 7 + c
        val p = grid[idx]
        if (p != 0 && p == grid[idx + 8] && p == grid[idx + 16] && p == grid[idx + 24]) {
          val pl = if (p == 1) ConnectPlayer.RED else ConnectPlayer.YELLOW
          return Pair(pl, listOf(idx, idx + 8, idx + 16, idx + 24))
        }
      }
    }
    // Check diagonal (up-right)
    for (r in 3 until 6) {
      for (c in 0 until 4) {
        val idx = r * 7 + c
        val p = grid[idx]
        if (p != 0 && p == grid[idx - 6] && p == grid[idx - 12] && p == grid[idx - 18]) {
          val pl = if (p == 1) ConnectPlayer.RED else ConnectPlayer.YELLOW
          return Pair(pl, listOf(idx, idx - 6, idx - 12, idx - 18))
        }
      }
    }
    return Pair(null, emptyList())
  }

  fun resetBoard() {
    for (i in 0 until 42) board[i] = 0
    currentPlayer = ConnectPlayer.RED
    winningCells = emptyList()
    isGameOver = false
    winner = null
    isDraw = false
    isAiThinking = false
  }

  fun dropPiece(col: Int): Boolean {
    if (isGameOver || isAiThinking) return false
    var targetRow = -1
    for (r in 5 downTo 0) {
      if (board[r * 7 + col] == 0) {
        targetRow = r
        break
      }
    }
    if (targetRow == -1) return false

    val pieceVal = if (currentPlayer == ConnectPlayer.RED) 1 else 2
    board[targetRow * 7 + col] = pieceVal
    soundManager.playButtonClick()

    val (winResult, winLine) = checkWinnerOnGrid(board)
    if (winResult != null) {
      winner = winResult
      winningCells = winLine
      isGameOver = true
      if (winResult == ConnectPlayer.RED) {
        redScore++
        soundManager.playWinSound()
      } else {
        yellowScore++
        soundManager.playLoseSound()
      }
      val durationSec = ((System.currentTimeMillis() - startTimeMs) / 1000L).coerceAtLeast(1L)
      val resType = if (winResult == ConnectPlayer.RED) GameResultType.WIN else GameResultType.LOSS
      val finalScore = if (winResult == ConnectPlayer.RED) 100 + (42 - board.count { it != 0 }) * 5 else 20
      onGameFinished("connectfour", finalScore, resType, durationSec, sessionId)
      return true
    }

    if (board.none { it == 0 }) {
      isDraw = true
      isGameOver = true
      val durationSec = ((System.currentTimeMillis() - startTimeMs) / 1000L).coerceAtLeast(1L)
      onGameFinished("connectfour", 50, GameResultType.DRAW, durationSec, sessionId)
      return true
    }

    currentPlayer = if (currentPlayer == ConnectPlayer.RED) ConnectPlayer.YELLOW else ConnectPlayer.RED
    return true
  }

  fun findAiMove(): Int {
    val validCols = (0 until 7).filter { col -> board[col] == 0 }
    if (validCols.isEmpty()) return 0

    // 1. Check if AI (YELLOW = 2) can win in 1 move
    for (col in validCols) {
      var r = -1
      for (row in 5 downTo 0) {
        if (board[row * 7 + col] == 0) { r = row; break }
      }
      if (r != -1) {
        val testGrid = board.toMutableList()
        testGrid[r * 7 + col] = 2
        if (checkWinnerOnGrid(testGrid).first == ConnectPlayer.YELLOW) return col
      }
    }

    // 2. Check if player (RED = 1) can win in 1 move, block them
    if (difficulty != GameDifficulty.EASY) {
      for (col in validCols) {
        var r = -1
        for (row in 5 downTo 0) {
          if (board[row * 7 + col] == 0) { r = row; break }
        }
        if (r != -1) {
          val testGrid = board.toMutableList()
          testGrid[r * 7 + col] = 1
          if (checkWinnerOnGrid(testGrid).first == ConnectPlayer.RED) return col
        }
      }
    }

    // 3. Prefer center column (3) then adjacent (2, 4)
    val preferences = listOf(3, 2, 4, 1, 5, 0, 6)
    if (difficulty == GameDifficulty.HARD) {
      for (pref in preferences) {
        if (pref in validCols) {
          var r = -1
          for (row in 5 downTo 0) {
            if (board[row * 7 + pref] == 0) { r = row; break }
          }
          if (r > 0) {
            val testGrid = board.toMutableList()
            testGrid[(r - 1) * 7 + pref] = 1
            if (checkWinnerOnGrid(testGrid).first == ConnectPlayer.RED) {
              continue
            }
          }
          return pref
        }
      }
    }
    return validCols.random()
  }

  // Trigger AI turn
  LaunchedEffect(currentPlayer, mode, isGameOver) {
    if (!isGameOver && mode == ConnectGameMode.VS_AI && currentPlayer == ConnectPlayer.YELLOW) {
      isAiThinking = true
      delay(Random.nextLong(350, 700))
      val moveCol = findAiMove()
      dropPiece(moveCol)
      isAiThinking = false
    }
  }

  if (mode == ConnectGameMode.SELECTION) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(Color(0xFF0F0C20))
        .padding(16.dp),
      contentAlignment = Alignment.Center
    ) {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxWidth(0.9f)
      ) {
        Text("🔴 CONNECT FOUR 🟡", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("Connect 4 discs horizontally, vertically or diagonally!", fontSize = 14.sp, color = Color(0xFFA4B0BE))
        Spacer(modifier = Modifier.height(12.dp))

        Card(
          colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1B38)),
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier
            .fillMaxWidth()
            .clickable {
              mode = ConnectGameMode.VS_AI
              resetBoard()
            }
            .testTag("connectfour_ai_btn")
        ) {
          Row(
            modifier = Modifier.padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.SmartToy, contentDescription = null, tint = Color(0xFFFF4757), modifier = Modifier.size(36.dp))
            Spacer(modifier = Modifier.width(16.dp))
            Column {
              Text("Play vs Computer", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color.White)
              Text("Offline AI with Easy, Medium & Hard", fontSize = 13.sp, color = Color(0xFFA4B0BE))
            }
          }
        }

        Card(
          colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1B38)),
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier
            .fillMaxWidth()
            .clickable {
              mode = ConnectGameMode.LOCAL_2P
              resetBoard()
            }
            .testTag("connectfour_2p_btn")
        ) {
          Row(
            modifier = Modifier.padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.People, contentDescription = null, tint = Color(0xFFFFA502), modifier = Modifier.size(36.dp))
            Spacer(modifier = Modifier.width(16.dp))
            Column {
              Text("Local 2-Player (Pass & Play)", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color.White)
              Text("Play on same device with a friend offline", fontSize = 13.sp, color = Color(0xFFA4B0BE))
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Button(
          onClick = onBack,
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E2A52)),
          modifier = Modifier.fillMaxWidth().testTag("connectfour_back_btn")
        ) {
          Text("Back to Hub", color = Color.White)
        }
      }
    }
    return
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F0C20))
  ) {
    GameTopBar(
      title = "Connect Four",
      score = if (mode == ConnectGameMode.VS_AI) redScore else null,
      isPaused = isPaused,
      isMuted = isMuted,
      onBack = { mode = ConnectGameMode.SELECTION },
      onPauseToggle = { isPaused = !isPaused },
      onRestart = { resetBoard() },
      onMuteToggle = {
        soundManager.isSoundEnabled = !soundManager.isSoundEnabled
        isMuted = !soundManager.isSoundEnabled
      }
    )

    // Status / Turn Indicator
    Card(
      colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1633)),
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 8.dp),
      shape = RoundedCornerShape(12.dp)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(16.dp)
              .clip(CircleShape)
              .background(currentPlayer.color)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = if (isAiThinking) "Computer Thinking..." else "${currentPlayer.label}'s Turn",
            fontWeight = FontWeight.Bold,
            color = Color.White,
            fontSize = 14.sp
          )
        }
        Text(
          text = if (mode == ConnectGameMode.VS_AI) "You: $redScore | AI: $yellowScore" else "Red: $redScore | Yellow: $yellowScore",
          fontWeight = FontWeight.SemiBold,
          color = Color(0xFFFFB142),
          fontSize = 13.sp
        )
      }
    }

    // Connect Four Board: 7 Columns x 6 Rows
    BoxWithConstraints(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .padding(12.dp),
      contentAlignment = Alignment.Center
    ) {
      val maxW = maxWidth
      val maxH = maxHeight
      val cellSize = minOf(maxW / 7.5f, maxH / 7f)

      Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1B4F72)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
          .border(3.dp, Color(0xFF2E86C1), RoundedCornerShape(16.dp))
          .padding(8.dp)
      ) {
        Column(
          verticalArrangement = Arrangement.spacedBy(4.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier = Modifier.padding(4.dp)
        ) {
          for (r in 0 until 6) {
            Row(
              horizontalArrangement = Arrangement.spacedBy(4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              for (c in 0 until 7) {
                val idx = r * 7 + c
                val cellVal = board[idx]
                val isWinCell = idx in winningCells

                Box(
                  modifier = Modifier
                    .size(cellSize)
                    .clip(CircleShape)
                    .background(
                      when (cellVal) {
                        1 -> ConnectPlayer.RED.color
                        2 -> ConnectPlayer.YELLOW.color
                        else -> Color(0xFF0F0C20)
                      }
                    )
                    .border(
                      width = if (isWinCell) 3.dp else 1.dp,
                      color = if (isWinCell) Color.White else Color(0xFF2E86C1),
                      shape = CircleShape
                    )
                    .clickable(enabled = !isGameOver && !isAiThinking) {
                      dropPiece(c)
                    }
                    .testTag("cell_${r}_${c}")
                )
              }
            }
          }
        }
      }
    }

    // Column Quick Drop Buttons
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 8.dp),
      horizontalArrangement = Arrangement.SpaceEvenly
    ) {
      for (c in 0 until 7) {
        Button(
          onClick = { dropPiece(c) },
          enabled = !isGameOver && !isAiThinking && board[c] == 0,
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF241F42)),
          shape = CircleShape,
          modifier = Modifier
            .size(38.dp)
            .testTag("drop_col_$c")
        ) {
          Text("↓", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
      }
    }

    if (isPaused) {
      GamePauseDialog(
        onResume = { isPaused = false },
        onRestart = {
          resetBoard()
          isPaused = false
        },
        onExit = { mode = ConnectGameMode.SELECTION }
      )
    }

    if (isGameOver) {
      GameOverDialog(
        gameTitle = "Connect Four",
        resultType = if (isDraw) GameResultType.DRAW else if (winner == ConnectPlayer.RED) GameResultType.WIN else GameResultType.LOSS,
        score = if (winner == ConnectPlayer.RED) 100 else if (isDraw) 50 else 20,
        highScore = redScore * 100,
        onPlayAgain = { resetBoard() },
        onExit = { mode = ConnectGameMode.SELECTION }
      )
    }
  }
}
