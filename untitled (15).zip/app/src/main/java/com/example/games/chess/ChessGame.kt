package com.example.games.chess

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.core.audio.SoundManager
import com.example.core.model.GameDifficulty
import com.example.core.model.GameResultType
import com.example.games.common.GameOverDialog
import com.example.games.common.GamePauseDialog
import com.example.games.common.GameTopBar
import kotlinx.coroutines.delay
import java.util.UUID
import kotlin.math.abs

enum class PieceColor { WHITE, BLACK }
enum class PieceType(val symbolWhite: String, val symbolBlack: String, val value: Int) {
  PAWN("♙", "♟", 100),
  KNIGHT("♘", "♞", 320),
  BISHOP("♗", "♝", 330),
  ROOK("♖", "♜", 500),
  QUEEN("♕", "♛", 900),
  KING("♔", "♚", 20000)
}

data class ChessPiece(
  val type: PieceType,
  val color: PieceColor,
  var hasMoved: Boolean = false
)

data class ChessMove(
  val fromR: Int, val fromC: Int,
  val toR: Int, val toC: Int,
  val isCastling: Boolean = false,
  val isEnPassant: Boolean = false,
  val isPromotion: Boolean = false
)

@Composable
fun ChessGame(
  onBack: () -> Unit,
  onGameFinished: (gameId: String, score: Int, resultType: GameResultType, duration: Long, sessionId: String) -> Unit
) {
  val context = LocalContext.current
  val soundManager = remember { SoundManager.getInstance(context) }
  var sessionId by remember { mutableStateOf(UUID.randomUUID().toString()) }
  var startTimeMs by remember { mutableStateOf(System.currentTimeMillis()) }
  var hasSubmittedSession by remember { mutableStateOf(false) }

  fun triggerGameFinished(resultType: GameResultType, finalScore: Int) {
    if (!hasSubmittedSession) {
      hasSubmittedSession = true
      val duration = ((System.currentTimeMillis() - startTimeMs) / 1000L).coerceAtLeast(1L)
      onGameFinished("chess", finalScore, resultType, duration, sessionId)
    }
  }

  var isAiMode by remember { mutableStateOf(true) }
  var difficulty by remember { mutableStateOf(GameDifficulty.MEDIUM) }
  var currentTurn by remember { mutableStateOf(PieceColor.WHITE) }
  var selectedSquare by remember { mutableStateOf<Pair<Int, Int>?>(null) }
  var legalMovesForSelected by remember { mutableStateOf<List<ChessMove>>(emptyList()) }
  var enPassantTarget by remember { mutableStateOf<Pair<Int, Int>?>(null) }
  var isCheck by remember { mutableStateOf(false) }
  var isCheckmate by remember { mutableStateOf(false) }
  var isStalemate by remember { mutableStateOf(false) }
  var isPaused by remember { mutableStateOf(false) }
  var isMuted by remember { mutableStateOf(!soundManager.isSoundEnabled) }
  var promotionPendingMove by remember { mutableStateOf<ChessMove?>(null) }

  // 8x8 Board representation
  val board = remember {
    mutableStateListOf<MutableList<ChessPiece?>>().apply {
      for (r in 0..7) {
        add(MutableList(8) { null })
      }
    }
  }

  fun setupBoard() {
    for (r in 0..7) {
      for (c in 0..7) {
        board[r][c] = null
      }
    }

    // Black pieces at top (rows 0 and 1)
    val backRankOrder = listOf(
      PieceType.ROOK, PieceType.KNIGHT, PieceType.BISHOP, PieceType.QUEEN,
      PieceType.KING, PieceType.BISHOP, PieceType.KNIGHT, PieceType.ROOK
    )
    for (c in 0..7) {
      board[0][c] = ChessPiece(backRankOrder[c], PieceColor.BLACK)
      board[1][c] = ChessPiece(PieceType.PAWN, PieceColor.BLACK)
      board[6][c] = ChessPiece(PieceType.PAWN, PieceColor.WHITE)
      board[7][c] = ChessPiece(backRankOrder[c], PieceColor.WHITE)
    }

    currentTurn = PieceColor.WHITE
    selectedSquare = null
    legalMovesForSelected = emptyList()
    enPassantTarget = null
    isCheck = false
    isCheckmate = false
    isStalemate = false
    sessionId = UUID.randomUUID().toString()
    startTimeMs = System.currentTimeMillis()
    hasSubmittedSession = false
  }

  remember {
    setupBoard()
    true
  }

  fun isInside(r: Int, c: Int): Boolean = r in 0..7 && c in 0..7

  // Generate pseudo-legal moves for a piece without king check filter
  fun generatePseudoMoves(r: Int, c: Int, b: List<List<ChessPiece?>>): List<ChessMove> {
    val piece = b[r][c] ?: return emptyList()
    val moves = mutableListOf<ChessMove>()
    val forward = if (piece.color == PieceColor.WHITE) -1 else 1

    when (piece.type) {
      PieceType.PAWN -> {
        // Forward 1
        val f1R = r + forward
        if (isInside(f1R, c) && b[f1R][c] == null) {
          val isProm = (piece.color == PieceColor.WHITE && f1R == 0) || (piece.color == PieceColor.BLACK && f1R == 7)
          moves.add(ChessMove(r, c, f1R, c, isPromotion = isProm))
          // Forward 2
          val startRow = if (piece.color == PieceColor.WHITE) 6 else 1
          val f2R = r + forward * 2
          if (r == startRow && b[f2R][c] == null) {
            moves.add(ChessMove(r, c, f2R, c))
          }
        }
        // Captures
        for (dc in listOf(-1, 1)) {
          val capR = r + forward
          val capC = c + dc
          if (isInside(capR, capC)) {
            val target = b[capR][capC]
            val isProm = (piece.color == PieceColor.WHITE && capR == 0) || (piece.color == PieceColor.BLACK && capR == 7)
            if (target != null && target.color != piece.color) {
              moves.add(ChessMove(r, c, capR, capC, isPromotion = isProm))
            } else if (enPassantTarget == Pair(capR, capC)) {
              moves.add(ChessMove(r, c, capR, capC, isEnPassant = true))
            }
          }
        }
      }
      PieceType.KNIGHT -> {
        val offsets = listOf(
          Pair(-2, -1), Pair(-2, 1), Pair(-1, -2), Pair(-1, 2),
          Pair(1, -2), Pair(1, 2), Pair(2, -1), Pair(2, 1)
        )
        for ((dr, dc) in offsets) {
          val tr = r + dr
          val tc = c + dc
          if (isInside(tr, tc) && (b[tr][tc] == null || b[tr][tc]?.color != piece.color)) {
            moves.add(ChessMove(r, c, tr, tc))
          }
        }
      }
      PieceType.BISHOP, PieceType.ROOK, PieceType.QUEEN -> {
        val dirs = mutableListOf<Pair<Int, Int>>()
        if (piece.type != PieceType.ROOK) dirs.addAll(listOf(Pair(-1, -1), Pair(-1, 1), Pair(1, -1), Pair(1, 1)))
        if (piece.type != PieceType.BISHOP) dirs.addAll(listOf(Pair(-1, 0), Pair(1, 0), Pair(0, -1), Pair(0, 1)))
        for ((dr, dc) in dirs) {
          var tr = r + dr
          var tc = c + dc
          while (isInside(tr, tc)) {
            if (b[tr][tc] == null) {
              moves.add(ChessMove(r, c, tr, tc))
            } else {
              if (b[tr][tc]?.color != piece.color) {
                moves.add(ChessMove(r, c, tr, tc))
              }
              break
            }
            tr += dr
            tc += dc
          }
        }
      }
      PieceType.KING -> {
        for (dr in -1..1) {
          for (dc in -1..1) {
            if (dr == 0 && dc == 0) continue
            val tr = r + dr
            val tc = c + dc
            if (isInside(tr, tc) && (b[tr][tc] == null || b[tr][tc]?.color != piece.color)) {
              moves.add(ChessMove(r, c, tr, tc))
            }
          }
        }
        // Castling
        if (!piece.hasMoved && !isCheck) {
          // Kingside
          if (b[r][5] == null && b[r][6] == null) {
            val rook = b[r][7]
            if (rook != null && rook.type == PieceType.ROOK && !rook.hasMoved) {
              moves.add(ChessMove(r, c, r, 6, isCastling = true))
            }
          }
          // Queenside
          if (b[r][1] == null && b[r][2] == null && b[r][3] == null) {
            val rook = b[r][0]
            if (rook != null && rook.type == PieceType.ROOK && !rook.hasMoved) {
              moves.add(ChessMove(r, c, r, 2, isCastling = true))
            }
          }
        }
      }
    }
    return moves
  }

  // Check if king of a given color is under attack
  fun isKingInCheck(color: PieceColor, b: List<List<ChessPiece?>>): Boolean {
    var kingPos: Pair<Int, Int>? = null
    for (r in 0..7) {
      for (c in 0..7) {
        val p = b[r][c]
        if (p != null && p.type == PieceType.KING && p.color == color) {
          kingPos = Pair(r, c)
          break
        }
      }
    }
    val kp = kingPos ?: return false

    val opponentColor = if (color == PieceColor.WHITE) PieceColor.BLACK else PieceColor.WHITE
    for (r in 0..7) {
      for (c in 0..7) {
        val p = b[r][c]
        if (p != null && p.color == opponentColor) {
          val pseudo = generatePseudoMoves(r, c, b)
          if (pseudo.any { it.toR == kp.first && it.toC == kp.second }) return true
        }
      }
    }
    return false
  }

  // Filter legal moves by simulating move and verifying King is not in check
  fun getLegalMoves(r: Int, c: Int): List<ChessMove> {
    val piece = board[r][c] ?: return emptyList()
    val pseudo = generatePseudoMoves(r, c, board)
    val legal = mutableListOf<ChessMove>()
    for (move in pseudo) {
      val tempBoard = board.map { it.toMutableList() }
      tempBoard[move.toR][move.toC] = tempBoard[move.fromR][move.fromC]
      tempBoard[move.fromR][move.fromC] = null
      if (move.isEnPassant) {
        val capR = if (piece.color == PieceColor.WHITE) move.toR + 1 else move.toR - 1
        tempBoard[capR][move.toC] = null
      }
      if (!isKingInCheck(piece.color, tempBoard)) {
        legal.add(move)
      }
    }
    return legal
  }

  fun executeMove(move: ChessMove, promotionChoice: PieceType = PieceType.QUEEN) {
    val piece = board[move.fromR][move.fromC] ?: return
    soundManager.playMoveSound()

    // Handle En Passant capture
    if (move.isEnPassant) {
      val capR = if (piece.color == PieceColor.WHITE) move.toR + 1 else move.toR - 1
      board[capR][move.toC] = null
      soundManager.playCollisionSound()
    }
    // Handle Castling rook jump
    if (move.isCastling) {
      if (move.toC == 6) {
        board[move.fromR][5] = board[move.fromR][7]
        board[move.fromR][7] = null
      } else if (move.toC == 2) {
        board[move.fromR][3] = board[move.fromR][0]
        board[move.fromR][0] = null
      }
    }
    // Capture sound
    if (board[move.toR][move.toC] != null) {
      soundManager.playCollisionSound()
    }
    // Move piece
    board[move.toR][move.toC] = piece.copy(
      type = if (move.isPromotion) promotionChoice else piece.type,
      hasMoved = true
    )
    board[move.fromR][move.fromC] = null

    // Update En Passant target if 2-step pawn jump
    if (piece.type == PieceType.PAWN && abs(move.toR - move.fromR) == 2) {
      enPassantTarget = Pair((move.fromR + move.toR) / 2, move.fromC)
    } else {
      enPassantTarget = null
    }

    // Switch turn
    val nextColor = if (currentTurn == PieceColor.WHITE) PieceColor.BLACK else PieceColor.WHITE
    currentTurn = nextColor
    selectedSquare = null
    legalMovesForSelected = emptyList()

    // Check / Checkmate verification
    val kingInCheck = isKingInCheck(nextColor, board)
    isCheck = kingInCheck

    // Check if nextColor has any legal moves
    var anyLegal = false
    for (r in 0..7) {
      for (c in 0..7) {
        if (board[r][c]?.color == nextColor) {
          if (getLegalMoves(r, c).isNotEmpty()) {
            anyLegal = true
            break
          }
        }
      }
      if (anyLegal) break
    }

    if (!anyLegal) {
      if (kingInCheck) {
        isCheckmate = true
        val isWin = currentTurn == PieceColor.BLACK
        if (isWin) soundManager.playWinSound() else soundManager.playLoseSound()
        val finalScore = if (isWin) 1500 else 200
        triggerGameFinished(if (isWin) GameResultType.WIN else GameResultType.LOSS, finalScore)
      } else {
        isStalemate = true
        soundManager.playScoreBeep()
        triggerGameFinished(GameResultType.DRAW, 500)
      }
    }
  }

  fun onSquareClicked(r: Int, c: Int) {
    if (isAiMode && currentTurn == PieceColor.BLACK) return
    if (isCheckmate || isStalemate) return

    val selected = selectedSquare
    if (selected != null) {
      val matchedMove = legalMovesForSelected.firstOrNull { it.toR == r && it.toC == c }
      if (matchedMove != null) {
        if (matchedMove.isPromotion) {
          promotionPendingMove = matchedMove
        } else {
          executeMove(matchedMove)
        }
        return
      }
    }

    val clickedPiece = board[r][c]
    if (clickedPiece != null && clickedPiece.color == currentTurn) {
      selectedSquare = Pair(r, c)
      legalMovesForSelected = getLegalMoves(r, c)
      soundManager.playButtonClick()
    } else {
      selectedSquare = null
      legalMovesForSelected = emptyList()
    }
  }

  // AI turn execution
  LaunchedEffect(currentTurn, isAiMode, isCheckmate, isStalemate) {
    if (isAiMode && currentTurn == PieceColor.BLACK && !isCheckmate && !isStalemate) {
      delay(600)
      val allAiMoves = mutableListOf<ChessMove>()
      for (r in 0..7) {
        for (c in 0..7) {
          if (board[r][c]?.color == PieceColor.BLACK) {
            allAiMoves.addAll(getLegalMoves(r, c))
          }
        }
      }
      if (allAiMoves.isNotEmpty()) {
        val chosenMove = when (difficulty) {
          GameDifficulty.EASY -> allAiMoves.random()
          GameDifficulty.MEDIUM -> {
            allAiMoves.firstOrNull { board[it.toR][it.toC] != null } ?: allAiMoves.random()
          }
          GameDifficulty.HARD -> {
            allAiMoves.maxByOrNull { move ->
              val target = board[move.toR][move.toC]
              var score = target?.type?.value ?: 0
              if (move.toR in 3..4 && move.toC in 3..4) score += 30
              score
            } ?: allAiMoves.random()
          }
        }
        executeMove(chosenMove, PieceType.QUEEN)
      }
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F0C20))
  ) {
    GameTopBar(
      title = "Chess",
      isPaused = isPaused,
      isMuted = isMuted,
      onBack = onBack,
      onPauseToggle = { isPaused = !isPaused },
      onRestart = { setupBoard() },
      onMuteToggle = {
        isMuted = !isMuted
        soundManager.isSoundEnabled = !isMuted
      }
    )

    // Options bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row {
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isAiMode) Color(0xFF6C5CE7) else Color(0xFF1E1B38))
            .clickable { isAiMode = true; setupBoard() }
            .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Text("vs AI", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.width(6.dp))
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (!isAiMode) Color(0xFF6C5CE7) else Color(0xFF1E1B38))
            .clickable { isAiMode = false; setupBoard() }
            .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Text("2-Player", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
      }

      Text(
        text = if (isCheckmate) "CHECKMATE!" else if (isCheck) "CHECK!" else "${currentTurn.name}'S TURN",
        fontWeight = FontWeight.Bold,
        color = if (isCheck) Color(0xFFFF5252) else Color(0xFF00CEC9),
        fontSize = 12.sp
      )
    }

    // 8x8 Chessboard
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .padding(12.dp),
      contentAlignment = Alignment.Center
    ) {
      BoxWithConstraints(
        modifier = Modifier
          .aspectRatio(1f)
          .clip(RoundedCornerShape(12.dp))
          .background(Color(0xFF18152E))
          .border(2.dp, Color(0xFF6C5CE7), RoundedCornerShape(12.dp))
          .padding(4.dp)
      ) {
        Column(modifier = Modifier.fillMaxSize()) {
          for (r in 0..7) {
            Row(modifier = Modifier.weight(1f)) {
              for (c in 0..7) {
                val isLightSquare = (r + c) % 2 == 0
                val isSelected = selectedSquare == Pair(r, c)
                val isLegalDest = legalMovesForSelected.any { it.toR == r && it.toC == c }
                val piece = board[r][c]

                Box(
                  modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .background(
                      when {
                        isSelected -> Color(0xFF6C5CE7).copy(alpha = 0.6f)
                        isLegalDest -> Color(0xFF00CEC9).copy(alpha = 0.35f)
                        isLightSquare -> Color(0xFFEDE0C8)
                        else -> Color(0xFF779556)
                      }
                    )
                    .clickable { onSquareClicked(r, c) }
                    .testTag("chess_sq_${r}_${c}"),
                  contentAlignment = Alignment.Center
                ) {
                  if (piece != null) {
                    Text(
                      text = if (piece.color == PieceColor.WHITE) piece.type.symbolWhite else piece.type.symbolBlack,
                      fontSize = 28.sp,
                      color = if (piece.color == PieceColor.WHITE) Color.White else Color(0xFF1A1A2E)
                    )
                  } else if (isLegalDest) {
                    Box(
                      modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF2ED573))
                    )
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  // Promotion Dialog
  promotionPendingMove?.let { move ->
    Dialog(onDismissRequest = {}) {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF18152E)),
        modifier = Modifier.padding(16.dp)
      ) {
        Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
          Text("Promote Pawn", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 18.sp)
          Spacer(modifier = Modifier.height(16.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            listOf(PieceType.QUEEN, PieceType.ROOK, PieceType.BISHOP, PieceType.KNIGHT).forEach { pType ->
              Button(
                onClick = {
                  executeMove(move, pType)
                  promotionPendingMove = null
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF241F42))
              ) {
                Text(pType.symbolWhite, fontSize = 24.sp)
              }
            }
          }
        }
      }
    }
  }

  if (isPaused) {
    GamePauseDialog(
      onResume = { isPaused = false },
      onRestart = { setupBoard() },
      onExit = onBack
    )
  }

  if (isCheckmate || isStalemate) {
    val isWin = isCheckmate && currentTurn == PieceColor.BLACK
    val resultType = when {
      isCheckmate && isWin -> GameResultType.WIN
      isCheckmate -> GameResultType.LOSS
      else -> GameResultType.DRAW
    }
    val score = when (resultType) {
      GameResultType.WIN -> 1500
      GameResultType.DRAW -> 500
      else -> 200
    }
    GameOverDialog(
      gameTitle = "Chess",
      resultType = resultType,
      score = score,
      highScore = 1500,
      onPlayAgain = { setupBoard() },
      onExit = onBack
    )
  }
}
