package com.example.games.checkers

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.core.model.GameResultType
import com.example.games.common.GameOverDialog
import com.example.games.common.GamePauseDialog
import com.example.games.common.GameTopBar
import kotlinx.coroutines.delay
import java.util.UUID

enum class CheckersPieceColor { RED, WHITE }

data class CheckersPiece(
  val color: CheckersPieceColor,
  var isKing: Boolean = false
)

data class CheckersMove(
  val fromR: Int, val fromC: Int,
  val toR: Int, val toC: Int,
  val capturedR: Int? = null,
  val capturedC: Int? = null
)

@Composable
fun CheckersGame(
  onBack: () -> Unit,
  onGameFinished: (gameId: String, score: Int, resultType: GameResultType, duration: Long, sessionId: String) -> Unit
) {
  val context = LocalContext.current
  val soundManager = remember { SoundManager.getInstance(context) }
  var sessionId by remember { mutableStateOf(UUID.randomUUID().toString()) }
  var startTimeMs by remember { mutableStateOf(System.currentTimeMillis()) }
  var hasSubmittedSession by remember { mutableStateOf(false) }

  fun triggerGameFinished(resultType: GameResultType, finalScore: Int) {
    if (!hasSubmittedSession) {
      hasSubmittedSession = true
      val duration = ((System.currentTimeMillis() - startTimeMs) / 1000L).coerceAtLeast(1L)
      onGameFinished("checkers", finalScore, resultType, duration, sessionId)
    }
  }

  var isAiMode by remember { mutableStateOf(true) }
  var currentTurn by remember { mutableStateOf(CheckersPieceColor.RED) }
  var selectedSquare by remember { mutableStateOf<Pair<Int, Int>?>(null) }
  var legalMovesForSelected by remember { mutableStateOf<List<CheckersMove>>(emptyList()) }
  var isPaused by remember { mutableStateOf(false) }
  var isMuted by remember { mutableStateOf(!soundManager.isSoundEnabled) }
  var isGameOver by remember { mutableStateOf(false) }
  var winner by remember { mutableStateOf<CheckersPieceColor?>(null) }

  val board = remember {
    mutableStateListOf<MutableList<CheckersPiece?>>().apply {
      for (r in 0..7) {
        add(MutableList(8) { null })
      }
    }
  }

  fun setupBoard() {
    for (r in 0..7) {
      for (c in 0..7) {
        board[r][c] = null
        if ((r + c) % 2 == 1) {
          if (r in 0..2) board[r][c] = CheckersPiece(CheckersPieceColor.WHITE)
          else if (r in 5..7) board[r][c] = CheckersPiece(CheckersPieceColor.RED)
        }
      }
    }
    currentTurn = CheckersPieceColor.RED
    selectedSquare = null
    legalMovesForSelected = emptyList()
    isGameOver = false
    winner = null
    sessionId = UUID.randomUUID().toString()
    startTimeMs = System.currentTimeMillis()
    hasSubmittedSession = false
  }

  remember {
    setupBoard()
    true
  }

  fun isInside(r: Int, c: Int) = r in 0..7 && c in 0..7

  fun getJumpsForPiece(r: Int, c: Int): List<CheckersMove> {
    val piece = board[r][c] ?: return emptyList()
    val jumps = mutableListOf<CheckersMove>()
    val rowDirs = if (piece.isKing) listOf(-1, 1) else if (piece.color == CheckersPieceColor.RED) listOf(-1) else listOf(1)
    val colDirs = listOf(-1, 1)

    for (dr in rowDirs) {
      for (dc in colDirs) {
        val midR = r + dr
        val midC = c + dc
        val destR = r + dr * 2
        val destC = c + dc * 2
        if (isInside(destR, destC) && board[destR][destC] == null) {
          val midPiece = board[midR][midC]
          if (midPiece != null && midPiece.color != piece.color) {
            jumps.add(CheckersMove(r, c, destR, destC, midR, midC))
          }
        }
      }
    }
    return jumps
  }

  fun getAllJumps(color: CheckersPieceColor): List<CheckersMove> {
    val jumps = mutableListOf<CheckersMove>()
    for (r in 0..7) {
      for (c in 0..7) {
        if (board[r][c]?.color == color) {
          jumps.addAll(getJumpsForPiece(r, c))
        }
      }
    }
    return jumps
  }

  fun getSimpleMovesForPiece(r: Int, c: Int): List<CheckersMove> {
    val piece = board[r][c] ?: return emptyList()
    val moves = mutableListOf<CheckersMove>()
    val rowDirs = if (piece.isKing) listOf(-1, 1) else if (piece.color == CheckersPieceColor.RED) listOf(-1) else listOf(1)
    val colDirs = listOf(-1, 1)

    for (dr in rowDirs) {
      for (dc in colDirs) {
        val destR = r + dr
        val destC = c + dc
        if (isInside(destR, destC) && board[destR][destC] == null) {
          moves.add(CheckersMove(r, c, destR, destC))
        }
      }
    }
    return moves
  }

  fun getLegalMovesForPiece(r: Int, c: Int): List<CheckersMove> {
    val piece = board[r][c] ?: return emptyList()
    val mandatoryJumps = getAllJumps(piece.color)
    return if (mandatoryJumps.isNotEmpty()) {
      getJumpsForPiece(r, c)
    } else {
      getSimpleMovesForPiece(r, c)
    }
  }

  fun executeMove(move: CheckersMove) {
    val piece = board[move.fromR][move.fromC] ?: return
    soundManager.playMoveSound()

    // Move piece
    board[move.toR][move.toC] = piece
    board[move.fromR][move.fromC] = null

    // Remove captured piece if jump
    if (move.capturedR != null && move.capturedC != null) {
      board[move.capturedR][move.capturedC] = null
      soundManager.playCollisionSound()
    }

    // Crown to King if reached back rank
    if ((piece.color == CheckersPieceColor.RED && move.toR == 0) ||
      (piece.color == CheckersPieceColor.WHITE && move.toR == 7)) {
      piece.isKing = true
      soundManager.playScoreBeep()
    }

    // Check multi-jump continuation
    if (move.capturedR != null) {
      val extraJumps = getJumpsForPiece(move.toR, move.toC)
      if (extraJumps.isNotEmpty()) {
        selectedSquare = Pair(move.toR, move.toC)
        legalMovesForSelected = extraJumps
        return // same player keeps jumping
      }
    }

    // Switch turn
    val nextColor = if (currentTurn == CheckersPieceColor.RED) CheckersPieceColor.WHITE else CheckersPieceColor.RED
    currentTurn = nextColor
    selectedSquare = null
    legalMovesForSelected = emptyList()

    // Check victory
    var anyOpponentMoves = false
    for (r in 0..7) {
      for (c in 0..7) {
        if (board[r][c]?.color == nextColor && getLegalMovesForPiece(r, c).isNotEmpty()) {
          anyOpponentMoves = true
          break
        }
      }
      if (anyOpponentMoves) break
    }

    if (!anyOpponentMoves) {
      isGameOver = true
      winner = piece.color
      val isWin = winner == CheckersPieceColor.RED
      if (isWin) soundManager.playWinSound() else soundManager.playLoseSound()
      val score = if (isWin) 1000 else 200
      triggerGameFinished(if (isWin) GameResultType.WIN else GameResultType.LOSS, score)
    }
  }

  fun onSquareClick(r: Int, c: Int) {
    if (isAiMode && currentTurn == CheckersPieceColor.WHITE) return
    if (isGameOver) return

    val selected = selectedSquare
    if (selected != null) {
      val matched = legalMovesForSelected.firstOrNull { it.toR == r && it.toC == c }
      if (matched != null) {
        executeMove(matched)
        return
      }
    }

    val p = board[r][c]
    if (p != null && p.color == currentTurn) {
      selectedSquare = Pair(r, c)
      legalMovesForSelected = getLegalMovesForPiece(r, c)
      soundManager.playButtonClick()
    } else {
      selectedSquare = null
      legalMovesForSelected = emptyList()
    }
  }

  // AI execution
  LaunchedEffect(currentTurn, isAiMode, isGameOver) {
    if (isAiMode && currentTurn == CheckersPieceColor.WHITE && !isGameOver) {
      delay(600)
      val allAiMoves = mutableListOf<CheckersMove>()
      val mandatoryJumps = getAllJumps(CheckersPieceColor.WHITE)
      if (mandatoryJumps.isNotEmpty()) {
        allAiMoves.addAll(mandatoryJumps)
      } else {
        for (r in 0..7) {
          for (c in 0..7) {
            if (board[r][c]?.color == CheckersPieceColor.WHITE) {
              allAiMoves.addAll(getSimpleMovesForPiece(r, c))
            }
          }
        }
      }
      if (allAiMoves.isNotEmpty()) {
        executeMove(allAiMoves.random())
      }
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F0C20))
  ) {
    GameTopBar(
      title = "Checkers",
      isPaused = isPaused,
      isMuted = isMuted,
      onBack = onBack,
      onPauseToggle = { isPaused = !isPaused },
      onRestart = { setupBoard() },
      onMuteToggle = {
        isMuted = !isMuted
        soundManager.isSoundEnabled = !isMuted
      }
    )

    // Mode Selector & Turn
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row {
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isAiMode) Color(0xFF6C5CE7) else Color(0xFF1E1B38))
            .clickable { isAiMode = true; setupBoard() }
            .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Text("vs AI", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.width(6.dp))
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (!isAiMode) Color(0xFF6C5CE7) else Color(0xFF1E1B38))
            .clickable { isAiMode = false; setupBoard() }
            .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Text("2 Players", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
      }

      Text(
        text = "${currentTurn.name}'S TURN",
        fontWeight = FontWeight.Bold,
        color = if (currentTurn == CheckersPieceColor.RED) Color(0xFFFF5252) else Color(0xFF00CEC9),
        fontSize = 12.sp
      )
    }

    // 8x8 Board
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .padding(12.dp),
      contentAlignment = Alignment.Center
    ) {
      BoxWithConstraints(
        modifier = Modifier
          .aspectRatio(1f)
          .clip(RoundedCornerShape(12.dp))
          .background(Color(0xFF18152E))
          .border(2.dp, Color(0xFF6C5CE7), RoundedCornerShape(12.dp))
          .padding(4.dp)
      ) {
        Column(modifier = Modifier.fillMaxSize()) {
          for (r in 0..7) {
            Row(modifier = Modifier.weight(1f)) {
              for (c in 0..7) {
                val isDarkSquare = (r + c) % 2 == 1
                val isSelected = selectedSquare == Pair(r, c)
                val isLegalDest = legalMovesForSelected.any { it.toR == r && it.toC == c }
                val piece = board[r][c]

                Box(
                  modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .background(
                      when {
                        isSelected -> Color(0xFF6C5CE7).copy(alpha = 0.6f)
                        isLegalDest -> Color(0xFF00CEC9).copy(alpha = 0.4f)
                        isDarkSquare -> Color(0xFF2E294E)
                        else -> Color(0xFFEDE0C8)
                      }
                    )
                    .clickable { onSquareClick(r, c) }
                    .testTag("checkers_sq_${r}_${c}"),
                  contentAlignment = Alignment.Center
                ) {
                  if (piece != null) {
                    Box(
                      modifier = Modifier
                        .fillMaxSize(0.8f)
                        .clip(CircleShape)
                        .background(if (piece.color == CheckersPieceColor.RED) Color(0xFFFF5252) else Color.White)
                        .border(2.dp, Color.Black.copy(alpha = 0.4f), CircleShape),
                      contentAlignment = Alignment.Center
                    ) {
                      if (piece.isKing) {
                        Text("👑", fontSize = 16.sp)
                      }
                    }
                  } else if (isLegalDest) {
                    Box(
                      modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF2ED573))
                    )
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  if (isPaused) {
    GamePauseDialog(
      onResume = { isPaused = false },
      onRestart = { setupBoard() },
      onExit = onBack
    )
  }

  if (isGameOver) {
    val isWin = winner == CheckersPieceColor.RED
    val score = if (isWin) 1000 else 200
    GameOverDialog(
      gameTitle = "Checkers",
      resultType = if (isWin) GameResultType.WIN else GameResultType.LOSS,
      score = score,
      highScore = 1000,
      onPlayAgain = { setupBoard() },
      onExit = onBack
    )
  }
}
