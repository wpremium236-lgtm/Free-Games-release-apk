package com.example.games.common

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.core.model.GameResultType
import com.example.core.storage.GamePreferences

@Composable
fun GameTopBar(
  title: String,
  score: Int? = null,
  highScore: Int? = null,
  lives: Int? = null,
  timeRemainingSec: Int? = null,
  isPaused: Boolean = false,
  isMuted: Boolean = false,
  onBack: () -> Unit,
  onPauseToggle: () -> Unit,
  onRestart: () -> Unit,
  onMuteToggle: () -> Unit,
  modifier: Modifier = Modifier
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .background(Color(0xFF141128))
      .padding(horizontal = 8.dp, vertical = 6.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      IconButton(
        onClick = onBack,
        modifier = Modifier.testTag("game_back_btn")
      ) {
        Icon(
          Icons.AutoMirrored.Filled.ArrowBack,
          contentDescription = "Exit to Menu",
          tint = Color.White
        )
      }
      Spacer(modifier = Modifier.width(4.dp))
      Text(
        text = title,
        fontWeight = FontWeight.Bold,
        fontSize = 16.sp,
        color = Color.White
      )
    }

    // Stats
    Row(verticalAlignment = Alignment.CenterVertically) {
      if (score != null) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(horizontal = 6.dp)) {
          Text("SCORE", fontSize = 9.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFA4B0BE))
          Text("$score", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFB142))
        }
      }
      if (lives != null) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(horizontal = 6.dp)) {
          Text("LIVES", fontSize = 9.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFA4B0BE))
          Text("❤️ $lives", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFF5252))
        }
      }
      if (timeRemainingSec != null) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(horizontal = 6.dp)) {
          Text("TIME", fontSize = 9.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFA4B0BE))
          Text("${timeRemainingSec}s", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00CEC9))
        }
      }
    }

    // Controls
    Row(verticalAlignment = Alignment.CenterVertically) {
      IconButton(onClick = onMuteToggle, modifier = Modifier.size(36.dp)) {
        Icon(
          if (isMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
          contentDescription = "Mute Sound",
          tint = if (isMuted) Color(0xFFFF5252) else Color.White,
          modifier = Modifier.size(20.dp)
        )
      }
      IconButton(onClick = onPauseToggle, modifier = Modifier.size(36.dp).testTag("game_pause_btn")) {
        Icon(
          if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
          contentDescription = "Pause Game",
          tint = Color.White,
          modifier = Modifier.size(20.dp)
        )
      }
      IconButton(onClick = onRestart, modifier = Modifier.size(36.dp).testTag("game_restart_btn")) {
        Icon(
          Icons.Default.Refresh,
          contentDescription = "Restart Game",
          tint = Color.White,
          modifier = Modifier.size(20.dp)
        )
      }
    }
  }
}

@Composable
fun GamePauseDialog(
  onResume: () -> Unit,
  onRestart: () -> Unit,
  onExit: () -> Unit
) {
  Dialog(onDismissRequest = onResume) {
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF18152E)),
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      Column(
        modifier = Modifier.padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Text("GAME PAUSED", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(modifier = Modifier.height(20.dp))
        Button(
          onClick = onResume,
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6C5CE7)),
          modifier = Modifier.fillMaxWidth().testTag("pause_resume_btn")
        ) {
          Text("Resume Game")
        }
        Spacer(modifier = Modifier.height(10.dp))
        Button(
          onClick = onRestart,
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF241F42)),
          modifier = Modifier.fillMaxWidth().testTag("pause_restart_btn")
        ) {
          Text("Restart Level", color = Color.White)
        }
        Spacer(modifier = Modifier.height(10.dp))
        Button(
          onClick = onExit,
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE84118)),
          modifier = Modifier.fillMaxWidth().testTag("pause_exit_btn")
        ) {
          Text("Quit to Hub", color = Color.White)
        }
      }
    }
  }
}

@Composable
fun GameOverDialog(
  gameTitle: String = "Game",
  resultType: GameResultType = GameResultType.GAME_OVER,
  score: Int,
  highScore: Int,
  durationSec: Long = 0L,
  onPlayAgain: () -> Unit,
  onExit: () -> Unit,
  onSaveResult: ((playerName: String) -> Unit)? = null
) {
  val context = LocalContext.current
  val prefs = remember { GamePreferences(context) }
  val isNameConfigured = remember { prefs.isPlayerNameConfigured() }
  var enteredName by remember { mutableStateOf(if (isNameConfigured) prefs.getUserProfile().name else "") }
  var isSaved by remember { mutableStateOf(isNameConfigured) }
  var validationError by remember { mutableStateOf<String?>(null) }

  val isNewHigh = score > highScore && score > 0
  val resultTitle = when (resultType) {
    GameResultType.WIN -> "🎉 VICTORY! 🎉"
    GameResultType.LOSS -> "💀 DEFEAT"
    GameResultType.DRAW -> "🤝 DRAW"
    GameResultType.GAME_OVER -> "💥 GAME OVER"
    GameResultType.COMPLETED -> "🏆 COMPLETED"
  }
  val resultColor = when (resultType) {
    GameResultType.WIN -> Color(0xFF2ED573)
    GameResultType.LOSS -> Color(0xFFFF5252)
    GameResultType.DRAW -> Color(0xFFFFB142)
    GameResultType.GAME_OVER -> Color(0xFFFF4757)
    GameResultType.COMPLETED -> Color(0xFF00CEC9)
  }

  Dialog(onDismissRequest = {}) {
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF18152E)),
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      Column(
        modifier = Modifier.padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Text(
          text = resultTitle,
          fontSize = 20.sp,
          fontWeight = FontWeight.Bold,
          color = resultColor
        )
        Spacer(modifier = Modifier.height(10.dp))
        if (isNewHigh) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .background(Color(0xFFFFB142))
              .padding(horizontal = 12.dp, vertical = 4.dp)
          ) {
            Text("★ NEW HIGH SCORE! ★", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
          }
          Spacer(modifier = Modifier.height(10.dp))
        }
        Text("Game: $gameTitle", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color(0xFFA4B0BE))
        Spacer(modifier = Modifier.height(2.dp))
        Text("Score: $score", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(modifier = Modifier.height(2.dp))
        Text("Result: ${resultType.name}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = resultColor)
        if (durationSec > 0) {
          Spacer(modifier = Modifier.height(2.dp))
          Text("Duration: ${durationSec}s", fontSize = 12.sp, color = Color(0xFFA4B0BE))
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Real Player Name section
        if (!isSaved) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(12.dp))
              .background(Color(0xFF241F42))
              .padding(12.dp)
          ) {
            Text(
              text = "Enter your name to save score:",
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold,
              color = Color.White
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
              value = enteredName,
              onValueChange = {
                enteredName = it.take(20)
                validationError = null
              },
              singleLine = true,
              placeholder = { Text("Your player name", color = Color(0xFF747D8C), fontSize = 12.sp) },
              modifier = Modifier.fillMaxWidth(),
              colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedBorderColor = Color(0xFF6C5CE7),
                unfocusedBorderColor = Color(0xFF4834D4)
              )
            )
            validationError?.let { err ->
              Spacer(modifier = Modifier.height(4.dp))
              Text(err, color = Color(0xFFFF5252), fontSize = 11.sp)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Button(
              onClick = {
                val trimmed = enteredName.trim()
                when {
                  trimmed.isBlank() -> validationError = "Name cannot be empty."
                  trimmed.length < 2 -> validationError = "Name must be at least 2 characters."
                  trimmed.length > 20 -> validationError = "Name must be 20 characters or less."
                  !trimmed.matches(Regex("^[a-zA-Z0-9_ -]+$")) -> validationError = "Only letters, numbers, and spaces allowed."
                  else -> {
                    validationError = null
                    prefs.saveUserProfile(prefs.getUserProfile().copy(name = trimmed))
                    onSaveResult?.invoke(trimmed)
                    isSaved = true
                  }
                }
              },
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00CEC9)),
              modifier = Modifier.fillMaxWidth().testTag("save_result_btn")
            ) {
              Text("SAVE RESULT", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
          }
          Spacer(modifier = Modifier.height(14.dp))
        } else {
          val displayName = enteredName.ifBlank { prefs.getUserProfile().name }
          if (displayName.isNotBlank()) {
            Text("Player: $displayName", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF00CEC9))
            Text("✓ Result recorded", fontSize = 11.sp, color = Color(0xFF2ED573))
            Spacer(modifier = Modifier.height(10.dp))
          }
        }

        Button(
          onClick = onPlayAgain,
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6C5CE7)),
          modifier = Modifier.fillMaxWidth().testTag("game_over_play_again_btn")
        ) {
          Text("PLAY AGAIN")
        }
        Spacer(modifier = Modifier.height(8.dp))
        Button(
          onClick = onExit,
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF241F42)),
          modifier = Modifier.fillMaxWidth().testTag("game_over_exit_btn")
        ) {
          Text("HOME", color = Color.White)
        }
      }
    }
  }
}

@Composable
fun GameOverDialog(
  isWin: Boolean,
  score: Int,
  highScore: Int,
  onPlayAgain: () -> Unit,
  onExit: () -> Unit
) {
  GameOverDialog(
    gameTitle = "Game",
    resultType = if (isWin) GameResultType.WIN else GameResultType.GAME_OVER,
    score = score,
    highScore = highScore,
    onPlayAgain = onPlayAgain,
    onExit = onExit
  )
}
