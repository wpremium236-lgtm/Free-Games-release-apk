package com.example

import android.app.Activity
import android.os.Bundle
import java.io.File
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.example.core.ads.AdManager
import com.example.core.data.GameResultRepository
import com.example.core.model.GameItem
import com.example.core.model.GameResult
import com.example.core.model.GameResultType
import com.example.core.storage.GamePreferences
import kotlinx.coroutines.launch

import com.example.games.archery.ArcheryGame
import com.example.games.blockpuzzle.BlockPuzzleGame
import com.example.games.brickbreaker.BrickBreakerGame
import com.example.games.bubbleshooter.BubbleShooterGame
import com.example.games.carracing.CarRacingGame
import com.example.games.checkers.CheckersGame
import com.example.games.chess.ChessGame
import com.example.games.colormatch.ColorMatchGame
import com.example.games.connectfour.ConnectFourGame
import com.example.games.fruitslicer.FruitSlicerGame
import com.example.games.game2048.Game2048
import com.example.games.knifehit.KnifeHitGame
import com.example.games.ludo.LudoGame
import com.example.games.memorymatch.MemoryMatchGame
import com.example.games.minesweeper.MinesweeperGame
import com.example.games.numberguessing.NumberGuessingGame
import com.example.games.snake.SnakeGame
import com.example.games.solitaire.SolitaireGame
import com.example.games.spaceshooter.SpaceShooterGame
import com.example.games.sudoku.SudokuGame
import com.example.games.tapflying.TapFlyingGame
import com.example.games.tictactoe.TicTacToeGame
import com.example.games.whackamole.WhackAMoleGame
import com.example.games.wordpuzzle.WordPuzzleGame
import com.example.ui.AchievementsScreen
import com.example.ui.GameDetailSheet
import com.example.ui.HomeScreen
import com.example.ui.HubTab
import com.example.ui.LeaderboardScreen
import com.example.ui.ProfileAndSettingsScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    try {
      val cDir = cacheDir
      File(cDir, "WebView/Default/HTTP Cache/Code Cache/js").mkdirs()
      File(cDir, "WebView/Default/HTTP Cache/Code Cache/wasm").mkdirs()
    } catch (_: Exception) {}

    setContent {
      MyApplicationTheme {
        MainAppRoot()
      }
    }
  }
}

@Composable
fun MainAppRoot() {
  val context = LocalContext.current
  val prefs = remember { GamePreferences(context) }
  val adManager = remember { AdManager.getInstance(context) }
  var currentTab by remember { mutableStateOf(HubTab.GAMES) }
  var activeGame by remember { mutableStateOf<GameItem?>(null) }
  var detailGame by remember { mutableStateOf<GameItem?>(null) }
  val gameRepository = remember { GameResultRepository.getInstance(context) }
  val scope = rememberCoroutineScope()
  var gameStartTimeMs by remember { mutableStateOf(System.currentTimeMillis()) }

  fun handleGameFinished(
    gameId: String,
    score: Int,
    resultType: GameResultType? = null,
    duration: Long? = null,
    sessionId: String? = null
  ) {
    val durationSec = duration ?: ((System.currentTimeMillis() - gameStartTimeMs) / 1000L).coerceAtLeast(1L)
    val userProfile = prefs.getUserProfile()
    val isWin = score > 0
    val finalResultType = resultType ?: if (isWin) GameResultType.WIN else GameResultType.GAME_OVER
    val result = GameResult(
      gameId = gameId,
      playerId = userProfile.name.lowercase().replace(" ", "_"),
      playerName = userProfile.name,
      score = score,
      resultType = finalResultType,
      duration = durationSec,
      completedAt = System.currentTimeMillis(),
      sessionId = if (!sessionId.isNullOrBlank()) sessionId else gameRepository.generateSessionId()
    )
    scope.launch {
      gameRepository.submitGameResult(result)
      adManager.recordGameCompleted()
      val activity = context as? Activity
      if (adManager.canShowInterstitial()) {
        adManager.showInterstitialIfReady(activity) {}
      }
    }
  }

  var showLeaveGameDialog by remember { mutableStateOf(false) }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F0C20))
      .safeDrawingPadding()
  ) {
    val currentGame = activeGame
    if (currentGame != null) {
      BackHandler {
        showLeaveGameDialog = true
      }

      if (showLeaveGameDialog) {
        androidx.compose.material3.AlertDialog(
          onDismissRequest = { showLeaveGameDialog = false },
          title = {
            androidx.compose.material3.Text(
              "Leave Game?",
              fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
              color = Color.White
            )
          },
          text = {
            androidx.compose.material3.Text(
              "Are you sure you want to exit to the game menu? Your current in-game progress will be lost.",
              color = Color(0xFFA4B0BE)
            )
          },
          confirmButton = {
            androidx.compose.material3.Button(
              onClick = {
                showLeaveGameDialog = false
                activeGame = null
              },
              colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Color(0xFFE84118))
            ) {
              androidx.compose.material3.Text("Leave Game")
            }
          },
          dismissButton = {
            androidx.compose.material3.OutlinedButton(
              onClick = { showLeaveGameDialog = false }
            ) {
              androidx.compose.material3.Text("Continue Playing", color = Color.White)
            }
          },
          containerColor = Color(0xFF1E1A38)
        )
      }

      when (currentGame.id) {
        "ludo" -> LudoGame(
          onBack = { showLeaveGameDialog = true },
          onGameFinished = { gId, score, resType, dur, sessId ->
            handleGameFinished(gId, score, resType, dur, sessId)
          }
        )
        "snake" -> SnakeGame(
          onBack = { showLeaveGameDialog = true },
          onGameFinished = { gId, score, resType, dur, sessId ->
            handleGameFinished(gId, score, resType, dur, sessId)
          }
        )
        "tictactoe" -> TicTacToeGame(
          onBack = { showLeaveGameDialog = true },
          onGameFinished = { gId, score, resType, dur, sessId ->
            handleGameFinished(gId, score, resType, dur, sessId)
          }
        )
        "carracing" -> CarRacingGame(
          onBack = { showLeaveGameDialog = true },
          onGameFinished = { gId, score, resType, dur, sessId ->
            handleGameFinished(gId, score, resType, dur, sessId)
          }
        )
        "tapflying" -> TapFlyingGame(
          onBack = { showLeaveGameDialog = true },
          onGameFinished = { gId, score, resType, dur, sessId ->
            handleGameFinished(gId, score, resType, dur, sessId)
          }
        )
        "2048", "game2048" -> Game2048(
          onBack = { showLeaveGameDialog = true },
          onGameFinished = { gId, score, resType, dur, sessId ->
            handleGameFinished(gId, score, resType, dur, sessId)
          }
        )
        "sudoku" -> SudokuGame(
          onBack = { showLeaveGameDialog = true },
          onGameFinished = { gId, score, resType, dur, sessId ->
            handleGameFinished(gId, score, resType, dur, sessId)
          }
        )
        "minesweeper" -> MinesweeperGame(
          onBack = { showLeaveGameDialog = true },
          onGameFinished = { gId, score, resType, dur, sessId ->
            handleGameFinished(gId, score, resType, dur, sessId)
          }
        )
        "memorymatch" -> MemoryMatchGame(
          onBack = { showLeaveGameDialog = true },
          onGameFinished = { gId, score, resType, dur, sessId ->
            handleGameFinished(gId, score, resType, dur, sessId)
          }
        )
        "chess" -> ChessGame(
          onBack = { showLeaveGameDialog = true },
          onGameFinished = { gId, score, resType, dur, sessId ->
            handleGameFinished(gId, score, resType, dur, sessId)
          }
        )
        "checkers" -> CheckersGame(
          onBack = { showLeaveGameDialog = true },
          onGameFinished = { gId, score, resType, dur, sessId ->
            handleGameFinished(gId, score, resType, dur, sessId)
          }
        )
        "solitaire" -> SolitaireGame(
          onBack = { showLeaveGameDialog = true },
          onGameFinished = { score -> handleGameFinished(currentGame.id, score) }
        )
        "bubbleshooter" -> BubbleShooterGame(
          onBack = { showLeaveGameDialog = true },
          onGameFinished = { score -> handleGameFinished(currentGame.id, score) }
        )
        "archery", "targethit" -> ArcheryGame(
          onBack = { showLeaveGameDialog = true },
          onGameFinished = { score -> handleGameFinished(currentGame.id, score) }
        )
        "brickbreaker" -> BrickBreakerGame(
          onBack = { showLeaveGameDialog = true },
          onGameFinished = { score -> handleGameFinished(currentGame.id, score) }
        )
        "spaceshooter" -> SpaceShooterGame(
          onBack = { showLeaveGameDialog = true },
          onGameFinished = { gId, score, resType, dur, sessId ->
            handleGameFinished(gId, score, resType, dur, sessId)
          }
        )
        "numberguessing" -> NumberGuessingGame(
          onBack = { showLeaveGameDialog = true },
          onGameFinished = { gId, score, resType, dur, sessId ->
            handleGameFinished(gId, score, resType, dur, sessId)
          }
        )
        "wordpuzzle" -> WordPuzzleGame(
          onBack = { showLeaveGameDialog = true },
          onGameFinished = { gId, score, resType, dur, sessId ->
            handleGameFinished(gId, score, resType, dur, sessId)
          }
        )
        "connectfour" -> ConnectFourGame(
          onBack = { showLeaveGameDialog = true },
          onGameFinished = { gId, score, resType, dur, sessId ->
            handleGameFinished(gId, score, resType, dur, sessId)
          }
        )
        "knifehit" -> KnifeHitGame(
          onBack = { showLeaveGameDialog = true },
          onGameFinished = { score -> handleGameFinished(currentGame.id, score) }
        )
        "fruitslicer" -> FruitSlicerGame(
          onBack = { showLeaveGameDialog = true },
          onGameFinished = { score -> handleGameFinished(currentGame.id, score) }
        )
        "blockpuzzle" -> BlockPuzzleGame(
          onBack = { showLeaveGameDialog = true },
          onGameFinished = { score -> handleGameFinished(currentGame.id, score) }
        )
        "colormatch" -> ColorMatchGame(
          onBack = { showLeaveGameDialog = true },
          onGameFinished = { score -> handleGameFinished(currentGame.id, score) }
        )
        "whackamole" -> WhackAMoleGame(
          onBack = { showLeaveGameDialog = true },
          onGameFinished = { score -> handleGameFinished(currentGame.id, score) }
        )
      }
    } else {
      when (currentTab) {
        HubTab.GAMES -> HomeScreen(
          onSelectGame = { game -> detailGame = game },
          currentTab = currentTab,
          onTabChange = { currentTab = it }
        )
        HubTab.LEADERBOARDS -> LeaderboardScreen(
          onBack = { currentTab = HubTab.GAMES }
        )
        HubTab.ACHIEVEMENTS -> AchievementsScreen(
          onBack = { currentTab = HubTab.GAMES }
        )
        HubTab.PROFILE -> ProfileAndSettingsScreen(
          onBack = { currentTab = HubTab.GAMES }
        )
      }

      if (currentTab != HubTab.GAMES) {
        BackHandler {
          currentTab = HubTab.GAMES
        }
      }

      detailGame?.let { game ->
        GameDetailSheet(
          game = game,
          highScore = prefs.getHighScore(game.id),
          onStartPlay = {
            gameStartTimeMs = System.currentTimeMillis()
            activeGame = game
            detailGame = null
          },
          onDismiss = { detailGame = null }
        )
      }
    }
  }
}
