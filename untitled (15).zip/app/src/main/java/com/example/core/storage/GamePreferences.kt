package com.example.core.storage

import android.content.Context
import android.content.SharedPreferences
import com.example.core.model.AdminAdSettings
import com.example.core.model.AppLanguage
import com.example.core.model.AppThemeMode
import com.example.core.model.GameDifficulty
import com.example.core.model.LeaderboardRecord
import com.example.core.model.UserProfile
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class GamePreferences(context: Context) {
  private val prefs: SharedPreferences = context.getSharedPreferences("game_hub_prefs", Context.MODE_PRIVATE)

  // Settings
  fun isSoundEnabled(): Boolean = prefs.getBoolean("pref_sound", true)
  fun setSoundEnabled(enabled: Boolean) = prefs.edit().putBoolean("pref_sound", enabled).apply()

  fun isMusicEnabled(): Boolean = prefs.getBoolean("pref_music", true)
  fun setMusicEnabled(enabled: Boolean) = prefs.edit().putBoolean("pref_music", enabled).apply()

  fun isVibrationEnabled(): Boolean = prefs.getBoolean("pref_vibration", true)
  fun setVibrationEnabled(enabled: Boolean) = prefs.edit().putBoolean("pref_vibration", enabled).apply()

  fun getThemeMode(): AppThemeMode {
    val name = prefs.getString("pref_theme_mode", AppThemeMode.DARK.name) ?: AppThemeMode.DARK.name
    return runCatching { AppThemeMode.valueOf(name) }.getOrDefault(AppThemeMode.DARK)
  }
  fun setThemeMode(mode: AppThemeMode) = prefs.edit().putString("pref_theme_mode", mode.name).apply()

  fun getLanguage(): AppLanguage {
    val name = prefs.getString("pref_language", AppLanguage.ENGLISH.name) ?: AppLanguage.ENGLISH.name
    return runCatching { AppLanguage.valueOf(name) }.getOrDefault(AppLanguage.ENGLISH)
  }
  fun setLanguage(lang: AppLanguage) = prefs.edit().putString("pref_language", lang.name).apply()

  fun getDefaultDifficulty(): GameDifficulty {
    val name = prefs.getString("pref_default_difficulty", GameDifficulty.MEDIUM.name) ?: GameDifficulty.MEDIUM.name
    return runCatching { GameDifficulty.valueOf(name) }.getOrDefault(GameDifficulty.MEDIUM)
  }
  fun setDefaultDifficulty(diff: GameDifficulty) = prefs.edit().putString("pref_default_difficulty", diff.name).apply()

  // Game High Scores
  fun getHighScore(gameId: String): Int = prefs.getInt("high_score_$gameId", 0)
  fun setHighScore(gameId: String, score: Int) {
    val current = getHighScore(gameId)
    if (score > current) {
      prefs.edit().putInt("high_score_$gameId", score).apply()
    }
  }

  // Favorites
  fun getFavorites(): Set<String> = prefs.getStringSet("favorite_games", emptySet()) ?: emptySet()
  fun toggleFavorite(gameId: String) {
    val current = getFavorites().toMutableSet()
    if (current.contains(gameId)) current.remove(gameId) else current.add(gameId)
    prefs.edit().putStringSet("favorite_games", current).apply()
  }

  // Recently Played
  fun getRecentlyPlayed(): List<String> {
    val raw = prefs.getString("recently_played", "") ?: ""
    if (raw.isEmpty()) return emptyList()
    return raw.split(",").filter { it.isNotBlank() }
  }

  fun recordGamePlayed(gameId: String, isWin: Boolean = false, scoreEarned: Int = 0) {
    val list = getRecentlyPlayed().toMutableList()
    list.remove(gameId)
    list.add(0, gameId)
    if (list.size > 8) list.subList(8, list.size).clear()
    prefs.edit().putString("recently_played", list.joinToString(",")).apply()

    // Increment overall stats
    val profile = getUserProfile()
    val updatedTotalGames = profile.totalGames + 1
    val updatedWins = if (isWin) profile.totalWins + 1 else profile.totalWins
    val updatedScore = profile.totalScore + scoreEarned
    saveUserProfile(profile.copy(
      totalGames = updatedTotalGames,
      totalWins = updatedWins,
      totalScore = updatedScore
    ))
  }

  // Stable Unique Player ID
  fun getPlayerId(): String {
    var id = prefs.getString("stable_player_id", null)
    if (id.isNullOrBlank()) {
      id = "usr_" + java.util.UUID.randomUUID().toString().replace("-", "").take(12)
      prefs.edit().putString("stable_player_id", id).apply()
    }
    return id
  }

  fun isPlayerNameConfigured(): Boolean {
    val name = prefs.getString("profile_name", "") ?: ""
    return name.isNotBlank() && name != "Player 1"
  }

  // User Profile
  fun getUserProfile(): UserProfile {
    val savedName = prefs.getString("profile_name", "") ?: ""
    return UserProfile(
      name = if (savedName == "Player 1") "" else savedName,
      avatarIndex = prefs.getInt("profile_avatar", 0),
      totalGames = prefs.getInt("profile_total_games", 0),
      totalWins = prefs.getInt("profile_total_wins", 0),
      totalScore = prefs.getLong("profile_total_score", 0L),
      favoriteGameId = prefs.getString("profile_fav_game", "ludo") ?: "ludo",
      isCloudSynced = prefs.getBoolean("profile_cloud_synced", false),
      accountEmail = prefs.getString("profile_email", null)
    )
  }

  fun saveUserProfile(profile: UserProfile) {
    val cleanName = if (profile.name == "Player 1") "" else profile.name.trim()
    prefs.edit()
      .putString("profile_name", cleanName)
      .putInt("profile_avatar", profile.avatarIndex)
      .putInt("profile_total_games", profile.totalGames)
      .putInt("profile_total_wins", profile.totalWins)
      .putLong("profile_total_score", profile.totalScore)
      .putString("profile_fav_game", profile.favoriteGameId)
      .putBoolean("profile_cloud_synced", profile.isCloudSynced)
      .putString("profile_email", profile.accountEmail)
      .apply()
  }

  // Leaderboard
  fun getLeaderboard(gameId: String): List<LeaderboardRecord> {
    val raw = prefs.getString("leaderboard_$gameId", "[]") ?: "[]"
    return try {
      val array = JSONArray(raw)
      val list = mutableListOf<LeaderboardRecord>()
      for (i in 0 until array.length()) {
        val obj = array.getJSONObject(i)
        list.add(
          LeaderboardRecord(
            id = obj.getString("id"),
            gameId = obj.getString("gameId"),
            playerName = obj.getString("playerName"),
            score = obj.getInt("score"),
            date = obj.getString("date")
          )
        )
      }
      list.sortedByDescending { it.score }
    } catch (_: Exception) {
      emptyList()
    }
  }

  fun addLeaderboardEntry(gameId: String, playerName: String, score: Int) {
    val current = getLeaderboard(gameId).toMutableList()
    val dateStr = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date())
    current.add(
      LeaderboardRecord(
        id = "${System.currentTimeMillis()}",
        gameId = gameId,
        playerName = playerName,
        score = score,
        date = dateStr
      )
    )
    val sorted = current.sortedByDescending { it.score }.take(10)
    val array = JSONArray()
    for (item in sorted) {
      val obj = JSONObject().apply {
        put("id", item.id)
        put("gameId", item.gameId)
        put("playerName", item.playerName)
        put("score", item.score)
        put("date", item.date)
      }
      array.put(obj)
    }
    prefs.edit().putString("leaderboard_$gameId", array.toString()).apply()
  }

  // Admin Ad Settings
  fun getAdminAdSettings(): AdminAdSettings {
    return AdminAdSettings(
      adsGloballyEnabled = prefs.getBoolean("admin_ads_enabled", true),
      bannerEnabled = prefs.getBoolean("admin_banner_enabled", true),
      interstitialEnabled = prefs.getBoolean("admin_interstitial_enabled", true),
      rewardedEnabled = prefs.getBoolean("admin_rewarded_enabled", true),
      interstitialIntervalSeconds = prefs.getInt("admin_interstitial_interval", 60),
      interstitialFrequencyGames = prefs.getInt("admin_interstitial_freq", 2)
    )
  }

  fun saveAdminAdSettings(settings: AdminAdSettings) {
    prefs.edit()
      .putBoolean("admin_ads_enabled", settings.adsGloballyEnabled)
      .putBoolean("admin_banner_enabled", settings.bannerEnabled)
      .putBoolean("admin_interstitial_enabled", settings.interstitialEnabled)
      .putBoolean("admin_rewarded_enabled", settings.rewardedEnabled)
      .putInt("admin_interstitial_interval", settings.interstitialIntervalSeconds)
      .putInt("admin_interstitial_freq", settings.interstitialFrequencyGames)
      .apply()
  }
}
