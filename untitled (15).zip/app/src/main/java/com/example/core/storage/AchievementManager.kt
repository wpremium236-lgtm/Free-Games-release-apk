package com.example.core.storage

import android.content.Context
import com.example.core.model.Achievement

class AchievementManager(context: Context) {
  private val prefs = GamePreferences(context)

  fun getAchievements(): List<Achievement> {
    val profile = prefs.getUserProfile()
    val gamesPlayed = profile.totalGames
    val wins = profile.totalWins
    val totalScore = profile.totalScore

    return listOf(
      Achievement(
        id = "first_game",
        titleEn = "First Step",
        titleBn = "প্রথম পদক্ষেপ",
        descEn = "Play your first game in the hub",
        descBn = "যেকোনো একটি গেম খেলুন",
        iconEmoji = "🎮",
        currentProgress = gamesPlayed.coerceAtMost(1),
        maxProgress = 1,
        isUnlocked = gamesPlayed >= 1
      ),
      Achievement(
        id = "first_win",
        titleEn = "First Victory",
        titleBn = "প্রথম বিজয়",
        descEn = "Win any game match or level",
        descBn = "যেকোনো গেমে ম্যাচ জিতুন",
        iconEmoji = "🏆",
        currentProgress = wins.coerceAtMost(1),
        maxProgress = 1,
        isUnlocked = wins >= 1
      ),
      Achievement(
        id = "10_games",
        titleEn = "Casual Gamer",
        titleBn = "ক্যাজুয়াল গেমার",
        descEn = "Play 10 games",
        descBn = "মোট ১০টি ম্যাচ খেলুন",
        iconEmoji = "🎯",
        currentProgress = gamesPlayed.coerceAtMost(10),
        maxProgress = 10,
        isUnlocked = gamesPlayed >= 10
      ),
      Achievement(
        id = "50_games",
        titleEn = "Gaming Enthusiast",
        titleBn = "গেমিং অনুরাগী",
        descEn = "Play 50 games",
        descBn = "মোট ৫০টি ম্যাচ খেলুন",
        iconEmoji = "🔥",
        currentProgress = gamesPlayed.coerceAtMost(50),
        maxProgress = 50,
        isUnlocked = gamesPlayed >= 50
      ),
      Achievement(
        id = "100_games",
        titleEn = "Centurion Gamer",
        titleBn = "শততম গেমার",
        descEn = "Play 100 games across the hub",
        descBn = "মোট ১০০টি ম্যাচ সম্পূর্ণ করুন",
        iconEmoji = "👑",
        currentProgress = gamesPlayed.coerceAtMost(100),
        maxProgress = 100,
        isUnlocked = gamesPlayed >= 100
      ),
      Achievement(
        id = "high_score",
        titleEn = "High Scorer",
        titleBn = "হাই স্কোরার",
        descEn = "Earn 5,000 total score points",
        descBn = "মোট ৫,০০০ পয়েন্ট অর্জন করুন",
        iconEmoji = "⭐",
        currentProgress = totalScore.toInt().coerceAtMost(5000),
        maxProgress = 5000,
        isUnlocked = totalScore >= 5000
      ),
      Achievement(
        id = "puzzle_master",
        titleEn = "Puzzle Master",
        titleBn = "ধাঁধার মাস্টার",
        descEn = "Score points in 2048, Sudoku, or Word Puzzle",
        descBn = "২০৪৮, সুডোকু বা শব্দ ধাঁধায় পয়েন্ট পান",
        iconEmoji = "🧩",
        currentProgress = if (prefs.getHighScore("game2048") > 0 || prefs.getHighScore("sudoku") > 0) 1 else 0,
        maxProgress = 1,
        isUnlocked = prefs.getHighScore("game2048") > 0 || prefs.getHighScore("sudoku") > 0
      ),
      Achievement(
        id = "ludo_champ",
        titleEn = "Ludo Champion",
        titleBn = "লুডো চ্যাম্পিয়ন",
        descEn = "Win a full match of Ludo",
        descBn = "লুডোতে একটি পূর্ণ ম্যাচ জিতুন",
        iconEmoji = "🎲",
        currentProgress = if (prefs.getHighScore("ludo") > 0) 1 else 0,
        maxProgress = 1,
        isUnlocked = prefs.getHighScore("ludo") > 0
      ),
      Achievement(
        id = "arcade_master",
        titleEn = "Arcade Master",
        titleBn = "আর্কেড মাস্টার",
        descEn = "Achieve high score in Snake or Brick Breaker",
        descBn = "স্নেক বা ব্রিক ব্রেকারে উচ্চ স্কোর গড়ুন",
        iconEmoji = "🕹️",
        currentProgress = if (prefs.getHighScore("snake") >= 50 || prefs.getHighScore("brickbreaker") >= 200) 1 else 0,
        maxProgress = 1,
        isUnlocked = prefs.getHighScore("snake") >= 50 || prefs.getHighScore("brickbreaker") >= 200
      ),
      Achievement(
        id = "board_master",
        titleEn = "Grandmaster",
        titleBn = "গ্র্যান্ডমাস্টার",
        descEn = "Play Chess or Checkers matches",
        descBn = "দাবা বা চেকার্স ম্যাচ খেলুন",
        iconEmoji = "♟️",
        currentProgress = if (prefs.getHighScore("chess") > 0 || prefs.getHighScore("checkers") > 0) 1 else 0,
        maxProgress = 1,
        isUnlocked = prefs.getHighScore("chess") > 0 || prefs.getHighScore("checkers") > 0
      )
    )
  }
}
