package com.example.core.model

import androidx.compose.ui.graphics.Color

enum class GameCategory(val displayNameEn: String, val displayNameBn: String) {
  ALL("All", "সব"),
  BOARD("Board", "বোর্ড"),
  ARCADE("Arcade", "আর্কেড"),
  PUZZLE("Puzzle", "পাজল"),
  RACING("Racing", "রেসিং"),
  STRATEGY("Strategy", "কৌশল"),
  CASUAL("Casual", "ক্যাজুয়াল")
}

enum class GameDifficulty(val labelEn: String, val labelBn: String) {
  EASY("Easy", "সহজ"),
  MEDIUM("Medium", "মাঝারি"),
  HARD("Hard", "কঠিন")
}

data class GameItem(
  val id: String,
  val nameEn: String,
  val nameBn: String,
  val category: GameCategory,
  val descriptionEn: String,
  val descriptionBn: String,
  val howToPlayEn: String,
  val howToPlayBn: String,
  val controlsEn: String,
  val controlsBn: String,
  val iconEmoji: String,
  val accentColor: Color,
  val difficulties: List<GameDifficulty> = listOf(GameDifficulty.EASY, GameDifficulty.MEDIUM, GameDifficulty.HARD),
  val hasHighScore: Boolean = true
)

data class Achievement(
  val id: String,
  val titleEn: String,
  val titleBn: String,
  val descEn: String,
  val descBn: String,
  val iconEmoji: String,
  val currentProgress: Int = 0,
  val maxProgress: Int = 1,
  val isUnlocked: Boolean = false
)

data class LeaderboardRecord(
  val id: String,
  val gameId: String,
  val playerName: String,
  val score: Int,
  val date: String
)

data class UserProfile(
  val name: String = "",
  val avatarIndex: Int = 0,
  val totalGames: Int = 0,
  val totalWins: Int = 0,
  val totalScore: Long = 0L,
  val favoriteGameId: String = "ludo",
  val isCloudSynced: Boolean = false,
  val accountEmail: String? = null
)

data class AdminAdSettings(
  val adsGloballyEnabled: Boolean = true,
  val bannerEnabled: Boolean = true,
  val interstitialEnabled: Boolean = true,
  val rewardedEnabled: Boolean = true,
  val interstitialIntervalSeconds: Int = 60,
  val interstitialFrequencyGames: Int = 2
)

enum class AppThemeMode {
  SYSTEM, LIGHT, DARK
}

enum class AppLanguage {
  ENGLISH, BANGLA
}
