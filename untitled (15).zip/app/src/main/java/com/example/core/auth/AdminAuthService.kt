package com.example.core.auth

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

data class AdminAuthSession(
  val isAuthenticated: Boolean,
  val token: String? = null,
  val email: String? = null,
  val role: String? = null,
  val errorMessage: String? = null
)

class AdminAuthService private constructor() {
  /**
   * Secure server-side authentication for admin dashboard access.
   * Eliminates client-side hardcoded credentials in compliance with security guidelines.
   */
  suspend fun authenticate(endpointUrl: String, authToken: String): AdminAuthSession = withContext(Dispatchers.IO) {
    if (endpointUrl.isBlank() || authToken.isBlank()) {
      return@withContext AdminAuthSession(
        isAuthenticated = false,
        errorMessage = "Server endpoint and authorization token are required"
      )
    }

    try {
      val url = URL(endpointUrl)
      val connection = (url.openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = 8000
        readTimeout = 8000
        setRequestProperty("Content-Type", "application/json")
        setRequestProperty("Authorization", "Bearer $authToken")
        doOutput = true
      }

      val requestBody = JSONObject().apply {
        put("action", "verify_admin_credentials")
        put("timestamp", System.currentTimeMillis())
      }

      OutputStreamWriter(connection.outputStream).use { writer ->
        writer.write(requestBody.toString())
        writer.flush()
      }

      val responseCode = connection.responseCode
      if (responseCode == 200) {
        val responseText = connection.inputStream.bufferedReader().use { it.readText() }
        val json = JSONObject(responseText)
        val role = json.optString("role", "admin")
        val email = json.optString("email", "verified_admin")
        return@withContext AdminAuthSession(
          isAuthenticated = true,
          token = authToken,
          email = email,
          role = role
        )
      } else {
        return@withContext AdminAuthSession(
          isAuthenticated = false,
          errorMessage = "Server authentication failed with status code $responseCode"
        )
      }
    } catch (e: Exception) {
      Log.e("AdminAuthService", "Network or server connection error during authentication", e)
      return@withContext AdminAuthSession(
        isAuthenticated = false,
        errorMessage = "Failed to connect to authentication server: ${e.message}"
      )
    }
  }

  companion object {
    @Volatile
    private var INSTANCE: AdminAuthService? = null

    fun getInstance(): AdminAuthService {
      return INSTANCE ?: synchronized(this) {
        INSTANCE ?: AdminAuthService().also { INSTANCE = it }
      }
    }
  }
}
