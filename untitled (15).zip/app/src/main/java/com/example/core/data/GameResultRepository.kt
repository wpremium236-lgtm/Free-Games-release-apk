package com.example.core.data

import android.content.Context
import android.util.Log
import com.example.core.model.GameResult
import com.example.core.model.GameResultType
import com.example.core.model.LeaderboardRecord
import com.example.core.storage.GamePreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

sealed interface SubmissionResult {
  data class Success(val record: LeaderboardRecord, val isNewHighScore: Boolean) : SubmissionResult
  data class Rejected(val reason: String) : SubmissionResult
  data class Duplicate(val message: String) : SubmissionResult
}

class GameResultRepository(context: Context) {
  private val prefs = GamePreferences(context.applicationContext)
  private val submittedSessionIds = mutableSetOf<String>()
  private val _leaderboardUpdates = MutableStateFlow<Map<String, List<LeaderboardRecord>>>(emptyMap())
  val leaderboardUpdates: StateFlow<Map<String, List<LeaderboardRecord>>> = _leaderboardUpdates.asStateFlow()

  fun generateSessionId(): String {
    return UUID.randomUUID().toString()
  }

  /**
   * Validates score limits and sanity checks to prevent impossible / cheated scores.
   */
  fun validateResult(result: GameResult): Pair<Boolean, String?> {
    if (result.playerName.isBlank()) {
      return false to "Player name cannot be blank"
    }
    if (result.score < 0) {
      return false to "Negative score is invalid"
    }

    // Maximum score sanity checks per game rules
    val maxAllowedScore = when (result.gameId) {
      "tictactoe" -> 1
      "ludo" -> 500
      "chess", "checkers" -> 1
      "snake" -> 50_000
      "carracing" -> 100_000
      "tapflying" -> 5_000
      "game2048" -> 500_000
      "sudoku" -> 10_000
      "minesweeper" -> 10_000
      "memorymatch" -> 20_000
      "solitaire" -> 50_000
      "bubbleshooter" -> 200_000
      "archery" -> 10_000
      "brickbreaker" -> 100_000
      "knifehit" -> 10_000
      "fruitslicer" -> 50_000
      "blockpuzzle" -> 100_000
      "colormatch" -> 10_000
      "whackamole" -> 10_000
      else -> 1_000_000
    }

    if (result.score > maxAllowedScore) {
      return false to "Score ${result.score} exceeds maximum possible score for ${result.gameId}"
    }

    // Minimum reasonable duration check (unless score is 0)
    if (result.score > 100 && result.duration < 1L) {
      return false to "Gameplay duration too short for achieved score"
    }

    return true to null
  }

  /**
   * Submits a real verified GameResult. Prevents duplicate submissions by session ID.
   */
  suspend fun submitGameResult(result: GameResult): SubmissionResult = withContext(Dispatchers.IO) {
    if (submittedSessionIds.contains(result.sessionId)) {
      Log.w("GameResultRepository", "Duplicate submission attempt for session ${result.sessionId}")
      return@withContext SubmissionResult.Duplicate("Game session already recorded")
    }

    val (isValid, rejectReason) = validateResult(result)
    if (!isValid) {
      Log.w("GameResultRepository", "Rejected score submission: $rejectReason")
      return@withContext SubmissionResult.Rejected(rejectReason ?: "Invalid game result")
    }

    submittedSessionIds.add(result.sessionId)
    val isWin = result.resultType == GameResultType.WIN
    val previousHigh = prefs.getHighScore(result.gameId)
    val isNewHigh = result.score > previousHigh

    if (isNewHigh) {
      prefs.setHighScore(result.gameId, result.score)
    }

    // Persist to user stats & profile
    prefs.recordGamePlayed(result.gameId, isWin = isWin, scoreEarned = result.score)

    val dateStr = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(result.completedAt))
    val record = LeaderboardRecord(
      id = result.sessionId,
      gameId = result.gameId,
      playerName = result.playerName,
      score = result.score,
      date = dateStr
    )

    // Ensure real leaderboard record is added only if score > 0 and real playerName configured
    if (result.score > 0 && result.playerName.isNotBlank() && result.playerName != "Player 1") {
      prefs.addLeaderboardEntry(result.gameId, result.playerName, result.score)
    }

    return@withContext SubmissionResult.Success(record, isNewHigh)
  }

  fun getLeaderboard(gameId: String): List<LeaderboardRecord> {
    return prefs.getLeaderboard(gameId)
  }

  companion object {
    @Volatile
    private var INSTANCE: GameResultRepository? = null

    fun getInstance(context: Context): GameResultRepository {
      return INSTANCE ?: synchronized(this) {
        INSTANCE ?: GameResultRepository(context).also { INSTANCE = it }
      }
    }
  }
}
