package com.example.core.model

enum class GameResultType {
  WIN,
  LOSS,
  DRAW,
  GAME_OVER,
  COMPLETED
}

data class GameResult(
  val gameId: String,
  val playerId: String,
  val playerName: String,
  val score: Int,
  val resultType: GameResultType,
  val duration: Long, // in seconds
  val completedAt: Long, // timestamp ms
  val sessionId: String
)
