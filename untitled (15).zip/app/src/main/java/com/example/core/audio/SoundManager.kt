package com.example.core.audio

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SoundManager private constructor(context: Context) {
  private val appContext = context.applicationContext
  private var toneGenerator: ToneGenerator? = null
  private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
    val vibratorManager = appContext.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
    vibratorManager?.defaultVibrator
  } else {
    @Suppress("DEPRECATION")
    appContext.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
  }

  var isSoundEnabled: Boolean = true
  var isMusicEnabled: Boolean = true
  var isVibrationEnabled: Boolean = true

  init {
    try {
      toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 80)
    } catch (_: Exception) {
      toneGenerator = null
    }
  }

  fun playButtonClick() {
    if (!isSoundEnabled) return
    try {
      toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 40)
    } catch (_: Exception) {}
    vibrate(20)
  }

  fun playDiceRoll() {
    if (!isSoundEnabled) return
    CoroutineScope(Dispatchers.Default).launch {
      for (i in 0..3) {
        try {
          toneGenerator?.startTone(ToneGenerator.TONE_PROP_PROMPT, 30)
        } catch (_: Exception) {}
        delay(60)
      }
    }
    vibrate(40)
  }

  fun playCardSound() {
    if (!isSoundEnabled) return
    try {
      toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 35)
    } catch (_: Exception) {}
    vibrate(15)
  }

  fun playCollisionSound() {
    if (!isSoundEnabled) return
    try {
      toneGenerator?.startTone(ToneGenerator.TONE_CDMA_SOFT_ERROR_LITE, 80)
    } catch (_: Exception) {}
    vibrate(60)
  }

  fun playWinSound() {
    if (!isSoundEnabled) return
    CoroutineScope(Dispatchers.Default).launch {
      try {
        toneGenerator?.startTone(ToneGenerator.TONE_DTMF_3, 80)
        delay(100)
        toneGenerator?.startTone(ToneGenerator.TONE_DTMF_6, 80)
        delay(100)
        toneGenerator?.startTone(ToneGenerator.TONE_DTMF_9, 150)
      } catch (_: Exception) {}
    }
    vibrate(120)
  }

  fun playLoseSound() {
    if (!isSoundEnabled) return
    CoroutineScope(Dispatchers.Default).launch {
      try {
        toneGenerator?.startTone(ToneGenerator.TONE_DTMF_7, 100)
        delay(120)
        toneGenerator?.startTone(ToneGenerator.TONE_DTMF_4, 100)
        delay(120)
        toneGenerator?.startTone(ToneGenerator.TONE_DTMF_1, 200)
      } catch (_: Exception) {}
    }
    vibrate(150)
  }

  fun playMoveSound() {
    if (!isSoundEnabled) return
    try {
      toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP2, 30)
    } catch (_: Exception) {}
    vibrate(15)
  }

  fun playScoreBeep() {
    if (!isSoundEnabled) return
    try {
      toneGenerator?.startTone(ToneGenerator.TONE_PROP_PROMPT, 50)
    } catch (_: Exception) {}
  }

  fun vibrate(milliseconds: Long = 40) {
    if (!isVibrationEnabled || vibrator == null || !vibrator.hasVibrator()) return
    try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        vibrator.vibrate(VibrationEffect.createOneShot(milliseconds, VibrationEffect.DEFAULT_AMPLITUDE))
      } else {
        @Suppress("DEPRECATION")
        vibrator.vibrate(milliseconds)
      }
    } catch (_: Exception) {}
  }

  companion object {
    @Volatile
    private var INSTANCE: SoundManager? = null

    fun getInstance(context: Context): SoundManager {
      return INSTANCE ?: synchronized(this) {
        INSTANCE ?: SoundManager(context).also { INSTANCE = it }
      }
    }
  }
}
