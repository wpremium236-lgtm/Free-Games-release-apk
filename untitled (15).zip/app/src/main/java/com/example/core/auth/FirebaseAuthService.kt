package com.example.core.auth

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.google.android.gms.tasks.Task
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

sealed class AuthUiState {
  data object Idle : AuthUiState()
  data object Loading : AuthUiState()
  data class Success(val user: FirebaseUser) : AuthUiState()
  data class Error(val message: String) : AuthUiState()
}

class FirebaseAuthService private constructor(private val appContext: Context) {
  private val auth: FirebaseAuth? by lazy {
    try {
      if (FirebaseApp.getApps(appContext).isNotEmpty()) {
        FirebaseAuth.getInstance()
      } else {
        null
      }
    } catch (e: Exception) {
      Log.e("FirebaseAuthService", "Firebase Auth initialization error: ${e.message}", e)
      null
    }
  }

  private val credentialManager: CredentialManager by lazy {
    CredentialManager.create(appContext)
  }

  private val _currentUserState = MutableStateFlow<FirebaseUser?>(null)
  val currentUserState: StateFlow<FirebaseUser?> = _currentUserState.asStateFlow()

  val isConfigured: Boolean
    get() = auth != null

  init {
    try {
      auth?.let { fbAuth ->
        _currentUserState.value = fbAuth.currentUser
        fbAuth.addAuthStateListener { updatedAuth ->
          _currentUserState.value = updatedAuth.currentUser
          Log.d("FirebaseAuthService", "Auth state changed. Current user UID: ${updatedAuth.currentUser?.uid}")
        }
      }
    } catch (e: Exception) {
      Log.e("FirebaseAuthService", "Error setting up AuthStateListener", e)
    }
  }

  fun getCurrentUser(): FirebaseUser? = auth?.currentUser

  suspend fun signUpWithEmail(email: String, password: String): Result<FirebaseUser> {
    val fbAuth = auth ?: return Result.failure(IllegalStateException("Firebase is not initialized. Please ensure google-services.json is present."))
    return try {
      val result: AuthResult = fbAuth.createUserWithEmailAndPassword(email.trim(), password).awaitResult()
      val user = result.user ?: throw IllegalStateException("User creation returned null user")
      Result.success(user)
    } catch (e: Exception) {
      Log.e("FirebaseAuthService", "Sign up failed: ${e.message}", e)
      Result.failure(e)
    }
  }

  suspend fun signInWithEmail(email: String, password: String): Result<FirebaseUser> {
    val fbAuth = auth ?: return Result.failure(IllegalStateException("Firebase is not initialized. Please ensure google-services.json is present."))
    return try {
      val result: AuthResult = fbAuth.signInWithEmailAndPassword(email.trim(), password).awaitResult()
      val user = result.user ?: throw IllegalStateException("Sign in returned null user")
      Result.success(user)
    } catch (e: Exception) {
      Log.e("FirebaseAuthService", "Sign in failed: ${e.message}", e)
      Result.failure(e)
    }
  }

  fun signOut() {
    try {
      auth?.signOut()
      _currentUserState.value = null
    } catch (e: Exception) {
      Log.e("FirebaseAuthService", "Sign out error", e)
    }
  }

  suspend fun signInWithGoogle(activity: Activity): Result<FirebaseUser> {
    val fbAuth = auth ?: return Result.failure(IllegalStateException("Firebase is not initialized. Please ensure google-services.json is present."))
    val serverClientIdResId = appContext.resources.getIdentifier("default_web_client_id", "string", appContext.packageName)
    if (serverClientIdResId == 0) {
      return Result.failure(IllegalStateException("Google Sign-In Web Client ID not found. Ensure google-services.json with OAuth 2.0 Web Client configuration is provided."))
    }
    val serverClientId = appContext.getString(serverClientIdResId)
    return try {
      val googleIdOption = GetGoogleIdOption.Builder()
        .setFilterByAuthorizedAccounts(false)
        .setServerClientId(serverClientId)
        .setAutoSelectEnabled(false)
        .build()

      val request = GetCredentialRequest.Builder()
        .addCredentialOption(googleIdOption)
        .build()

      val result = credentialManager.getCredential(activity, request)
      val credential = result.credential
      if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
        val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
        val authCredential = GoogleAuthProvider.getCredential(googleIdTokenCredential.idToken, null)
        val authResult = fbAuth.signInWithCredential(authCredential).awaitResult()
        val user = authResult.user ?: throw IllegalStateException("Google sign-in returned null user")
        Result.success(user)
      } else {
        Result.failure(IllegalStateException("Unexpected credential format received"))
      }
    } catch (e: GetCredentialCancellationException) {
      Result.failure(e)
    } catch (e: Exception) {
      Log.e("FirebaseAuthService", "Google Sign-In failed: ${e.message}", e)
      val userFriendlyMessage = when {
        e.message?.contains("Developer console is not set up correctly", ignoreCase = true) == true -> {
          "Google Play Services configuration incomplete: SHA-1 fingerprint (7B:5D:9E:F4:01:86:1B:75:70:B4:E1:05:40:1F:30:B1:25:06:51:54) must be added in Firebase Console (Project Settings -> Your Android App)."
        }
        e.message?.contains("16:", ignoreCase = true) == true || e.message?.contains("CANCELED", ignoreCase = true) == true -> {
          "Sign-in was cancelled by user."
        }
        else -> e.message ?: "Google Sign-In failed."
      }
      Result.failure(Exception(userFriendlyMessage, e))
    }
  }

  companion object {
    @Volatile
    private var INSTANCE: FirebaseAuthService? = null

    fun getInstance(context: Context): FirebaseAuthService {
      return INSTANCE ?: synchronized(this) {
        INSTANCE ?: FirebaseAuthService(context.applicationContext).also { INSTANCE = it }
      }
    }
  }
}

private suspend fun <T> Task<T>.awaitResult(): T = suspendCancellableCoroutine { cont ->
  addOnSuccessListener { result ->
    if (cont.isActive) cont.resume(result)
  }
  addOnFailureListener { exception ->
    if (cont.isActive) cont.resumeWithException(exception)
  }
  addOnCanceledListener {
    if (cont.isActive) cont.cancel()
  }
}
