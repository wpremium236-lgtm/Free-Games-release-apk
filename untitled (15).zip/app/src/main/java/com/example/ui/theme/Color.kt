package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Modern Gaming Hub Theme Colors
val PrimaryPurple = Color(0xFF6C5CE7)
val PrimaryPurpleDark = Color(0xFF5B4BC4)
val SecondaryTeal = Color(0xFF00CEC9)
val AccentAmber = Color(0xFFFFB142)
val AccentRose = Color(0xFFFF5252)
val AccentGreen = Color(0xFF2ED573)

// Dark Palette
val DarkBackground = Color(0xFF0F0C20)
val DarkSurface = Color(0xFF18152E)
val DarkSurfaceVariant = Color(0xFF241F42)
val DarkTextPrimary = Color(0xFFF8F9FA)
val DarkTextSecondary = Color(0xFFA4B0BE)

// Light Palette
val LightBackground = Color(0xFFF4F6FB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE8ECF4)
val LightTextPrimary = Color(0xFF1A1A2E)
val LightTextSecondary = Color(0xFF57606F)
