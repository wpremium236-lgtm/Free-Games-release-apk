package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.GameCatalog
import com.example.core.model.LeaderboardRecord
import com.example.core.storage.GamePreferences

@Composable
fun LeaderboardScreen(
  onBack: () -> Unit
) {
  val context = LocalContext.current
  val prefs = remember { GamePreferences(context) }
  val userProfile = remember { prefs.getUserProfile() }
  val allGames = remember { GameCatalog.games }
  var selectedGameId by remember { mutableStateOf<String?>("overall") }

  // Load real records exclusively
  val realRecords = remember(selectedGameId, userProfile.totalScore) {
    if (selectedGameId == "overall") {
      val overallList = mutableListOf<LeaderboardRecord>()
      allGames.forEach { game ->
        val gameScores = prefs.getLeaderboard(game.id)
        overallList.addAll(gameScores)
      }
      overallList.sortedByDescending { it.score }.take(50)
    } else {
      prefs.getLeaderboard(selectedGameId ?: "")
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F0C20))
      .padding(16.dp)
  ) {
    Text(
      "HONOR ROLL & LEADERBOARD",
      fontSize = 22.sp,
      fontWeight = FontWeight.Black,
      color = Color.White
    )
    Text(
      "Verified Match Results & High Scores",
      fontSize = 12.sp,
      color = Color(0xFF00CEC9),
      fontWeight = FontWeight.SemiBold
    )

    Spacer(modifier = Modifier.height(12.dp))

    // Filter Chips: Overall + Individual Games
    LazyRow(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      item {
        FilterChip(
          selected = selectedGameId == "overall",
          onClick = { selectedGameId = "overall" },
          label = { Text("All Games") },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = Color(0xFF6C5CE7),
            selectedLabelColor = Color.White,
            containerColor = Color(0xFF18152E),
            labelColor = Color(0xFFA4B0BE)
          )
        )
      }
      items(allGames) { game ->
        FilterChip(
          selected = selectedGameId == game.id,
          onClick = { selectedGameId = game.id },
          label = { Text("${game.iconEmoji} ${game.nameEn}") },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = Color(0xFF6C5CE7),
            selectedLabelColor = Color.White,
            containerColor = Color(0xFF18152E),
            labelColor = Color(0xFFA4B0BE)
          )
        )
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    if (realRecords.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text("🏅", fontSize = 48.sp)
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = "No data yet.",
            color = Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "Play matches or set new high scores to see rankings here!",
            color = Color(0xFFA4B0BE),
            fontSize = 13.sp
          )
        }
      }
    } else {
      if (realRecords.size >= 3) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
          horizontalArrangement = Arrangement.SpaceEvenly,
          verticalAlignment = Alignment.Bottom
        ) {
          PodiumItem(rank = 2, entry = realRecords.getOrNull(1), height = 90.dp, color = Color(0xFFA4B0BE))
          PodiumItem(rank = 1, entry = realRecords.getOrNull(0), height = 115.dp, color = Color(0xFFFFB142))
          PodiumItem(rank = 3, entry = realRecords.getOrNull(2), height = 75.dp, color = Color(0xFFE17055))
        }
        Spacer(modifier = Modifier.height(12.dp))
      }

      LazyColumn(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.weight(1f).testTag("leaderboard_list")
      ) {
        itemsIndexed(realRecords) { index, item ->
          val rank = index + 1
          val isCurrentUser = item.playerName == userProfile.name

          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(
              containerColor = if (isCurrentUser) Color(0xFF6C5CE7).copy(alpha = 0.25f) else Color(0xFF18152E)
            ),
            modifier = Modifier
              .fillMaxWidth()
              .border(
                width = if (isCurrentUser) 1.5.dp else 1.dp,
                color = if (isCurrentUser) Color(0xFF6C5CE7) else Color(0xFF241F42),
                shape = RoundedCornerShape(12.dp)
              )
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "#$rank",
                  fontWeight = FontWeight.Bold,
                  fontSize = 14.sp,
                  color = when (rank) {
                    1 -> Color(0xFFFFB142)
                    2 -> Color(0xFFA4B0BE)
                    3 -> Color(0xFFE17055)
                    else -> Color(0xFF747D8C)
                  },
                  modifier = Modifier.width(36.dp)
                )
                Box(
                  modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF241F42)),
                  contentAlignment = Alignment.Center
                ) {
                  Text("👤", fontSize = 18.sp)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                  Text(
                    text = item.playerName + if (isCurrentUser) " (YOU)" else "",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = if (isCurrentUser) Color(0xFF00CEC9) else Color.White
                  )
                  Text(
                    text = item.date,
                    fontSize = 11.sp,
                    color = Color(0xFFA4B0BE)
                  )
                }
              }

              Text(
                text = "${item.score} pts",
                fontWeight = FontWeight.Black,
                fontSize = 14.sp,
                color = Color(0xFFFFB142)
              )
            }
          }
        }
      }
    }
  }
}

@Composable
fun PodiumItem(rank: Int, entry: LeaderboardRecord?, height: Dp, color: Color) {
  if (entry == null) return
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text("👑", fontSize = 24.sp)
    Spacer(modifier = Modifier.height(2.dp))
    Text(
      entry.playerName.take(8),
      fontSize = 11.sp,
      fontWeight = FontWeight.Bold,
      color = Color.White
    )
    Spacer(modifier = Modifier.height(2.dp))
    Text(
      "${entry.score}",
      fontSize = 10.sp,
      color = Color(0xFFFFB142),
      fontWeight = FontWeight.SemiBold
    )
    Spacer(modifier = Modifier.height(4.dp))
    Box(
      modifier = Modifier
        .width(80.dp)
        .height(height)
        .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
        .background(
          Brush.verticalGradient(listOf(color, color.copy(alpha = 0.4f)))
        ),
      contentAlignment = Alignment.Center
    ) {
      Text(
        "#$rank",
        fontWeight = FontWeight.Black,
        fontSize = 20.sp,
        color = Color.White
      )
    }
  }
}
