package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.ads.AdManager
import com.example.core.ads.PolicyCompliantBannerAd
import com.example.core.model.GameCatalog
import com.example.core.model.GameCategory
import com.example.core.model.GameItem
import com.example.core.storage.GamePreferences

enum class HubTab { GAMES, LEADERBOARDS, ACHIEVEMENTS, PROFILE }

@Composable
fun HomeScreen(
  onSelectGame: (GameItem) -> Unit,
  currentTab: HubTab,
  onTabChange: (HubTab) -> Unit
) {
  val context = LocalContext.current
  val prefs = remember { GamePreferences(context) }
  val adManager = remember { AdManager.getInstance(context) }
  val userProfile = remember { prefs.getUserProfile() }
  var searchQuery by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf<GameCategory?>(null) }

  val filteredGames = remember(searchQuery, selectedCategory) {
    GameCatalog.games.filter { game ->
      val matchesCategory = selectedCategory == null || game.category == selectedCategory
      val matchesSearch = searchQuery.isBlank() ||
          game.nameEn.contains(searchQuery, ignoreCase = true) ||
          game.descriptionEn.contains(searchQuery, ignoreCase = true) ||
          game.nameBn.contains(searchQuery, ignoreCase = true)
      matchesCategory && matchesSearch
    }
  }

  val featuredGame = remember { GameCatalog.games.first { it.id == "ludo" } }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F0C20))
  ) {
    // Top Bar with App Logo & Title
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(38.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(
              Brush.linearGradient(listOf(Color(0xFF6C5CE7), Color(0xFF00CEC9)))
            ),
          contentAlignment = Alignment.Center
        ) {
          Text("🎮", fontSize = 20.sp)
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(
            "20 FREE GAMES",
            fontWeight = FontWeight.Black,
            fontSize = 17.sp,
            color = Color.White,
            letterSpacing = 0.5.sp
          )
          Text(
            "All 20 Genuine Games • Zero Paywalls",
            fontSize = 11.sp,
            color = Color(0xFF00CEC9),
            fontWeight = FontWeight.Medium
          )
        }
      }

      // Quick Total Score / Wins Badge
      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(20.dp))
          .background(Color(0xFF1E1B38))
          .border(1.dp, Color(0xFF3B336A), RoundedCornerShape(20.dp))
          .padding(horizontal = 10.dp, vertical = 5.dp)
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text("⭐", fontSize = 12.sp)
          Spacer(modifier = Modifier.width(4.dp))
          Text("${userProfile.totalScore} pts", color = Color(0xFFFFB142), fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
      }
    }

    // Search Bar
    OutlinedTextField(
      value = searchQuery,
      onValueChange = { searchQuery = it },
      placeholder = { Text("Search ${GameCatalog.games.size} games...", color = Color(0xFFA4B0BE), fontSize = 13.sp) },
      leadingIcon = {
        Icon(Icons.Default.Search, contentDescription = "Search", tint = Color(0xFFA4B0BE), modifier = Modifier.size(20.dp))
      },
      trailingIcon = {
        if (searchQuery.isNotEmpty()) {
          IconButton(onClick = { searchQuery = "" }) {
            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color(0xFFA4B0BE), modifier = Modifier.size(18.dp))
          }
        }
      },
      singleLine = true,
      colors = OutlinedTextFieldDefaults.colors(
        focusedContainerColor = Color(0xFF18152E),
        unfocusedContainerColor = Color(0xFF18152E),
        focusedBorderColor = Color(0xFF6C5CE7),
        unfocusedBorderColor = Color(0xFF2E294E),
        focusedTextColor = Color.White,
        unfocusedTextColor = Color.White
      ),
      shape = RoundedCornerShape(12.dp),
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 4.dp)
        .testTag("home_search_input")
    )

    // Category Filter Chips
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 8.dp)
        .horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Spacer(modifier = Modifier.width(8.dp))
      val isAllSelected = selectedCategory == null
      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(20.dp))
          .background(if (isAllSelected) Color(0xFF6C5CE7) else Color(0xFF1E1B38))
          .clickable { selectedCategory = null }
          .padding(horizontal = 14.dp, vertical = 6.dp)
      ) {
        Text("All (${GameCatalog.games.size})", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
      }
      GameCategory.values().filter { it != GameCategory.ALL }.forEach { cat ->
        val isSelected = selectedCategory == cat
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (isSelected) Color(0xFF6C5CE7) else Color(0xFF1E1B38))
            .clickable { selectedCategory = cat }
            .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
          Text(cat.displayNameEn, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
        }
      }
      Spacer(modifier = Modifier.width(8.dp))
    }

    // Games Grid
    LazyVerticalGrid(
      columns = GridCells.Fixed(2),
      contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.spacedBy(10.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
      modifier = Modifier
        .weight(1f)
        .testTag("games_grid")
    ) {
      // Featured Game Banner if no search query
      if (searchQuery.isBlank() && selectedCategory == null) {
        item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(2) }) {
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF241F42)),
            modifier = Modifier
              .fillMaxWidth()
              .clickable { onSelectGame(featuredGame) }
              .testTag("featured_game_card")
          ) {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .background(
                  Brush.horizontalGradient(
                    listOf(Color(0xFF6C5CE7).copy(alpha = 0.85f), Color(0xFF18152E))
                  )
                )
                .padding(16.dp)
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Box(
                    modifier = Modifier
                      .clip(RoundedCornerShape(6.dp))
                      .background(Color(0xFFFFB142))
                      .padding(horizontal = 6.dp, vertical = 2.dp)
                  ) {
                    Text("FEATURED", fontSize = 9.sp, fontWeight = FontWeight.Black, color = Color.Black)
                  }
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(featuredGame.nameEn, fontWeight = FontWeight.Black, fontSize = 20.sp, color = Color.White)
                  Text("Play with 2-6 players or vs AI!", fontSize = 12.sp, color = Color(0xFFA4B0BE))
                }
                Box(
                  modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF2ED573)),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = Color.White, modifier = Modifier.size(28.dp))
                }
              }
            }
          }
        }
      }

      // 20+ Games Cards
      items(filteredGames, key = { it.id }) { game ->
        val highScore = prefs.getHighScore(game.id)
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFF18152E)),
          modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelectGame(game) }
            .testTag("game_card_${game.id}")
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(42.dp)
                  .clip(RoundedCornerShape(10.dp))
                  .background(Color(0xFF241F42)),
                contentAlignment = Alignment.Center
              ) {
                Text(game.iconEmoji, fontSize = 24.sp)
              }
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(6.dp))
                  .background(Color(0xFF2E294E))
                  .padding(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Text(game.category.displayNameEn, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF00CEC9))
              }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
              game.nameEn,
              fontWeight = FontWeight.Bold,
              fontSize = 15.sp,
              color = Color.White,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              game.descriptionEn,
              fontSize = 11.sp,
              color = Color(0xFFA4B0BE),
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              if (highScore > 0) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text("🏆", fontSize = 10.sp)
                  Spacer(modifier = Modifier.width(2.dp))
                  Text("$highScore", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFB142))
                }
              } else {
                Text("Free", fontSize = 10.sp, color = Color(0xFF2ED573), fontWeight = FontWeight.Bold)
              }
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(6.dp))
                  .background(Color(0xFF6C5CE7))
                  .padding(horizontal = 8.dp, vertical = 4.dp)
              ) {
                Text("PLAY", fontSize = 10.sp, fontWeight = FontWeight.Black, color = Color.White)
              }
            }
          }
        }
      }
    }

    // Banner Ad at bottom
    PolicyCompliantBannerAd(adManager = adManager)

    // Bottom Navigation Bar
    NavigationBar(
      containerColor = Color(0xFF141128),
      contentColor = Color.White,
      tonalElevation = 8.dp
    ) {
      NavigationBarItem(
        selected = currentTab == HubTab.GAMES,
        onClick = { onTabChange(HubTab.GAMES) },
        icon = { Icon(Icons.Default.Gamepad, contentDescription = "Games") },
        label = { Text("Games", fontSize = 10.sp) },
        colors = NavigationBarItemDefaults.colors(
          selectedIconColor = Color(0xFF00CEC9),
          selectedTextColor = Color(0xFF00CEC9),
          indicatorColor = Color(0xFF241F42),
          unselectedIconColor = Color(0xFFA4B0BE),
          unselectedTextColor = Color(0xFFA4B0BE)
        ),
        modifier = Modifier.testTag("nav_tab_games")
      )
      NavigationBarItem(
        selected = currentTab == HubTab.LEADERBOARDS,
        onClick = { onTabChange(HubTab.LEADERBOARDS) },
        icon = { Icon(Icons.Default.Leaderboard, contentDescription = "Leaderboard") },
        label = { Text("Rankings", fontSize = 10.sp) },
        colors = NavigationBarItemDefaults.colors(
          selectedIconColor = Color(0xFF00CEC9),
          selectedTextColor = Color(0xFF00CEC9),
          indicatorColor = Color(0xFF241F42),
          unselectedIconColor = Color(0xFFA4B0BE),
          unselectedTextColor = Color(0xFFA4B0BE)
        ),
        modifier = Modifier.testTag("nav_tab_leaderboard")
      )
      NavigationBarItem(
        selected = currentTab == HubTab.ACHIEVEMENTS,
        onClick = { onTabChange(HubTab.ACHIEVEMENTS) },
        icon = { Icon(Icons.Default.EmojiEvents, contentDescription = "Achievements") },
        label = { Text("Badges", fontSize = 10.sp) },
        colors = NavigationBarItemDefaults.colors(
          selectedIconColor = Color(0xFF00CEC9),
          selectedTextColor = Color(0xFF00CEC9),
          indicatorColor = Color(0xFF241F42),
          unselectedIconColor = Color(0xFFA4B0BE),
          unselectedTextColor = Color(0xFFA4B0BE)
        ),
        modifier = Modifier.testTag("nav_tab_achievements")
      )
      NavigationBarItem(
        selected = currentTab == HubTab.PROFILE,
        onClick = { onTabChange(HubTab.PROFILE) },
        icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
        label = { Text("Profile", fontSize = 10.sp) },
        colors = NavigationBarItemDefaults.colors(
          selectedIconColor = Color(0xFF00CEC9),
          selectedTextColor = Color(0xFF00CEC9),
          indicatorColor = Color(0xFF241F42),
          unselectedIconColor = Color(0xFFA4B0BE),
          unselectedTextColor = Color(0xFFA4B0BE)
        ),
        modifier = Modifier.testTag("nav_tab_profile")
      )
    }
  }
}
