package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.storage.AchievementManager

@Composable
fun AchievementsScreen(
  onBack: () -> Unit
) {
  val context = LocalContext.current
  val achievementManager = remember { AchievementManager(context) }
  val list = remember { achievementManager.getAchievements() }
  val unlockedCount = list.count { it.isUnlocked }
  val progress = if (list.isNotEmpty()) unlockedCount.toFloat() / list.size else 0f

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F0C20))
      .padding(16.dp)
  ) {
    Text(
      "ACHIEVEMENTS",
      fontSize = 22.sp,
      fontWeight = FontWeight.Black,
      color = Color.White
    )
    Text(
      "Unlock trophies across all 20 games",
      fontSize = 12.sp,
      color = Color(0xFF00CEC9),
      fontWeight = FontWeight.SemiBold
    )

    Spacer(modifier = Modifier.height(16.dp))

    // Overall Progress Card
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF18152E)),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("Completion Progress", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
          Text("$unlockedCount / ${list.size}", fontWeight = FontWeight.Bold, color = Color(0xFFFFB142), fontSize = 14.sp)
        }
        Spacer(modifier = Modifier.height(8.dp))
        LinearProgressIndicator(
          progress = { progress },
          modifier = Modifier
            .fillMaxWidth()
            .height(8.dp)
            .clip(RoundedCornerShape(4.dp)),
          color = Color(0xFF2ED573),
          trackColor = Color(0xFF241F42)
        )
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Achievements List
    LazyColumn(
      verticalArrangement = Arrangement.spacedBy(10.dp),
      modifier = Modifier.weight(1f).testTag("achievements_list")
    ) {
      items(list, key = { it.id }) { ach ->
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(
            containerColor = if (ach.isUnlocked) Color(0xFF1E1B38) else Color(0xFF141128)
          ),
          modifier = Modifier
            .fillMaxWidth()
            .border(
              width = 1.dp,
              color = if (ach.isUnlocked) Color(0xFF6C5CE7) else Color(0xFF241F42),
              shape = RoundedCornerShape(12.dp)
            )
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(if (ach.isUnlocked) Color(0xFF6C5CE7).copy(alpha = 0.35f) else Color(0xFF1E1B38)),
              contentAlignment = Alignment.Center
            ) {
              Text(
                if (ach.isUnlocked) ach.iconEmoji else "🔒",
                fontSize = 22.sp
              )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = ach.titleEn,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = if (ach.isUnlocked) Color.White else Color(0xFFA4B0BE)
              )
              Text(
                text = ach.descEn,
                fontSize = 12.sp,
                color = Color(0xFFA4B0BE)
              )
            }
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(if (ach.isUnlocked) Color(0xFF2ED573) else Color(0xFF241F42))
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                "${ach.currentProgress}/${ach.maxProgress}",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (ach.isUnlocked) Color.Black else Color(0xFFA4B0BE)
              )
            }
          }
        }
      }
    }
  }
}
