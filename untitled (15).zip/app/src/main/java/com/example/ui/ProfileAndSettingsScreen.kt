package com.example.ui

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.audio.SoundManager
import com.example.core.auth.AdminAuthService
import com.example.core.auth.AdminAuthSession
import com.example.core.auth.FirebaseAuthService
import com.example.core.model.AdminAdSettings
import com.example.core.model.UserProfile
import com.example.core.storage.GamePreferences
import kotlinx.coroutines.launch

@Composable
fun ProfileAndSettingsScreen(
  onBack: () -> Unit
) {
  val context = LocalContext.current
  val activity = context as? Activity
  val prefs = remember { GamePreferences(context) }
  val soundManager = remember { SoundManager.getInstance(context) }
  val authService = remember { FirebaseAuthService.getInstance(context) }
  val currentUser by authService.currentUserState.collectAsStateWithLifecycle()

  var profile by remember { mutableStateOf(prefs.getUserProfile()) }
  var soundEnabled by remember { mutableStateOf(prefs.isSoundEnabled()) }
  var vibrationEnabled by remember { mutableStateOf(prefs.isVibrationEnabled()) }

  // Firebase Auth Form State
  var authEmail by remember { mutableStateOf("") }
  var authPassword by remember { mutableStateOf("") }
  var isSignUpMode by remember { mutableStateOf(false) }
  var isAuthLoading by remember { mutableStateOf(false) }
  var authErrorMessage by remember { mutableStateOf<String?>(null) }
  var authSuccessMessage by remember { mutableStateOf<String?>(null) }

  // Admin Ad Settings
  var adminSettings by remember { mutableStateOf(prefs.getAdminAdSettings()) }
  var adminAuthSession by remember { mutableStateOf<AdminAuthSession?>(null) }
  var showAdminLoginDialog by remember { mutableStateOf(false) }
  val coroutineScope = rememberCoroutineScope()
  val adminAuthService = remember { AdminAuthService.getInstance() }

  var showEditNameDialog by remember { mutableStateOf(false) }
  var showPolicyDialog by remember { mutableStateOf(false) }

  val avatarEmojis = listOf("🦁", "🦊", "🐼", "🦄", "🚀", "👑", "⚡", "🎮")

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F0C20))
      .padding(16.dp)
      .verticalScroll(rememberScrollState())
  ) {
    Text(
      "PLAYER PROFILE",
      fontSize = 22.sp,
      fontWeight = FontWeight.Black,
      color = Color.White
    )
    Text(
      "Preferences, stats & game controls",
      fontSize = 12.sp,
      color = Color(0xFF00CEC9),
      fontWeight = FontWeight.SemiBold
    )

    Spacer(modifier = Modifier.height(16.dp))

    // Profile Card
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF18152E)),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        val currentAvatar = avatarEmojis.getOrElse(profile.avatarIndex) { "🎮" }
        Box(
          modifier = Modifier
            .size(72.dp)
            .clip(CircleShape)
            .background(Color(0xFF241F42))
            .border(2.dp, Color(0xFF6C5CE7), CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Text(currentAvatar, fontSize = 38.sp)
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(profile.name.ifBlank { "Guest Player" }, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color.White)
          Spacer(modifier = Modifier.width(6.dp))
          Icon(
            Icons.Default.Edit,
            contentDescription = "Edit Name",
            tint = Color(0xFF00CEC9),
            modifier = Modifier
              .size(18.dp)
              .clickable { showEditNameDialog = true }
          )
        }
        if (profile.totalGames == 0) {
          Text("No data yet.", fontSize = 12.sp, color = Color(0xFFA4B0BE))
        } else {
          Text("${profile.totalGames} Games Played • ${profile.totalWins} Wins • ${profile.totalScore} pts", fontSize = 12.sp, color = Color(0xFFA4B0BE))
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Avatar selector row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceEvenly
        ) {
          avatarEmojis.forEachIndexed { idx, em ->
            Box(
              modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(if (profile.avatarIndex == idx) Color(0xFF6C5CE7) else Color(0xFF241F42))
                .clickable {
                  val updated = profile.copy(avatarIndex = idx)
                  profile = updated
                  prefs.saveUserProfile(updated)
                },
              contentAlignment = Alignment.Center
            ) {
              Text(em, fontSize = 18.sp)
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Firebase Cloud Authentication Card
    Text("FIREBASE CLOUD ACCOUNT", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFFA4B0BE))
    Spacer(modifier = Modifier.height(8.dp))
    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF18152E)),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AccountCircle, contentDescription = null, tint = Color(0xFF00CEC9), modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("AUTHENTICATION", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
          }
          if (currentUser != null) {
            Text("Active Session", color = Color(0xFF2ED573), fontSize = 11.sp, fontWeight = FontWeight.Bold)
          } else {
            Text("Signed Out", color = Color(0xFFA4B0BE), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (currentUser != null) {
          val user = currentUser!!
          Text(
            text = "Email: ${user.email ?: "No email associated"}",
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Firebase UID: ${user.uid}",
            color = Color(0xFFA4B0BE),
            fontSize = 11.sp
          )
          Spacer(modifier = Modifier.height(12.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Button(
              onClick = {
                authService.signOut()
                authEmail = ""
                authPassword = ""
                authErrorMessage = null
                authSuccessMessage = "Signed out. Enter credentials to switch account."
              },
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF241F42)),
              modifier = Modifier.weight(1f).testTag("auth_switch_account_button")
            ) {
              Icon(Icons.Default.SwapHoriz, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Switch", fontSize = 12.sp)
            }
            Button(
              onClick = {
                authService.signOut()
                authEmail = ""
                authPassword = ""
                authErrorMessage = null
                authSuccessMessage = null
              },
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE74C3C)),
              modifier = Modifier.weight(1f).testTag("auth_logout_button")
            ) {
              Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Logout", fontSize = 12.sp)
            }
          }
        } else {
          Text(
            text = if (isSignUpMode) "Register a new cloud account with Firebase:" else "Sign in with your email or Google account:",
            fontSize = 12.sp,
            color = Color(0xFFA4B0BE)
          )
          Spacer(modifier = Modifier.height(8.dp))
          OutlinedTextField(
            value = authEmail,
            onValueChange = { authEmail = it; authErrorMessage = null },
            label = { Text("Email", color = Color(0xFFA4B0BE)) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("auth_email_input"),
            colors = OutlinedTextFieldDefaults.colors(
              focusedTextColor = Color.White,
              unfocusedTextColor = Color.White,
              focusedBorderColor = Color(0xFF6C5CE7)
            )
          )
          Spacer(modifier = Modifier.height(8.dp))
          OutlinedTextField(
            value = authPassword,
            onValueChange = { authPassword = it; authErrorMessage = null },
            label = { Text("Password", color = Color(0xFFA4B0BE)) },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth().testTag("auth_password_input"),
            colors = OutlinedTextFieldDefaults.colors(
              focusedTextColor = Color.White,
              unfocusedTextColor = Color.White,
              focusedBorderColor = Color(0xFF6C5CE7)
            )
          )

          authErrorMessage?.let { err ->
            Spacer(modifier = Modifier.height(8.dp))
            Text(err, color = Color(0xFFFF5252), fontSize = 11.sp)
          }

          authSuccessMessage?.let { msg ->
            Spacer(modifier = Modifier.height(8.dp))
            Text(msg, color = Color(0xFF2ED573), fontSize = 11.sp)
          }

          Spacer(modifier = Modifier.height(12.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Button(
              onClick = {
                if (authEmail.isBlank() || authPassword.isBlank()) {
                  authErrorMessage = "Email and password cannot be empty"
                  return@Button
                }
                isAuthLoading = true
                authErrorMessage = null
                authSuccessMessage = null
                coroutineScope.launch {
                  val result = if (isSignUpMode) {
                    authService.signUpWithEmail(authEmail, authPassword)
                  } else {
                    authService.signInWithEmail(authEmail, authPassword)
                  }
                  isAuthLoading = false
                  result.onSuccess {
                    authEmail = ""
                    authPassword = ""
                    authErrorMessage = null
                  }.onFailure { ex ->
                    authErrorMessage = ex.message ?: "Authentication failed."
                  }
                }
              },
              enabled = !isAuthLoading && authEmail.isNotBlank() && authPassword.isNotBlank(),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6C5CE7)),
              modifier = Modifier.weight(1f).testTag("auth_submit_button")
            ) {
              Text(
                if (isAuthLoading) "Connecting..." else if (isSignUpMode) "Sign Up" else "Sign In",
                fontSize = 13.sp
              )
            }
            Button(
              onClick = {
                isSignUpMode = !isSignUpMode
                authErrorMessage = null
              },
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF241F42)),
              modifier = Modifier.weight(1f).testTag("auth_toggle_mode_button")
            ) {
              Text(
                if (isSignUpMode) "Have Account?" else "New User?",
                fontSize = 12.sp,
                color = Color.White
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))
          Button(
            onClick = {
              if (activity != null) {
                isAuthLoading = true
                authErrorMessage = null
                coroutineScope.launch {
                  val result = authService.signInWithGoogle(activity)
                  isAuthLoading = false
                  result.onSuccess {
                    authErrorMessage = null
                  }.onFailure { ex ->
                    authErrorMessage = ex.message ?: "Google Sign-In failed."
                  }
                }
              } else {
                authErrorMessage = "Google Sign-In requires an active Activity"
              }
            },
            enabled = !isAuthLoading,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4285F4)),
            modifier = Modifier.fillMaxWidth().testTag("auth_google_sign_in_button")
          ) {
            Text("Sign in with Google", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Audio & Haptics Card
    Text("AUDIO & HAPTICS", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFFA4B0BE))
    Spacer(modifier = Modifier.height(8.dp))
    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF18152E)),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = null, tint = Color(0xFF00CEC9), modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Text("Sound Effects", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
          }
          Switch(
            checked = soundEnabled,
            onCheckedChange = {
              soundEnabled = it
              prefs.setSoundEnabled(it)
              soundManager.isSoundEnabled = it
            },
            colors = SwitchDefaults.colors(
              checkedThumbColor = Color.White,
              checkedTrackColor = Color(0xFF6C5CE7)
            ),
            modifier = Modifier.testTag("setting_sound_toggle")
          )
        }
        Spacer(modifier = Modifier.height(12.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Vibration, contentDescription = null, tint = Color(0xFF00CEC9), modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Text("Vibration Feedback", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
          }
          Switch(
            checked = vibrationEnabled,
            onCheckedChange = {
              vibrationEnabled = it
              prefs.setVibrationEnabled(it)
              soundManager.isVibrationEnabled = it
            },
            colors = SwitchDefaults.colors(
              checkedThumbColor = Color.White,
              checkedTrackColor = Color(0xFF6C5CE7)
            ),
            modifier = Modifier.testTag("setting_vibration_toggle")
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Secure Admin Dashboard Access
    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1B38)),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFF00CEC9), modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("ADMIN DASHBOARD", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
          }
          if (adminAuthSession?.isAuthenticated == true) {
            Text(
              "Authenticated",
              color = Color(0xFF2ED573),
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold
            )
          } else {
            Text(
              "Server Auth Required",
              color = Color(0xFFFFB142),
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold
            )
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (adminAuthSession?.isAuthenticated == true) {
          Text(
            "Logged in as: ${adminAuthSession?.email ?: "Admin"}",
            fontSize = 12.sp,
            color = Color(0xFFA4B0BE)
          )
          Spacer(modifier = Modifier.height(12.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("Enable In-App Ads", color = Color.White, fontSize = 14.sp)
            Switch(
              checked = adminSettings.adsGloballyEnabled,
              onCheckedChange = {
                val updated = adminSettings.copy(adsGloballyEnabled = it)
                adminSettings = updated
                prefs.saveAdminAdSettings(updated)
              }
            )
          }
          Spacer(modifier = Modifier.height(8.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("Banner Ads", color = Color.White, fontSize = 14.sp)
            Switch(
              checked = adminSettings.bannerEnabled,
              onCheckedChange = {
                val updated = adminSettings.copy(bannerEnabled = it)
                adminSettings = updated
                prefs.saveAdminAdSettings(updated)
              }
            )
          }
          Spacer(modifier = Modifier.height(8.dp))
          Text("Interstitial Frequency: Every ${adminSettings.interstitialFrequencyGames} games", color = Color(0xFFA4B0BE), fontSize = 12.sp)
          Slider(
            value = adminSettings.interstitialFrequencyGames.toFloat(),
            onValueChange = {
              val updated = adminSettings.copy(interstitialFrequencyGames = it.toInt().coerceAtLeast(1))
              adminSettings = updated
              prefs.saveAdminAdSettings(updated)
            },
            valueRange = 1f..10f,
            steps = 8,
            colors = SliderDefaults.colors(thumbColor = Color(0xFF6C5CE7), activeTrackColor = Color(0xFF6C5CE7))
          )
          Spacer(modifier = Modifier.height(8.dp))
          Button(
            onClick = { adminAuthSession = null },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF241F42)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text("Sign Out Admin", color = Color.White)
          }
        } else {
          Text(
            "Access to monetization controls and remote ad settings requires verified server-side administrator credentials. No client-side bypass is permitted.",
            fontSize = 11.sp,
            color = Color(0xFFA4B0BE),
            lineHeight = 16.sp
          )
          Spacer(modifier = Modifier.height(10.dp))
          Button(
            onClick = { showAdminLoginDialog = true },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6C5CE7)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text("Server Authenticate")
          }
        }
      }
    }

    // Google Play Policy & Fair Play Info
    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF18152E)),
      modifier = Modifier
        .fillMaxWidth()
        .clickable { showPolicyDialog = true }
    ) {
      Row(
        modifier = Modifier.padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFF2ED573), modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text("100% Free & Family Friendly", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
          Text("No real-money betting • No gambling • No in-app purchases", fontSize = 11.sp, color = Color(0xFFA4B0BE))
        }
      }
    }
  }

  // Edit Name Dialog
  if (showEditNameDialog) {
    var newName by remember { mutableStateOf(profile.name) }
    Dialog(onDismissRequest = { showEditNameDialog = false }) {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF18152E)),
        modifier = Modifier.padding(16.dp)
      ) {
        Column(modifier = Modifier.padding(20.dp)) {
          Text("Edit Player Name", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 18.sp)
          Spacer(modifier = Modifier.height(12.dp))
          OutlinedTextField(
            value = newName,
            onValueChange = { newName = it.take(16) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
              focusedTextColor = Color.White,
              unfocusedTextColor = Color.White,
              focusedBorderColor = Color(0xFF6C5CE7)
            )
          )
          Spacer(modifier = Modifier.height(16.dp))
          Button(
            onClick = {
              if (newName.isNotBlank()) {
                val updated = profile.copy(name = newName.trim())
                profile = updated
                prefs.saveUserProfile(updated)
              }
              showEditNameDialog = false
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6C5CE7)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text("Save Name")
          }
        }
      }
    }
  }

  // Policy Dialog
  if (showPolicyDialog) {
    Dialog(onDismissRequest = { showPolicyDialog = false }) {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF18152E)),
        modifier = Modifier.padding(16.dp)
      ) {
        Column(modifier = Modifier.padding(20.dp)) {
          Text("Fair Play & Privacy Policy", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 18.sp)
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            "✓ All 20 games are completely free to play without payment.\n" +
            "✓ There is no real-money betting, gambling, or cash prizes.\n" +
            "✓ No personal data is sold or shared with external trackers.\n" +
            "✓ High scores and achievements are securely stored locally on your device.\n" +
            "✓ AdMob test ads conform to Google Play Family and Child policies.",
            fontSize = 12.sp,
            color = Color(0xFFA4B0BE),
            lineHeight = 18.sp
          )
          Spacer(modifier = Modifier.height(16.dp))
          Button(
            onClick = { showPolicyDialog = false },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6C5CE7)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text("Close")
          }
        }
      }
    }
  }

  // Admin Server Authentication Dialog
  if (showAdminLoginDialog) {
    var serverUrl by remember { mutableStateOf("https://admin.20freegames.internal/api/v1/auth") }
    var authToken by remember { mutableStateOf("") }
    var isAuthenticating by remember { mutableStateOf(false) }
    var authError by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = { if (!isAuthenticating) showAdminLoginDialog = false }) {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF18152E)),
        modifier = Modifier.padding(16.dp)
      ) {
        Column(modifier = Modifier.padding(20.dp)) {
          Text("Server Admin Authorization", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 18.sp)
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            "Enter your server backend endpoint and OAuth/Bearer token. No client-side passwords are accepted.",
            fontSize = 12.sp,
            color = Color(0xFFA4B0BE)
          )
          Spacer(modifier = Modifier.height(12.dp))
          Text("Auth Endpoint", fontSize = 11.sp, color = Color(0xFFA4B0BE))
          OutlinedTextField(
            value = serverUrl,
            onValueChange = { serverUrl = it },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
              focusedTextColor = Color.White,
              unfocusedTextColor = Color.White,
              focusedBorderColor = Color(0xFF6C5CE7)
            )
          )
          Spacer(modifier = Modifier.height(8.dp))
          Text("Admin Bearer Token", fontSize = 11.sp, color = Color(0xFFA4B0BE))
          OutlinedTextField(
            value = authToken,
            onValueChange = { authToken = it },
            singleLine = true,
            placeholder = { Text("sec_admin_tok_...", color = Color.Gray) },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
              focusedTextColor = Color.White,
              unfocusedTextColor = Color.White,
              focusedBorderColor = Color(0xFF6C5CE7)
            )
          )
          authError?.let { err ->
            Spacer(modifier = Modifier.height(8.dp))
            Text(err, color = Color(0xFFFF5252), fontSize = 11.sp)
          }
          Spacer(modifier = Modifier.height(16.dp))
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
              onClick = { showAdminLoginDialog = false },
              enabled = !isAuthenticating,
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF241F42)),
              modifier = Modifier.weight(1f)
            ) {
              Text("Cancel", color = Color.White)
            }
            Button(
              onClick = {
                isAuthenticating = true
                authError = null
                coroutineScope.launch {
                  val session = adminAuthService.authenticate(serverUrl.trim(), authToken.trim())
                  isAuthenticating = false
                  if (session.isAuthenticated) {
                    adminAuthSession = session
                    showAdminLoginDialog = false
                  } else {
                    authError = session.errorMessage ?: "Authentication failed."
                  }
                }
              },
              enabled = !isAuthenticating && authToken.isNotBlank(),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6C5CE7)),
              modifier = Modifier.weight(1f)
            ) {
              Text(if (isAuthenticating) "Verifying..." else "Verify")
            }
          }
        }
      }
    }
  }
}
