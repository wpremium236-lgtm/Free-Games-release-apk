package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.core.model.GameItem

@Composable
fun GameDetailSheet(
  game: GameItem,
  highScore: Int,
  onStartPlay: () -> Unit,
  onDismiss: () -> Unit
) {
  Dialog(onDismissRequest = onDismiss) {
    Card(
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF18152E)),
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
        .testTag("game_detail_dialog")
    ) {
      Column(modifier = Modifier.padding(20.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(54.dp)
              .clip(RoundedCornerShape(14.dp))
              .background(Brush.linearGradient(listOf(Color(0xFF6C5CE7), Color(0xFF241F42)))),
            contentAlignment = Alignment.Center
          ) {
            Text(game.iconEmoji, fontSize = 30.sp)
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFFA4B0BE))
          }
        }

        Spacer(modifier = Modifier.height(12.dp))
        Text(game.nameEn, fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color.White)
        Text(game.category.displayNameEn.uppercase(), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00CEC9))

        Spacer(modifier = Modifier.height(10.dp))
        Text(game.howToPlayEn, fontSize = 13.sp, color = Color(0xFFA4B0BE), lineHeight = 18.sp)

        Spacer(modifier = Modifier.height(10.dp))
        Text("Controls: ${game.controlsEn}", fontSize = 12.sp, color = Color(0xFFFFB142))

        Spacer(modifier = Modifier.height(14.dp))

        // High score info
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF241F42))
            .padding(12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text("YOUR BEST SCORE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFA4B0BE))
            Text(if (highScore > 0) "$highScore pts" else "No data yet.", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFB142))
          }
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(Color(0xFF18152E))
              .padding(horizontal = 8.dp, vertical = 4.dp)
          ) {
            Text("Free to Play", fontSize = 11.sp, color = Color(0xFF2ED573), fontWeight = FontWeight.Bold)
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
          onClick = {
            onDismiss()
            onStartPlay()
          },
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6C5CE7)),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("detail_start_game_btn")
        ) {
          Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White)
          Spacer(modifier = Modifier.width(6.dp))
          Text("START PLAYING", fontWeight = FontWeight.Black, fontSize = 15.sp)
        }
      }
    }
  }
}
